---
name: fix-issue
description: "Использовать для диагностики и исправления багов: сначала root cause, потом TDD-фикс. Diagnose and fix non-obvious issues via hypothesis testing, then implement the fix with TDD."
argument-hint: "[bug description or error message]"
disable-model-invocation: true
allowed-tools: Read, Edit, Write, Grep, Glob, Bash
---

# Диагностика и исправление бага

Баг: **$ARGUMENTS**

## Фаза 1: Воспроизведение и понимание

1. **Воспроизведи баг** — определи точные шаги/входные данные, которые его вызывают
2. **Собери контекст ошибки**:
   - Полное сообщение об ошибке и traceback
   - Какой модуль выбрасывает ошибку
   - Какие входные данные её вызывают
3. **Прочитай сбойный код** — весь файл целиком, а не только строку с ошибкой. Контекст вокруг ошибки часто важнее самой строки — соседние функции, импорты и обработка ошибок раскрывают замысел автора.

## Фаза 1.5: Быстрая сортировка (triage)

Три параллельных агента-гипотезы (Фаза 2) — мощный инструмент для неочевидных багов. Но когда причина видна из traceback, запускать три агента — трата времени без пользы. Вот как решить:

**Быстрый путь (skip Phase 2)** — используй если выполняется хотя бы два из трёх:
- Traceback указывает на конкретную строку с очевидной ошибкой (KeyError на пустом dict/DataFrame, TypeError: NoneType, IndexError на пустом списке, ImportError)
- Баг локализован в одной функции и не зависит от внешнего состояния (DB, API, env)
- Есть аналогичный обработанный edge case рядом в коде (например, `if df.empty: return None` в соседней функции, а в сбойной — нет)

Примеры быстрого пути:
- `KeyError: 'column_name'` — DataFrame пуст или не содержит колонку, защитная проверка отсутствует
- `TypeError: 'NoneType' has no attribute 'X'` — функция вернула None, вызывающий код не проверил
- `IndexError: list index out of range` — пустой список, нет проверки `if items:`

**Полный анализ (Phase 2)** — используй если:
- Traceback неинформативен (ошибка глубоко в стеке, неожиданное значение, corrupted data)
- Причина может быть в данных, конфиге ИЛИ логике — и непонятно где
- Ошибка нестабильна или зависит от внешнего состояния

При быстром пути — сформулируй одну гипотезу, подтверди её экспериментом и переходи к Фазе 3.

## Фаза 2: Параллельный анализ root cause

Запусти 3 конкурирующих агента-гипотезы через Task tool (тип Explore, ВСЕ ПАРАЛЛЕЛЬНО).

### Адаптация промптов к домену бага

Базовые шаблоны ниже — каркас. Дополни каждый промпт контекстом из Фазы 1, адаптируя проверки к конкретному модулю:

| Модуль бага | Агент 1 (данные) | Агент 2 (конфиг) | Агент 3 (логика) |
|---|---|---|---|
| `core/sql/*` | DataFrame из db_connector, column names | `llm.sql_*` settings, Oracle DSN | SQL regex, парсинг ответа LLM |
| `core/output/chart_*` | DataFrame shape, dtypes, NaN/None | `chart.*`, `data_display.*` settings | matplotlib edge cases: 0/1 строка, пустые значения, формат лейблов |
| `core/output/code_*` | DataFrame merge, column conflicts | pandas version, SAFE_BUILTINS scope | exec() sandbox, LLM code format |
| `core/output/response_*` | dataframe_to_text output, truncation | `llm.response_*` settings | LLM response parsing, encoding |
| `infrastructure/*` | Connection state, SSL certs | `.env`, settings.py defaults | Singleton lifecycle, error handling |

### Агент гипотезы 1: Проблема потока данных
```
Investigate whether the bug in "$ARGUMENTS" is caused by incorrect data flowing
through the pipeline. Trace the data from input to the failure point.
Check: types, None values, empty DataFrames, encoding issues, column name mismatches.
Read the relevant pipeline files and trace the data transformation chain.
[Дополни: специфика модуля из таблицы выше]
```

### Агент гипотезы 2: Проблема конфигурации/окружения
```
Investigate whether the bug in "$ARGUMENTS" is caused by configuration or environment.
Check: settings.py defaults, .env values, missing env vars, model name mismatches,
Oracle connection params, API URL format, SSL/truststore issues.
Read settings.py, the entry points, and the failing module.
[Дополни: специфика модуля из таблицы выше]
```

### Агент гипотезы 3: Проблема логики/граничного случая
```
Investigate whether the bug in "$ARGUMENTS" is caused by a logic error or edge case.
Check: off-by-one, wrong comparison, missing None check, regex mismatch, incorrect
string parsing, LLM response format assumption, SQL generation edge case.
Read the failing function, its tests, and similar functions in other modules.
[Дополни: специфика модуля из таблицы выше]
```

## Фаза 3: Сведение результатов

После получения отчётов от агентов (Фаза 2) или после быстрого пути (Фаза 1.5):

### Критерии приоритизации гипотез

Ранжируй гипотезы по силе доказательств. Критерии упорядочены от сильного к слабому — гипотеза с доказательством верхнего уровня побеждает гипотезу с нижним, даже если нижняя «звучит логичнее»:

1. **Воспроизводимое доказательство** — гипотеза подтверждена конкретным экспериментом.
   Пример: «Добавил `assert not df.empty` перед строкой 42 — тест упал с AssertionError, подтверждая что DataFrame пуст»
2. **Прямое свидетельство в коде** — есть конкретная строка с ошибкой, видно что не так.
   Пример: «Строка 42: `df[column]` вызывается без проверки `if column in df.columns`, а вот строка 38 в той же функции такую проверку делает»
3. **Косвенные улики** — паттерн, который мог бы вызвать баг, но нет прямого доказательства.
   Пример: «settings.py имеет дефолт chart_max_rows=50, а данные содержат 51 строку — может обрезается»
4. **Правдоподобная теория** — логическое рассуждение без доказательств в коде.
   Пример: «Возможно, LLM возвращает формат отличный от ожидаемого»

Если несколько гипотез на одном уровне — проверь каждую целенаправленным экспериментом (добавь assert, print, или запусти с test-данными). Определи root cause с точностью до file:line.

## Фаза 4: Исправление (TDD)

### Ограничения безопасности

Перед исправлением — проверь, есть ли в модуле sandbox-ограничения:
- Модули с `exec()` (chart_generator, code_generator, code_validator) используют `SAFE_BUILTINS` из `infrastructure/safe_builtins.py`. Фикс не должен добавлять exec() без sandbox и не должен обходить существующий sandbox.
- Модули с SQL (sql_generator, sql_validator) — только SELECT-запросы разрешены. Фикс не должен открывать возможность для других типов запросов.

### Шаги исправления

1. **Напиши падающий тест**, воспроизводящий баг
2. **Реализуй минимальное исправление** — только то, что нужно для устранения root cause
3. **Убедись, что тест проходит**
4. **Запусти полный набор тестов** — без регрессий: `.venv/bin/python -m pytest tests/ -v`
5. **Проверь точки входа** — `run_agent.py` и `zulip_bot.py` всё ещё импортируются

## Фаза 5: Отчёт

### Если использовался быстрый путь (Фаза 1.5 → skip Phase 2)

```
## Root cause
[Точное объяснение с file:line]

## Диагностика (быстрый путь)
- Тип ошибки: [KeyError / TypeError / etc.]
- Причина: [конкретное объяснение]
- Почему быстрый путь: [traceback однозначен / баг локализован / аналогичный паттерн рядом]

## Применённое исправление
- [file:line]: [что изменено и почему]

## Тесты
- Добавлен: [имя теста] — воспроизводит исходный баг
- Набор: X прошло, Y упало

## Предотвращение
- [Что предотвратит аналогичные баги в будущем]
```

### Если использовался полный анализ (Phase 2 → 3 агента)

```
## Root cause
[Точное объяснение с file:line]

## Проверенные гипотезы
1. [гипотеза] — [подтверждена/отклонена] — [доказательство] — [уровень: воспроизводимое/прямое/косвенное/теория]
2. [гипотеза] — [подтверждена/отклонена] — [доказательство] — [уровень: ...]
3. [гипотеза] — [подтверждена/отклонена] — [доказательство] — [уровень: ...]

## Применённое исправление
- [file:line]: [что изменено и почему]

## Тесты
- Добавлен: [имя теста] — воспроизводит исходный баг
- Набор: X прошло, Y упало

## Предотвращение
- [Что предотвратит аналогичные баги в будущем]
```

## Дальнейшие действия

- Запустить `/verify` для полной проверки пайплайна после исправления
- Если исправление было сложным: запустить `/compound` для документирования паттерна отладки
- Если связано с безопасностью: запустить security-auditor агент (subagent_type="security-auditor")
