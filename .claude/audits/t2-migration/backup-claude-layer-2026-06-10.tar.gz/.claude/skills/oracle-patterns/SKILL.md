---
name: oracle-patterns
description: "Фоновые знания о паттернах Oracle DB в проекте: таблицы client_product и desk (ADR-021 access control), пайплайн генерации SQL (декомпозиция ADR-010), пулинг соединений, валидация SQL с сохранением структуры. Загружается автоматически при работе с SQL-кодом (core/sql/*, db_connector)."
user-invocable: false
---

# Паттерны Oracle DB

## Таблица: client_product

Единственная таблица в Oracle с банковскими данными корпоративных клиентов (описана в metadata.py, ~500 строк).
Все SQL-запросы в проекте работают исключительно с этой таблицей. Данные агрегированы по месяцам (поле MONTH_DT -- последний день месяца).

Ключевые поля имеют `is_key=True` в metadata — они всегда включаются в LLM-промпты независимо от TF-IDF релевантности.

## Пайплайн генерации SQL (декомпозиция ADR-010)

generator.py — тонкий оркестратор. Логика разделена на 3 модуля:

```
core/sql/
  generator.py       — оркестратор: generate_sql()
  field_search.py     — TF-IDF + морфологический ранжинг полей
  keywords.py         — извлечение ключевых слов + стемминг (русский язык)
  extraction.py       — парсинг SQL из ответа LLM
  prompts/v1/sql_generation.txt — шаблон системного промпта (628 строк, .format() placeholders)
```

### Поток: вопрос → SQL

```
вопрос
  → extract_keywords_from_question()         [keywords.py]
  → find_relevant_fields_vector_search()     [field_search.py]
    - TF-IDF cosine similarity по каждому ключевому слову
    - морфологический fallback (check_keyword_in_text через get_word_stem)
    - TF-IDF поиск по полному вопросу (вес ×2.0)
    - ключевые поля исключаются здесь (добавляются отдельно позже)
  → get_key_fields()                         [field_search.py]
    - поля с is_key=True в metadata
    - добавляются ПОСЛЕ релевантных полей (порядок релевантности сохраняется)
  → get_relevant_fields_description()        [field_search.py]
    - полный формат метаданных (тип, категория, валюта, правила агрегации)
    - compact=False для генерации SQL (полные описания)
  → _build_sql_generation_system_prompt()    [generator.py]
    - загружает шаблон из core/sql/prompts/v1/sql_generation.txt (@lru_cache)
    - .format(table_name, table_description, fields_description, question)
  → call_llm(prompt, temperature=0.1)        [llm_client.py]
  → extract_sql_from_response()              [extraction.py]
    - вырезает блоки <think>...</think> (reasoning-модели)
    - цепочка извлечения: теги <sql> → ```sql markdown → plain SELECT
    - обработка multi-statement SQL (учёт скобок и точек с запятой)
```

## Пайплайн валидации SQL (core/sql/validator.py)

Двухступенчатая валидация с сохранением структуры:

```
SQL-запрос
  → Этап 1: validate_sql_syntax() — базовые проверки (БД не нужна)
    - SELECT/FROM обязательны
    - опасные ключевые слова заблокированы (DROP, DELETE, INSERT и др.)
    - проверка баланса скобок
    - строковые литералы вырезаются перед проверкой ключевых слов

  → Этап 2: EXPLAIN PLAN на реальной БД (когда передан db_executor)
    - db_executor.validate_sql_syntax(sql) — использует EXPLAIN PLAN
    - неагрегированные запросы получают FETCH FIRST 1 ROW ONLY для безопасности

  → При ошибке: fix_sql_with_llm() — исправление через LLM
    - find_metadata_fields_in_sql() — извлекает используемые поля из SQL через regex
    - передаёт компактное описание полей (только используемые + MONTH_DT)
    - до 3 попыток (sql_fix_max_attempts)

  → После каждого исправления: check_sql_structure_preserved()
    - проверяет что GROUP BY, HAVING, ORDER BY не удалены
    - проверяет что количество полей SELECT не уменьшилось вдвое
    - если структура потеряна → повторная попытка с усиленным промптом
```

Ключевые сигнатуры функций:
```python
validate_and_fix_sql(sql, original_question, db_executor=None, model=DEFAULT_MODEL, max_attempts=None) -> (sql, bool)
fix_sql_with_llm(sql, error_message, original_question, model=DEFAULT_MODEL, max_attempts=None) -> str
find_metadata_fields_in_sql(sql) -> list[str]
check_sql_structure_preserved(original_sql, fixed_sql) -> (bool, str)
```

## Паттерн подключения (infrastructure/db_connector.py)

```python
# Прямое подключение (legacy)
connector = OracleConnector(user, password, dsn)
connector.connect()
df = connector.execute_query(sql)
connector.disconnect()

# Пул соединений (предпочтительно — ADR-004)
pool = create_db_pool(user, password, dsn, min=1, max=5, increment=1)
connector = OracleConnector(user, password, dsn, pool=pool)
connector.connect()            # берёт соединение из пула
df = connector.execute_query(sql)
connector.disconnect()         # возвращает соединение в пул

# Context manager (тоже поддерживается)
with OracleConnector(user, password, dsn, pool=pool) as connector:
    df = connector.execute_query(sql)
```

Хелпер: `create_db_connector(settings=None) -> OracleConnector` — создаёт коннектор из settings с пулом.

## Используемые настройки

```python
s = get_settings()
# Генерация SQL
s.llm.sql_gen_temperature     # 0.1 — низкая для детерминированного SQL
s.llm.sql_gen_max_tokens      # 6000
s.llm.sql_max_prompt_length   # 15000
# Исправление SQL
s.llm.sql_fix_temperature     # 0.3
s.llm.sql_fix_max_tokens      # 4000
s.llm.sql_fix_max_attempts    # 3
# TF-IDF
s.search.relevant_fields_top_n    # 50
s.search.tfidf_max_features       # 5000
s.search.tfidf_ngram_min          # 1
s.search.tfidf_ngram_max          # 2
# Пул
s.pool.pool_min       # 1
s.pool.pool_max       # 5
s.pool.pool_increment # 1
```

## Таблица: desk

Организационная структура менеджеров и дэсков. Используется для row-level access control (ADR-021).
Каждая строка — менеджер с привязкой к дэску. Актуальные записи: `VALID_TO = DATE '4000-01-01'`.

Ключевые поля:
- `LOGIN` — логин менеджера (ключ связи с access_rules.yaml)
- `DESK_NAME` — название дэска (значение для фильтра в client_product.DESK)
- `HEAD_FLG` — `'Y'` = руководитель с полным доступом (без CTE-фильтра)
- `VALID_TO` — `DATE '4000-01-01'` = актуальная запись
- `DESK_CODE` — категория дэска (Regions, International, Large, Middle, FI)
- `MANAGER_NAME` — ФИО менеджера

Связь с client_product: `desk.DESK_NAME` соответствует `client_product.DESK`.

Dev seed-данные (8 записей): 7 актуальных менеджеров по дэскам (Region 1, International 1/2, Large 1, Middle 1, FI) + 1 историческая запись.

## Dev-окружение

- Oracle XE Docker: localhost:1521/XEPDB1 (dev_user/dev_password)
- network_mode: host (обход VPN — ADR-001)
- Проверка подключения: `python dev/test-connection.py`
