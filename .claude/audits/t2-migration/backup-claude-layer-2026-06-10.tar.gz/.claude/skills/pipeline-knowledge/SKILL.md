---
name: pipeline-knowledge
description: "Background knowledge about the 8-step data processing pipeline, module responsibilities, and data flow patterns. Automatically loaded when working with pipeline-related code (agent.py, sql_generator, sql_validator, chart_generator, response_generator, code_generator)."
user-invocable: false
---

# Архитектура пайплайна

## 8-шаговый пайплайн (agent.py::AIAgent.process_question)

```
Вход: вопрос пользователя (str)
  │
  ├─[1] relevance_checker.check_relevance(question)
  │     Использует: metadata.py (словарь полей), utils.get_word_stem()
  │     Возвращает: bool — если False, пайплайн останавливается с "вопрос нерелевантен"
  │
  ├─[2] question_analyzer.analyze_question(question)
  │     Использует: LLM call (qa_analyze_temperature/max_tokens)
  │     Возвращает: List[str] — атомарные подвопросы (фильтрует LLM "thinking")
  │
  ├─[3] ДЛЯ КАЖДОГО подвопроса → _process_subquestions():
  │     ├─ sql_generator.generate_sql(subquestion)
  │     │   Использует: LLM + TF-IDF (sklearn) + metadata.py
  │     │   Возвращает: SQL-запрос (строка)
  │     │
  │     ├─ sql_validator.validate_and_fix_sql(sql)
  │     │   Использует: EXPLAIN PLAN на Oracle + LLM fix (до 3 попыток)
  │     │   Возвращает: валидированный SQL (строка)
  │     │
  │     ├─ db_connector.execute_query(sql)
  │     │   Использует: oracledb + pandas.read_sql
  │     │   Возвращает: pandas DataFrame
  │     │
  │     ├─ chart_generator.generate_chart(df, subquestion)
  │     │   Использует: LLM → matplotlib код → exec(SAFE_BUILTINS)
  │     │   Возвращает: путь к PNG-файлу в output/
  │     │
  │     └─ response_generator.generate_response(df, subquestion)
  │         Использует: LLM + metadata.py для описаний полей
  │         Возвращает: текстовый ответ на естественном языке
  │
  ├─[4] code_generator + code_validator → _merge_dataframes()
  │     Объединяет N DataFrame в один через pandas-код, сгенерированный LLM
  │     exec() с sandbox SAFE_BUILTINS
  │
  ├─[5] chart_generator → итоговый объединённый график
  ├─[6] response_generator → итоговый ответ на естественном языке
  ├─[7] save_dataframes_to_excel → Excel в output/
  └─[8] pdf_generator → PDF-отчёт в output/

Выход: Dict с текстом, путями к графикам, путём к Excel, путём к PDF
```

## Критические инварианты

1. **Все exec() используют SAFE_BUILTINS** — никогда сырые __builtins__
2. **Все LLM-вызовы проходят через llm_client.call_llm()** — singleton с retry
3. **Всё выполнение SQL через db_connector.OracleConnector** — поддерживает пулинг
4. **Имена моделей из settings.py** — никогда не захардкожены в модулях
5. **Выходные файлы всегда в output/** — через output_config.get_output_path()
6. **У metadata.py 6 потребителей** — изменение требует проверки всех 6

## Типы данных в потоке

```
str (question) → List[str] (subquestions) → str (SQL) → DataFrame → str (NL answer)
                                                      → PNG (chart)
                                                      → DataFrame (merged)
                                                      → XLSX (Excel)
                                                      → PDF (report)
```
