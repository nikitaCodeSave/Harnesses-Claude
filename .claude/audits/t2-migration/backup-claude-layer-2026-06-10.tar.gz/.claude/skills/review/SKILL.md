---
name: review
description: "Использовать для ревью после реализации или перед merge: параллельная проверка security, quality, architecture, test coverage. Multi-perspective code review with specialist agents."
argument-hint: "[working|staged|unstaged|branch[:base]|file paths]"
disable-model-invocation: false
allowed-tools: Read, Grep, Glob, Bash(git *)
---

# Мультиагентное ревью кода

Ревью: **$ARGUMENTS**

## Шаг 1. Определение области ревью

Определи git-команду для diff на основе `$ARGUMENTS`:

| $ARGUMENTS | Команда diff | Команда файлов |
|---|---|---|
| пусто или `working` | `git diff HEAD` | `git diff HEAD --name-only` |
| `staged` | `git diff --cached` | `git diff --cached --name-only` |
| `unstaged` | `git diff` | `git diff --name-only` |
| `branch` | `git diff main...HEAD` | `git diff main...HEAD --name-only` |
| `branch:<base>` | `git diff <base>...HEAD` | `git diff <base>...HEAD --name-only` |
| пути к файлам | — (читать файлы напрямую) | использовать указанные пути |
| номер PR | `gh pr diff $ARGUMENTS` | `gh pr diff $ARGUMENTS --name-only` |

## Шаг 2. Получение изменений и списка файлов

Выполни две команды параллельно:

1. **Статистика изменений**: `git diff <scope> --stat` — для отображения пользователю
2. **Список файлов**: `git diff <scope> --name-only` — для передачи агентам ревью

Покажи статистику изменений пользователю.

## Шаг 3. Проверка наличия изменений

Если команда diff вернула пустой результат (нет изменений в выбранной области):
- **Остановиться** — НЕ запускать агентов ревью.
- Сообщить: "Нет изменений в выбранной области."
- Предложить альтернативные области: `working`, `staged`, `unstaged`, `branch` или явные пути к файлам.

## Шаг 4. Запуск параллельных агентов ревью

Запустить **4 агента через Task tool, ВСЕ ПАРАЛЛЕЛЬНО в одном сообщении**.

Каждому агенту передать список файлов, полученный на Шаге 2.

### 4.1 Ревьюер безопасности

Использовать `subagent_type="security-auditor"` — выделенный агент безопасности с предзагруженными знаниями о pipeline и Oracle-паттернах.

```
Review these changed files for security issues.
Focus on: exec() sandboxing (SAFE_BUILTINS), hardcoded secrets, SQL injection, LLM prompt injection, file path traversal.
Changed files: <список файлов из Шага 2>
```

### 4.2 Ревьюер качества кода

Использовать `subagent_type="Explore"` — агент с доступом к Glob, Grep, Read для анализа кодовой базы.

```
Review code quality of these changes:
- Function complexity (>20 lines = flag for extraction)
- Error handling (bare except, swallowed exceptions)
- Type hints presence on new/changed functions
- Naming conventions (snake_case functions, PascalCase classes, UPPER constants)
- DRY violations (copy-pasted logic that should be shared)
- Import order (stdlib, third-party, local)
- Logging vs print (helper modules must use logging, not print)

Changed files: <список файлов из Шага 2>
Report: issue type, file:line, description, suggestion
```

### 4.3 Ревьюер архитектуры

Использовать `subagent_type="Explore"` — агент с доступом к Glob, Grep, Read для анализа зависимостей.

```
Review architectural compliance of these changes against docs/architecture.md:
- Does the change respect the module dependency graph?
- Are new imports creating unexpected coupling?
- Is the 8-step pipeline preserved?
- Are both entry points (run_agent.py, zulip_bot.py) still consistent?
- Does settings.py integration follow the pattern (get_settings(), not direct env reads)?
- If metadata.py touched — are all 6 consumers checked?

Changed files: <список файлов из Шага 2>
Report: compliance issue, file:line, which architectural rule is violated
```

### 4.4 Ревьюер тестового покрытия

Использовать `subagent_type="Explore"` — агент с доступом к Glob, Grep, Read для поиска тестов.

```
Review test coverage for these changes:
- Do new functions have corresponding tests in tests/<layer>/test_<module>.py?
- Do changed functions have tests updated for new behavior?
- Are edge cases covered (empty input, None, error paths)?
- Do tests use mocks for LLM (patch llm_client.call_llm) and Oracle (patch db_connector)?
- Test naming: test_<what>_<scenario>_<expected>

Changed files: <список файлов из Шага 2>
Report: missing tests, weak tests, test file that needs update
```

## Шаг 5. Синтез результатов

После завершения работы всех 4 агентов составить единый отчёт.

Каждую найденную проблему классифицировать по серьёзности:
- **Критичные** — блокируют merge: уязвимости безопасности, сломанный pipeline, потеря данных
- **Важные** — следует исправить: нарушение конвенций, пропущенные тесты, слабая обработка ошибок
- **Предложения** — желательно: стилистические улучшения, оптимизации, рефакторинг

Формат отчёта:

```
## Итоги ревью

| Категория | Проблем | Критичных |
|---|---|---|
| Безопасность | X | Y |
| Качество кода | X | Y |
| Архитектура | X | Y |
| Тестовое покрытие | X | Y |

## Критичные (блокируют merge)
1. [проблема] — `file:line` — [предложение по исправлению]

## Важные (следует исправить)
1. [проблема] — `file:line` — [предложение по исправлению]

## Предложения (желательно)
1. [проблема] — `file:line` — [предложение по исправлению]

## Вердикт: Одобрено / Не одобрено
- **Одобрено** — если нет критичных проблем
- **Не одобрено** — если есть хотя бы одна критичная проблема (перечислить блокеры)
```

Если в какой-то категории 0 проблем — указать "0" в таблице и не создавать пустую секцию.

## Дальнейшие шаги

- Если не одобрено: предложить исправления для критичных проблем
- Если одобрено: запустить `/verify` для финальной проверки → `/compound` для документирования
