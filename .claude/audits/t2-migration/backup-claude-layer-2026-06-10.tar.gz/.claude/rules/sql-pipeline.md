---
paths: ["core/sql/**", "core/analysis/**"]
---

# Правило: SQL-пайплайн

## Генерация SQL
- Не использовать `SELECT *` — только явные колонки из metadata.py
- Все значения в WHERE через параметры (`:param`), не через конкатенацию строк
- LIKE-паттерны: `UPPER(field) LIKE UPPER('%value%')` — validator исправляет автоматически

## Валидация
- EXPLAIN PLAN обязателен перед возвратом SQL пользователю (validator.py)
- LLM-фикс до 3 попыток, потом — ошибка пользователю, не бесконечный retry

## Промпты (core/sql/prompts/)
- Изменения промптов требуют live-теста на реальной модели (GenAI/Qwen3-30B-A3B)
- Unit-тесты проверяют формат ответа, не содержание — LLM недетерминирован

## Зависимости metadata.py
- metadata.py используют 6 модулей: relevance_checker, sql/generator, sql/validator, response_generator, chart_generator, agent
- При изменении metadata.py — проверить все 6 зависимых модулей
