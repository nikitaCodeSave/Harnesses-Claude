---
paths:
  - "infrastructure/safe_builtins.py"
  - "infrastructure/db_connector.py"
  - "infrastructure/llm_client.py"
  - "infrastructure/settings.py"
  - "infrastructure/user_access.py"
---

# Правило: security-critical модули

## safe_builtins.py
- Изменения требуют ADR — это sandbox для exec()
- Проверить все вызовы exec() в проекте: `core/output/code_validator.py`
- Не добавлять builtins без явной необходимости (принцип минимальных привилегий)

## db_connector.py
- Не хардкодить DSN, credentials — только через settings.py / .env
- Все SQL-запросы параметризованы (bind variables), не конкатенация строк

## llm_client.py
- Singleton-паттерн — не создавать второй экземпляр клиента
- SSL через truststore — не отключать верификацию сертификатов
- LLMCallError — единственный тип ошибки для вызывающего кода

## settings.py
- После изменений проверить обе точки входа: `presentation/cli.py`, `presentation/zulip_bot.py`
- Все параметры через pydantic-settings v2, дефолты в классе, переопределение через .env

## user_access.py
- YAML whitelist (ADR-022) — email/fnmatch паттерны
- AccessDeniedError — не подавлять, пробрасывать до пользователя
