# Правило: тестирование

## Структура тестов
- Тесты зеркалируют src-структуру (Phase 8, ADR-012):
  - `tests/infrastructure/` — settings, llm, db, utils, meta-тесты
  - `tests/core/sql/` — sql generator, extraction, keywords, field_search, validator
  - `tests/core/analysis/` — relevance_checker
  - `tests/core/output/` — response_generator, chart_generator, code_generator
  - `tests/core/report/` — pdf integration, formatters, styles, table_builder
  - `tests/application/` — agent methods, callback, request_id
  - `tests/presentation/` — zulip pool
- Общие фикстуры: tests/conftest.py
- НЕ добавлять `__init__.py` в тестовые поддиректории (вызывает package shadowing)
- Виртуальная среда: .venv/bin/pytest
- Запуск: `pytest tests/ -v`
- Запуск одного файла: `pytest tests/infrastructure/test_utils.py -v`

## Фреймворк и стиль
- pytest (НЕ unittest)
- Моки для LLM: `unittest.mock.patch` на `infrastructure.llm_client.call_llm` (или `core.*.module.call_llm` для конкретного модуля)
- Моки для Oracle: `unittest.mock.patch` на `infrastructure.db_connector.OracleConnector`
- Unit-тесты: НИКОГДА не вызывай реальные LLM API и Oracle DB
- Имена тестов на английском: test_<what>_<scenario>_<expected>
- Пример: test_get_word_stem_russian_word_returns_stem

## Приоритеты тестирования
1. Чистые функции без побочных эффектов (get_word_stem, extract_python_code, find_metadata_fields_in_sql)
2. Валидация и проверки (check_sql_structure_preserved, check_relevance)
3. Парсинг и форматирование (extract_sql_from_response, dataframe_to_text)
4. Интеграционные пути с моками (sql_generator -> sql_validator -> db_connector)

## Тестирование LLM-зависимых фич
- Тестировать ФОРМАТ ответа, не содержание (LLM недетерминирован)
- Замерять размер промпта: assert len(prompt) < settings.llm.sql_max_prompt_length
- Тестировать fallback-пути (что если LLM вернёт мусор/пустой ответ?)

## Интеграционное тестирование на живом dev-окружении
- Dev-окружение ИНИЦИАЛИЗИРОВАНО: Oracle XE (localhost:1521/XEPDB1) + Ollama (localhost:11434)
- Проверка подключений: `python dev/test-connection.py`
- Ручной smoke-test: `python run_agent.py` → задать вопрос к реальной БД
- После значимых изменений — ОБЯЗАТЕЛЬНО прогнать живой запрос через `run_agent.py` для проверки e2e
- Интеграционные тесты (tests/test_integration_*.py): могут использовать реальную Oracle и Ollama, маркировать `@pytest.mark.integration`
- Маркеры: `@pytest.mark.integration` (все), `@pytest.mark.slow` (полный пайплайн через AIAgent.process_question, 50-80s каждый)
- Быстрый прогон (~11s): `pytest -m "integration and not slow"` — 24 теста
- Полный прогон (~195s): `pytest -m integration` — все 27 тестов
- Только slow (~180s): `pytest -m "integration and slow"` — 3 теста (e2e)

## Что НЕ тестировать напрямую
- metadata.py (статические данные — тестировать только структуру, не содержимое)
- pdf_generator.py внутренности (тестировать только что PDF-файл создаётся)
- Конкретные ответы LLM (они недетерминированы — тестировать формат, не содержание)
