# Правило: стиль кода

## Конвенции проекта
- Python 3.10+ (type hints через typing: Optional, List, Dict, Tuple, Set)
- Docstrings: Google-style (Args:, Returns:, Raises:)
- Максимальная длина строки: нет жёсткого лимита, но стараться <=120 символов

## Именование
- Модули: snake_case.py (sql_generator.py, chart_generator.py)
- Классы: PascalCase (AIAgent, OracleConnector, LLMClient)
- Функции/методы: snake_case (generate_sql, validate_and_fix_sql)
- Константы: UPPER_SNAKE (ORACLE_USERNAME, DEFAULT_MODEL, OUTPUT_DIR)
- Приватные методы: _prefix (_process_subquestions, _merge_dataframes, _generate_reports, _emit)

## Импорты (порядок)
1. Стандартная библиотека (os, sys, json, typing, datetime)
2. Пустая строка
3. Сторонние пакеты (pandas, numpy, matplotlib, oracledb, openai)
4. Пустая строка
5. Локальные модули (from llm_client import call_llm)

## Логирование
- Модуль logging, НЕ print() в helper-модулях
- Каждый модуль: logger = logging.getLogger(__name__)
- Уровни: debug (детали), info (прогресс), warning (нештатные), error (ошибки)
- print() допустим ТОЛЬКО в user-facing коде точек входа (run_agent.py, agent.py CLI)

## Язык
- Код (переменные, функции, классы): английский
- Docstrings: русский (Google-style: Args:, Returns:, Raises:)
- Комментарии в коде: русский допустим
- Пользовательский вывод (print/logging): русский
- Документация (.md файлы): русский
- Тесты (имена, описания): английский

## Сверка с документацией
- При использовании сторонних библиотек — проверяй API через context7 или WebSearch, не полагайся на knowledge cutoff
- При обновлении зависимостей — проверяй changelog и breaking changes

## Конфигурация
- Все параметры через settings.py (get_settings())
- Дефолтная модель: llm_client.DEFAULT_MODEL ("GenAI/Qwen3-30B-A3B")
