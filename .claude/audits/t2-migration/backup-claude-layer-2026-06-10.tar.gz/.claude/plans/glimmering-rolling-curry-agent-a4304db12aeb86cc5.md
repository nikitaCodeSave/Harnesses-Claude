# Research: obra/superpowers Claude Code Plugin

## Overview

**Repo:** https://github.com/obra/superpowers
**Author:** Jesse Vincent (obra) / Prime Radiant
**Stars:** 115,343 | **Forks:** 9,235 | **License:** MIT
**Version:** 5.0.6 | **Language:** Shell (primary), Markdown skills
**Description:** "An agentic skills framework & software development methodology that works."

---

## How It Works (Architecture)

Superpowers is a **Claude Code plugin** (also supports Cursor, Codex, OpenCode, Gemini CLI) that injects a set of "skills" -- Markdown documents that function as behavioral protocols. Skills are NOT code libraries; they are structured instructions that the LLM follows.

### Installation Mechanism

1. **Claude Code plugin marketplace** -- `/plugin install superpowers@claude-plugins-official`
2. Plugin manifest at `.claude-plugin/plugin.json`
3. **SessionStart hook** (`hooks/hooks.json`) runs a bash script on every session start
4. The hook reads `skills/using-superpowers/SKILL.md` and injects it as `additionalContext` into the session
5. This bootstrap skill (`using-superpowers`) tells the agent: "Before ANY response, check if a skill applies. If even 1% chance -- invoke it."

### Skill Invocation

Skills are loaded via Claude Code's `Skill` tool (not Read). The `using-superpowers` skill is pre-loaded at session start; all others are loaded on-demand when the agent detects relevance.

### Directory Structure

```
.claude-plugin/
  plugin.json              # Plugin manifest (name, version, author)
  marketplace.json         # Marketplace config
hooks/
  hooks.json               # SessionStart hook definition
  hooks-cursor.json        # Cursor variant
  run-hook.cmd             # Windows hook runner
  session-start            # Bash script: injects using-superpowers into context
skills/
  brainstorming/           # SKILL.md + visual companion scripts
  dispatching-parallel-agents/  # SKILL.md
  executing-plans/         # SKILL.md
  finishing-a-development-branch/  # SKILL.md
  receiving-code-review/   # SKILL.md
  requesting-code-review/  # SKILL.md + code-reviewer.md
  subagent-driven-development/   # SKILL.md + 3 prompt templates
  systematic-debugging/    # SKILL.md + 5 supporting .md files + find-polluter.sh
  test-driven-development/ # SKILL.md + testing-anti-patterns.md
  using-git-worktrees/     # SKILL.md
  using-superpowers/       # SKILL.md + platform references
  verification-before-completion/  # SKILL.md
  writing-plans/           # SKILL.md + plan-document-reviewer-prompt.md
  writing-skills/          # SKILL.md + examples + best practices
agents/
  code-reviewer.md         # Agent prompt for code review
commands/
  brainstorm.md            # Slash command
  execute-plan.md
  write-plan.md
tests/                     # Shell-based skill tests
  claude-code/             # Integration tests for Claude Code
  explicit-skill-requests/ # Tests for explicit invocation
  skill-triggering/        # Tests for automatic triggering
  subagent-driven-dev/     # E2E tests with scaffold projects
```

---

## Complete Skills List (14 skills)

### Testing
1. **test-driven-development** -- RED-GREEN-REFACTOR cycle enforcement

### Debugging
2. **systematic-debugging** -- 4-phase root cause process
3. **verification-before-completion** -- Evidence before claims

### Collaboration / Workflow
4. **brainstorming** -- Socratic design refinement (HARD GATE: no code before design approval)
5. **writing-plans** -- Implementation plans with bite-sized tasks (2-5 min each)
6. **executing-plans** -- Batch execution with human checkpoints
7. **subagent-driven-development** -- Fresh subagent per task + two-stage review
8. **dispatching-parallel-agents** -- Concurrent subagent workflows
9. **requesting-code-review** -- Pre-review checklist
10. **receiving-code-review** -- Responding to feedback
11. **using-git-worktrees** -- Isolated development branches
12. **finishing-a-development-branch** -- Merge/PR decision workflow

### Meta
13. **writing-skills** -- Create new skills following best practices
14. **using-superpowers** -- Bootstrap skill, loaded at session start

---

## TDD Skill -- Deep Dive

### The Iron Law
```
NO PRODUCTION CODE WITHOUT A FAILING TEST FIRST
```

If code was written before the test: **delete it**. Not "keep as reference", not "adapt it" -- delete means delete.

### RED-GREEN-REFACTOR Cycle Enforcement

**RED:** Write one minimal test. Run it. Confirm it **fails** (not errors). Failure must be because feature is missing, not typos.

**GREEN:** Write the **simplest** code to make the test pass. No over-engineering (YAGNI). Don't add features, don't refactor, don't "improve".

**REFACTOR:** Only after green. Remove duplication, improve names, extract helpers. Tests must stay green.

### How It Prevents Violations

The skill uses a **"Common Rationalizations" table** -- a list of 11 excuses with pre-written rebuttals:
- "Too simple to test" -> "Simple code breaks. Test takes 30 seconds."
- "I'll test after" -> "Tests passing immediately prove nothing."
- "Need to explore first" -> "Fine. Throw away exploration, start with TDD."
- "TDD will slow me down" -> "TDD faster than debugging."

Plus a **"Red Flags - STOP and Start Over"** list:
- Code before test
- Test passes immediately
- Can't explain why test failed
- "Just this once" rationalization

### Testing Anti-Patterns (supporting document)

5 anti-patterns with gate functions:
1. **Testing mock behavior** -- asserting on mocks instead of real code
2. **Test-only methods in production** -- `destroy()` only used in tests
3. **Mocking without understanding** -- over-mocking breaks test logic
4. **Incomplete mocks** -- partial data structures hide bugs
5. **Integration tests as afterthought**

Each has a "Gate Function" -- a decision tree the agent runs before the anti-pattern action.

---

## Systematic Debugging -- Deep Dive

### 4 Phases (must complete each before proceeding)

**Phase 1: Root Cause Investigation**
- Read error messages carefully (full stack traces)
- Reproduce consistently
- Check recent changes (git diff)
- Gather evidence in multi-component systems (add diagnostic logging at each boundary)
- Trace data flow backward (see root-cause-tracing.md)

**Phase 2: Pattern Analysis**
- Find working examples in same codebase
- Compare against references (read completely, don't skim)
- Identify all differences

**Phase 3: Hypothesis and Testing**
- Form single hypothesis, state it explicitly
- Test with smallest possible change
- One variable at a time

**Phase 4: Implementation**
- Create failing test case first (uses TDD skill)
- Implement single fix
- Verify fix

### The 3-Failed-Fixes Architectural Review

This is the key escalation mechanism:

```
Phase 4, Step 4:
  If Fix Doesn't Work:
    Count: How many fixes have you tried?
    If < 3: Return to Phase 1, re-analyze
    If >= 3: STOP and question the architecture

  Signals of architectural problem:
    - Each fix reveals new shared state/coupling
    - Fixes require "massive refactoring"
    - Each fix creates new symptoms elsewhere

  Action: Discuss with human partner before attempting more fixes
```

The skill explicitly says: "This is NOT a failed hypothesis -- this is a wrong architecture."

### Supporting Techniques
- **root-cause-tracing.md** -- Backward tracing through call chain (5-step process)
- **defense-in-depth.md** -- Add validation at multiple layers
- **condition-based-waiting.md** -- Replace arbitrary timeouts with condition polling
- **find-polluter.sh** -- Shell script to bisect which test pollutes state

---

## Subagent-Driven Development -- Deep Dive

The most complex workflow. Per task:
1. Dispatch **implementer subagent** (fresh context, no session history)
2. Implementer implements + tests + commits + self-reviews
3. Dispatch **spec reviewer subagent** (checks against spec)
4. If spec issues -> implementer fixes -> re-review
5. Dispatch **code quality reviewer subagent**
6. If quality issues -> implementer fixes -> re-review
7. Mark task complete

Has 4 implementer statuses: DONE, DONE_WITH_CONCERNS, NEEDS_CONTEXT, BLOCKED

**Model selection guidance:** cheap models for mechanical tasks (1-2 files), capable models for architecture/review.

---

## The Full Workflow (End to End)

1. **brainstorming** -- Before ANY code. Explores idea, asks questions one at a time, proposes 2-3 approaches, presents design in sections, writes spec to `docs/superpowers/specs/`. HARD GATE: no implementation until design approved.

2. **using-git-worktrees** -- Creates isolated workspace on new branch after design approval.

3. **writing-plans** -- Breaks spec into bite-sized tasks (2-5 min each). Every task has exact file paths, complete code, verification steps. No placeholders allowed. Saves to `docs/superpowers/plans/`.

4. **subagent-driven-development** (or **executing-plans**) -- Executes plan task by task with fresh subagents and two-stage review.

5. **test-driven-development** -- Used by implementer subagents during step 4. RED-GREEN-REFACTOR for each task.

6. **requesting-code-review** -- Between tasks and at completion.

7. **finishing-a-development-branch** -- Verifies tests, presents merge/PR options, cleans up worktree.

---

## Comparison with Custom Project Skills (.claude/rules/)

| Aspect | obra/superpowers | Custom .claude/rules/ |
|--------|-----------------|----------------------|
| **Scope** | Universal methodology | Project-specific rules |
| **Installation** | Plugin marketplace | Manual, in-repo |
| **Enforcement** | SessionStart hook + "must invoke" directive | Always loaded from .claude/ |
| **Skill count** | 14 skills | N/A (flat rules) |
| **Subagent workflow** | Built-in (implementer/reviewer prompts) | Must build manually |
| **TDD enforcement** | Dedicated skill with rationalizations table | Rules mention TDD but less enforcement |
| **Debugging** | 4-phase process + 3-fix escalation | Ad hoc |
| **Plan format** | Standardized with bite-sized tasks | Project-defined |
| **Git worktrees** | Dedicated skill | Not typically covered |
| **Priority** | User instructions (CLAUDE.md) override superpowers | N/A |

### Key Difference

Superpowers skills are **behavioral protocols with enforcement mechanisms** (iron laws, gate functions, rationalization tables, red flag lists). They don't just say "do TDD" -- they anticipate how the agent will try to skip it and pre-empt those rationalizations.

Custom rules are typically **declarative** ("use TDD", "run tests first") without the same depth of enforcement.

### Compatibility

Superpowers explicitly states: "User's explicit instructions (CLAUDE.md) take precedence over superpowers skills." So they're designed to work alongside project rules, not replace them.

---

## Key Design Principles

1. **Skills trigger automatically** -- the agent checks for relevant skills before any task
2. **Rigid vs Flexible skills** -- TDD and debugging are rigid (follow exactly); patterns are flexible
3. **Iron Laws** -- non-negotiable rules stated upfront in each skill
4. **Rationalization prevention** -- anticipates excuses and provides rebuttals
5. **Gate functions** -- decision trees run before potentially harmful actions
6. **Verification-first** -- "Evidence before claims, always"
7. **Fresh context per subagent** -- prevents context pollution across tasks
