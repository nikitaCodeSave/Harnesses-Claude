# Phase 3: Интеграционный smoke-тест batch-режима

## Контекст

Phase 1 (skip-флаги в agent/subquestion/reports) и Phase 2 (BatchRunner + CLI) полностью реализованы и покрыты 25 unit-тестами. Нужно проверить batch-режим на **живом dev-окружении** (Oracle XE + Ollama) с 2-3 реальными вопросами из `dev/вопросы_client_product.json`, чтобы убедиться что весь пайплайн работает end-to-end.

## Выбор вопросов (3 шт, покрывают 3 сценария)

| # | Вопрос | Сценарий | Ожидание |
|---|--------|----------|----------|
| 1 | "Какая общая сумма дохода за 2024 год?" | Простой агрегат | `status=success`, SQL с SUM, финальный ответ |
| 2 | "Топ-5 менеджеров по количеству обслуживаемых клиентов" | Top-N, сложнее | `status=success`, SQL с COUNT+ORDER+ROWNUM |
| 3 | "Какая погода будет завтра в Москве?" | Нерелевантный | `status=error`, отсечён relevance_checker |

## План

### Task 1: Проверить dev-окружение
```bash
source .venv/bin/activate && python dev/test-connection.py
```
**Done when:** Oracle OK, LLM OK

### Task 2: Создать мини-файл с 3 вопросами
Создать `dev/batch_smoke_test.json`:
```json
[
  "Какая общая сумма дохода за 2024 год?",
  "Топ-5 менеджеров по количеству обслуживаемых клиентов",
  "Какая погода будет завтра в Москве?"
]
```

### Task 3: Запустить batch
```bash
python run_batch.py --input dev/batch_smoke_test.json --output dev/batch_smoke_results.csv
```
**Ожидание:** ~2-5 минут (2 вопроса через LLM + SQL, 1 быстрый отказ)

### Task 4: Проверить результат CSV
Критерии проверки:
1. **Структура:** 14 колонок (EXPECTED_COLUMNS из batch_runner.py)
2. **Вопрос 1** (агрегат): `status=success`, `generated_sql` содержит SUM, `row_count > 0`, `final_answer` не пустой
3. **Вопрос 2** (top-N): `status=success`, несколько строк (подвопросы), SQL валидный
4. **Вопрос 3** (погода): `status=error`, `final_answer` содержит сообщение о нерелевантности
5. **Timings:** `top_timings_s` и `detail_timings_s` — валидный JSON, ненулевые значения
6. **batch_id:** одинаковый во всех строках
7. **created_at:** ISO timestamp

### Task 5: Дочистка
- Удалить `dev/batch_smoke_test.json` и `dev/batch_smoke_results.csv` (временные файлы теста)
- Или оставить results для анализа — на усмотрение

## Риски

| Сценарий | Вероятность | Действие |
|----------|-------------|----------|
| Ollama недоступен | Низкая | `dev/test-connection.py` поймает до запуска |
| Oracle недоступен | Низкая | То же |
| LLM timeout на одном вопросе | Средняя | Error isolation в BatchRunner — остальные обработаются |
| Некорректный SQL от LLM | Средняя | sql_validator делает до 3 попыток fix, partial result допустим |

## Масштаб

- **Новых файлов:** 1 (временный JSON с вопросами)
- **Изменений в коде:** 0
- **Время выполнения:** ~5-10 минут (включая LLM latency)
