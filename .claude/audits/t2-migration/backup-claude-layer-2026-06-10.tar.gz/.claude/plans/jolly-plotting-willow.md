# План: Унификация print/logger в точках входа (Option A)

## Контекст

Research-документ (2026-03-06-logging-and-user-notifications-architecture.md, проблема 4) зафиксировал несогласованное использование print/logger в точках входа. Рекомендация: **Option A — print() для user-facing вывода в entry points, logger для процессной логики**.

## Результат анализа

Все 4 entry-point файла **уже следуют Option A**:

| Файл | print() | logger | Соответствует? |
|------|---------|--------|----------------|
| `presentation/cli.py` | main() — валидация, баннер, ошибки | **импортирован, но НЕ используется** | ✓ (кроме dead import) |
| `presentation/batch_cli.py` | main() — валидация, прогресс, summary | **импортирован, но НЕ используется** | ✓ (кроме dead import) |
| `presentation/zulip_bot.py` | main() + run() — валидация, баннер | Класс-методы ZulipBot/ZulipLogger | ✓ |
| `application/agent.py` | run_console() — REPL UI | Процессная логика | ✓ |

**Единственная проблема**: cli.py и batch_cli.py импортируют `logging` и создают `logger`, но нигде его не используют — это мёртвый код.

## Задачи

### Task 1: Удалить неиспользуемый logger из cli.py и batch_cli.py
- **Files**: `presentation/cli.py`, `presentation/batch_cli.py`
- **Depends on**: none
- **Changes**:
  - cli.py: удалить `import logging` (line 5) и `logger = logging.getLogger(__name__)` (line 8)
  - batch_cli.py: удалить `import logging` (line 11) и `logger = logging.getLogger(__name__)` (line 14)
- **Done when**: ruff не находит unused imports, pytest проходит

### Task 2: Обновить research-документ — пометить проблему 4 как решённую
- **Files**: `docs/research/2026-03-06-logging-and-user-notifications-architecture.md`
- **Depends on**: Task 1
- **Changes**: Добавить пометку что Option A утверждена и код уже следует ей
- **Done when**: документ обновлён

### Task 3: Запись в devlog
- **Files**: `devlog/changelog.json`
- **Depends on**: Task 1-2
- **Done when**: запись добавлена

## Верификация

```bash
pytest tests/ -v  # все тесты проходят
ruff check presentation/cli.py presentation/batch_cli.py  # нет unused imports
```

## Оценка масштаба

- 2 файла с изменениями кода (удаление 2 строк в каждом)
- 1 документ обновлён
- 1 запись devlog
- 0 новых тестов (поведение не меняется)

## Риски

| Сценарий | Вероятность | Действие |
|----------|-------------|----------|
| Нет рисков — удаление dead code | — | — |
