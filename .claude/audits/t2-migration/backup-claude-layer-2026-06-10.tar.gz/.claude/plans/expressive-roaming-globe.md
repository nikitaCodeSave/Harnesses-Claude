# План: обновление значений DESK в проекте

## Контекст

На проде столбец DESK в таблице `client_product` изменился: вместо ФИО руководителей (Сафронов А., Борисов В., ...) теперь используются названия подразделений: `Region 1, International 1, International 2, Middle 1, FI, Large 1`. Нужно обновить тестовые данные и все ссылки в проекте.

## Маппинг (1:1 по сегменту)

| Сегмент (SEG) | Новый DESK |
|---------------|------------|
| Large | Large 1 |
| Middle | Middle 1 |
| International | International 1 или International 2 (random) |
| SME | Region 1 |
| FI | FI |
| Region | Region 1 |

## Шаги

### 1. `dev/generate_seed.py` — seed-генератор
**Строки 173-179:** заменить `DESK_OPTIONS`:
```python
DESK_OPTIONS = {
    "Large": ["Large 1"],
    "Middle": ["Middle 1"],
    "International": ["International 1", "International 2"],
    "SME": ["Region 1"],
    "FI": ["FI"],
    "Region": ["Region 1"],
}
```

### 2. `infrastructure/metadata.py` — описание поля DESK
**Строки 106-107:** обновить description и description_en — заменить ФИО на новые значения:
```
"description": "Подразделение (дэск, деск) обслуживающее клиента. Значения: Region 1, International 1, International 2, Middle 1, FI, Large 1.",
"description_en": "Department (desk) serving the client. Values: Region 1, International 1, International 2, Middle 1, FI, Large 1.",
```

### 3. `dev/setup-oracle.sql` — статические INSERT'ы
Заменить ФИО в строках значений:
- Клиент 1 (International) строки 76, 101: `'Воробьев А.'` → `'International 1'`
- Клиент 2 (Large) строки 126, 151: `'Сафронов А.'` → `'Large 1'`
- Клиент 3 (Middle) строки 176, 201: `'Карпунин М.'` → `'Middle 1'`

### 4. `dev/peek_table.md` — документация таблицы
**Строки 67-68, 102, 137-138, 198-205:** обновить примеры строк и список DESK'ов.

### 5. `tests/dev/test_generate_seed_regressions.py`
**Строка 192:** `"desk": "Сафронов А."` → `"desk": "Large 1"` (или другой валидный)

### 6. `.claude/commands/seed-data.md` — документация скилла
**Строки 75-82, 97:** обновить таблицу маппинга и список значений DESK.

### 7. `docs/research/monitoring/monitoring-integration-guide.md`
**Строки 236-237, 255:** обновить примеры ответов с "дэск Карпунин М." на новые значения.

### 8. Обновить данные в живой Oracle (dev) — UPDATE по сегменту
Каждый старый DESK обслуживал несколько сегментов, поэтому UPDATE делаем по SEG:
```sql
UPDATE client_product SET DESK = 'Large 1' WHERE SEG = 'Large';
UPDATE client_product SET DESK = 'Middle 1' WHERE SEG = 'Middle';
UPDATE client_product SET DESK = 'FI' WHERE SEG = 'FI';
UPDATE client_product SET DESK = 'Region 1' WHERE SEG = 'Region';
UPDATE client_product SET DESK = 'Region 1' WHERE SEG = 'SME';
-- International: распределяем 50/50 по ROWNUM
UPDATE client_product SET DESK = 'International 1' WHERE SEG = 'International' AND MOD(ROWID, 2) = 0;
UPDATE client_product SET DESK = 'International 2' WHERE SEG = 'International' AND DESK != 'International 1';
COMMIT;
```
Выполнить через Python-скрипт с OracleConnector (или вручную через sqlplus).

### 9. Создать `dev/update_desk_values.py` — одноразовый скрипт миграции
Скрипт для выполнения UPDATE'ов через OracleConnector. После выполнения можно удалить.

## Файлы, которые НЕ нужно менять

- `core/output/df_merger.py` — ссылается на DESK как ключ, без конкретных значений ✓
- `core/sql/prompts/v1/sql_generation.txt` — ссылается на DESK как столбец, не на значения ✓
- `tests/core/sql/test_validator.py` — тесты SQL-структуры, конкретные значения DESK не используются ✓
- `core/sql/validator.py` — работает с DESK как текстовым полем, без хардкода значений ✓

## Верификация

1. `pytest tests/dev/ -v` — тесты seed-генератора
2. `pytest tests/ -v` — все unit-тесты без регрессий
3. Выполнить `dev/update_desk_values.py` — обновить Oracle
4. Проверка: `SELECT DESK, SEG, COUNT(*) FROM client_product GROUP BY DESK, SEG ORDER BY DESK`
