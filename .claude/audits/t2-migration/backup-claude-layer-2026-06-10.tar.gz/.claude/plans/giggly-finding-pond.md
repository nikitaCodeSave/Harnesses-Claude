# План: промпт-фикс multi-month named range — Q26 stabilization

## Context

**Проблема (прод-валидация 2026-05-27):**
Вопрос Q26 «Выгрузи закрытых клиентов за **период февраль и март 2026** в помесячной разбивке...» нестабилен на всех текущих версиях промпта:

| Промпт | Q26 поведение |
|--------|--------------|
| Чистый baseline (HEAD коммит `2c11127`, 874 строки) | single-month: `CLOSE_DT BETWEEN '2026-02-01' AND '2026-02-28'` — partial answer, март упущен |
| Прод-`sql_generation_old.txt` (working tree, 1008 строк, актуальная прод-версия) | стохастически single-month / reasoning-loop |
| Feature HEAD `sql_generation.txt` (989 строк, с фиксами #128-#132) | reasoning-loop / empty SQL |

**Корневая причина** (подтверждена анализом промптов и `_build_temporal_examples`):
В worked-examples нет ни одного примера multi-month named range через союз «и» (формат Q26). Существующие шаблоны:
- ABSOLUTE PERIODS — single-month equality, per-quarter BETWEEN, per-year BETWEEN, «с … по …» BETWEEN.
- EVENT DATE FIELDS — single-month CLOSE_DT/CREATE_DT BETWEEN.

При формулировке «за X и Y» модель защитно копирует ближайший шаблон → single-month, либо уходит в reasoning-loop как «непокрытый случай».

**Связь с итерацией 2 (extraction):** итерация 2 (extraction.py + generator.py + subquestion.py + 6 тестов) — observability + safety net: 330с hang → 8с graceful retry. Итерация 2 завершена, проходит прод-валидацию. Данный план — **отдельная инициатива** для корректности Q26 (success rate), а не worst-case latency.

**Цель:** добавить в `_build_temporal_examples` ровно один (минимальный) шаблон multi-month named range через союз «и» в двух местах (MONTH_DT и CLOSE_DT), не модифицируя ни одной существующей строки. Критерий приёма — Q26 success rate ≥ 80% на N=20 прогонах с гарантированным отсутствием регрессии на контрольных Q12/Q15/Q24.

---

## Подход

### Единственная точка изменения — `_build_temporal_examples` в `core/sql/generator.py:155-202`

Функция возвращает список строк (`lines`), который склеивается в worked-examples блок и подставляется в `sql_generation.txt` через placeholder `{temporal_examples}`. Все примеры **уже** строятся динамически от `current_date` и `max_data_date` через утилиты `_shift_month()`, `_eom()`, `_MONTHS_NOM`, `_MONTHS_PREP`.

**Изменение 1.** В блок `ABSOLUTE PERIODS` (после строки `"• \"за {dy} год\" (current, unfinished) → ..."`) добавить:

```python
# Multi-month named range через союз "и" — покрывает Q26 формат.
# Использует месяц 2 назад (p2m) → месяц 1 назад (pm) — оба CLOSED.
f"• \"за {_MONTHS_NOM[p2m - 1]} и {_MONTHS_NOM[pm - 1]} {cy}\" "
f"(multi-month range — use BETWEEN, not single-month equality) → "
f"WHERE MONTH_DT BETWEEN DATE '{p2y}-{p2m:02d}-01' AND DATE '{prev_eom}'",
```

**Изменение 2.** В блок `EVENT DATE FIELDS` (после строки `"• \"создали клиентов в..."`) добавить:

```python
# Multi-month CLOSE_DT через союз "и" — снимает single-month прайм для Q26.
f"• \"закрыли счета в {_MONTHS_PREP[p2m - 1]} и {_MONTHS_PREP[pm - 1]} {cy}\" → "
f"WHERE CLOSE_DT BETWEEN DATE '{p2y}-{p2m:02d}-01' AND DATE '{prev_eom}'",
```

**Пример рендеринга для current_date=2026-05-27** (p2m=март, pm=апрель):
```
• "за март и апрель 2026" (multi-month range — use BETWEEN, not single-month equality) →
  WHERE MONTH_DT BETWEEN DATE '2026-03-01' AND DATE '2026-04-30'
• "закрыли счета в марте и апреле 2026" →
  WHERE CLOSE_DT BETWEEN DATE '2026-03-01' AND DATE '2026-04-30'
```

### Что НЕ трогаем (явный «do-not-touch» список)

| Файл | Причина не трогать |
|------|--------------------|
| `core/sql/prompts/v1/sql_generation.txt` | Per user-choice: «Только Python» — избегаем drift промпт-файлов, проще rollback |
| `core/sql/prompts/v1/sql_generation_old.txt` | Текущий прод-промпт пользователя — не наш scope |
| `core/sql/validator.py` (multi-period guards Iter 1, Часть B) | Они защищают от ложного collapse, не конфликтуют с новым шаблоном |
| Existing строки в `_build_temporal_examples` | Только `lines.append`-симметрия, ни одна existing строка не модифицируется |
| `application/subquestion.py` (retry-loop итерации 2) | Решает worst-case latency, ортогонально |

---

## Файлы

### Код (1 файл, ≤8 строк изменений)
- `core/sql/generator.py` — функция `_build_temporal_examples` (строки 155-202). Добавить 2 элемента в `lines` list (по 3-4 строки каждый, считая комментарий).

### Тесты (1 файл, ≤4 новых теста)
- `tests/core/sql/test_generator.py` (class `TestTemporalExamples`):

  1. **`test_multi_month_absolute_via_conjunction_uses_between`** — проверяет, что блок содержит строку с шаблоном `"за <m1> и <m2> <y>"` → `WHERE MONTH_DT BETWEEN DATE '<m1>-01-01' AND DATE '<m2>-EOM'`. Использует фиксированный `current_date` для воспроизводимости.

  2. **`test_multi_month_event_date_via_conjunction_uses_between`** — проверяет, что блок содержит строку с шаблоном `"закрыли счета в <m1> и <m2> <y>"` → `WHERE CLOSE_DT BETWEEN DATE '<m1>-01-01' AND DATE '<m2>-EOM'`.

  3. **`test_existing_single_month_absolute_examples_preserved`** — regression guard: проверяет наличие existing single-month equality примеров (CLOSED/CURRENT/FUTURE) в блоке. Защита от случайного удаления.

  4. **`test_existing_single_month_event_date_examples_preserved`** — regression guard: проверяет наличие existing single-month `CLOSE_DT BETWEEN month-start AND EOM` и `CREATE_DT BETWEEN ...` примеров.

Все тесты используют тот же паттерн, что existing тесты класса `TestTemporalExamples`: фиксированный `current_date`/`max_data_date`, вызов `_build_temporal_examples(...)`, поиск нужной строки через `self._line(block, needle)`.

### Devlog
- `devlog/changelog.json` — запись `id=135`, type=`config`, scope=[`core/sql/generator.py`, `tests/core/sql/test_generator.py`], related=`134` (extraction iter 2).

---

## Гарантии «не сломать остальное»

| Риск | Митигация в плане |
|------|--------------------|
| Удаление/модификация existing examples | **Только `lines.append`**: 2 новых элемента вставляются между существующими. Никаких `lines.remove`, `lines[N] = ...`, никакой правки текущих f-строк. |
| Перепрайм модели на multi-month там, где её не было | Примеры явно помечены `"за <m1> и <m2>"` (только формат с союзом). Single-month примеры остаются доминирующими в блоке (8+ existing vs 2 новых). |
| Конфликт с EXPLICIT RANGE правилом в `.txt` | `.txt` не трогаем. EXPLICIT RANGE правило в `sql_generation.txt:156-158` ссылается на «с/по», но не запрещает другие BETWEEN-шаблоны из worked-examples. |
| Конфликт с multi-period guards validator.py | Validator.py guard (Iter 1, Часть B) пропускает SQL с ≥2 разными MONTH_DT литералами — новый BETWEEN-шаблон с 2 датами под него не подпадает (один BETWEEN, не два equality). |
| Стохастика квантованной модели | Live-валидация N=20 на Q26 + N=5×3 на контрольных (см. Verification). |
| Регрессия на other classes (single-month, two-period compare) | Unit-тесты на preservation of existing examples (regression guards). Live A/B по success rate на контрольных. |

---

## Verification

### 1. Unit-тесты (TDD per `.claude/rules/development-workflow.md`)

```bash
.venv/bin/pytest tests/ -q                            # baseline (ожидание: 1362 passed)
# Написать failing tests (4 новых)
.venv/bin/pytest tests/core/sql/test_generator.py -v  # 4 fail
# Сделать изменения в _build_temporal_examples
.venv/bin/pytest tests/core/sql/test_generator.py -v  # 4 pass
.venv/bin/pytest tests/ -q                            # полная регрессия: 1366 passed
```

### 2. Live-валидация на dev (Oracle XE + Ollama), per user-choice N=20+5×3

```bash
.venv/bin/python dev/test-connection.py  # проверка подключений
```

**Q26 target** (N=20):
```bash
.venv/bin/python dev/prompt_lab.py \
  --question "Выгрузи закрытых клиентов за период февраль и март 2026 в помесячной разбивке с указанием ИНН клиентов, наименований, сегмента, принадлежности к управлению ФОИ КМ и причины закрытия" \
  --repeat 20 --max-data-date 2026-05-26 --current-date 2026-05-27 --no-validate
```

Критерии Q26:
- **success rate ≥ 80%** (16+/20 прогонов содержат `CLOSE_DT BETWEEN '2026-02-01' AND '2026-03-31'` или эквивалент с обоими месяцами).
- 0 reasoning-loop без SELECT-keyword (если такие есть — итерация 2 ловит как `empty_sql_graceful`, но регресс).
- 0 collapsed single-month (если есть — фикс не сработал, гипотеза неверна).

**Контрольные** (N=5 каждый):
- Q12 «Какие клиенты менеджера Логинов закрыли счета в феврале 2026?» — должен **сохранить** single-month `CLOSE_DT BETWEEN '2026-02-01' AND '2026-02-28'`. Регресс — если стал multi-month.
- Q15 «Какой среднедневной доход по FX (отдельно EUR, отдельно CNY) за март 2026...» — single-month MONTH_DT '2026-03-31' или BETWEEN '2026-03-01' AND '2026-03-31'.
- Q24 «Список клиентов сегмента Middle, у которых снизились депозиты в феврале 2026 по сравнению с январем 2026» — two-period LEFT JOIN, multi-period guard Iter 1 не должен false-positive.

Критерий по контрольным: **success rate не падает** (5/5 или 4/5, как до фикса).

### 3. Прод-валидация (пользователем)

Прогон 30 вопросов из `dev/validation/results/SQLextraction+Q15_1_multi-period_guards_prod-v2.csv` на боевой модели с обновлённым `_build_temporal_examples`.

Сравнение с baseline-prod-prompt-old.csv (текущий, чистый baseline 874):
- Q26: success rate должен подняться с **0/N** до **≥80%** (CLOSE_DT BETWEEN обоих месяцев).
- Q12, Q15, Q24, Q18-23 (вины итераций 1-2): без регрессии (success rate сохранён).
- Q10 Лукойл, остальные 25 вопросов: success rate ±5% (стохастика LLM).
- Любая регрессия (новый класс ошибок, увеличение empty_sql_graceful) → откат до решения причины.

### 4. Devlog + коммит

Per memory `feedback_prod_validation_workflow` — коммит **ТОЛЬКО** после успешной прод-валидации шага 3. До этого изменения остаются в working tree.

После прод-валидации:
- Devlog запись `id=135`.
- Коммит включает только `core/sql/generator.py` + `tests/core/sql/test_generator.py` + `devlog/changelog.json`. **Не** включает прокачку `sql_generation_old.txt` (это прод-промпт пользователя, не наш scope).

---

## Что НЕ входит в этот план (отдельные инициативы)

- **Расширение EXPLICIT RANGE правила** в `sql_generation.txt:156-158` на форматы «X и Y», «X-Y», «X, Y» — per user-choice «только Python».
- **Multi-month с тире «X-Y»** и **запятой «X, Y»** — per user-choice «только X и Y минимально».
- **Промоут feature HEAD `sql_generation.txt` → новый прод-baseline** — отдельная инициатива (sql-prompt-quality), требует N≥30 валидации.
- **Откат загрязнённого `sql_generation_old.txt`** в working tree (1008 → 874 строки) — пользователь подтвердил, что 1008-строчная версия — текущая прод. Отдельная задача синхронизации репо с прод-deploy.
- **`validate_duplicate_subqueries`** — детект LEFT JOIN с двумя идентичными подзапросами — отдельная инициатива.
- **Multi-month вариант CREATE_DT** — модель на Q26 использует CLOSE_DT; CREATE_DT в текущем наборе вопросов не имеет multi-month кейса. Добавим, если появится в проде.
