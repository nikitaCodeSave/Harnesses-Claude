# План: E2E калибровка промптов с реальным пайплайном

## Контекст

Текущий `dev/calibrate_prompts.py` измеряет токены **только** для одного промпта (`response_generator`), собирая его синтетически. Секция "Рекомендации" просто эхо-выводит текущие настройки без анализа.

Нужен инструмент, который:
1. Прогоняет **полный 8-шаговый пайплайн** (`process_question()`) с реальным вопросом
2. Перехватывает **все LLM-вызовы** через [PERF] логи из `llm_client.py`
3. Анализирует потребление токенов и выдаёт **конкретные рекомендации** для `.env`

Исследование: `docs/research/2026-03-02-llm-token-consumption-e2e-analysis.md`

## Что меняется

**Один файл:** `dev/calibrate_prompts.py` — полная перезапись.

## Архитектура нового инструмента

### Сбор данных: PerfLogCapture (logging.Handler)

Перехватывает [PERF] логи из `infrastructure.llm_client` (строки 189-200):
```
[PERF] LLM: 2.345s (op=sql_generation, model=GenAI/Qwen3-30B-A3B, prompt=38763, attempt=1,
status=ok, prompt_tokens=9690, completion_tokens=1333, total_tokens=11023)
```

Также перехватывает предупреждения о `finish_reason=length` (строки 181-186):
```
Ответ LLM обрезан по max_tokens=3000 (op=response_generation) — результат может быть неполным
```

Парсит regex → список `LLMCallMetric` dataclass'ов.

### Запуск: main()

```
python dev/calibrate_prompts.py                              # дефолтный вопрос
python dev/calibrate_prompts.py "Топ-10 клиентов по PnL"     # конкретный вопрос
python dev/calibrate_prompts.py --skip-files "вопрос"        # без файлов (быстрее)
```

1. Инициализация Settings + LLMClient
2. Подключение PerfLogCapture к логгеру `infrastructure.llm_client`
3. `AIAgent().process_question(question, skip_files=args.skip_files)`
4. Парсинг собранных метрик → отчёт → рекомендации

### Отчёт: print_report()

По каждому LLM-вызову:
```
  [1] question_analysis (attempt 1)
      Промпт: 14,529 символов → 3,632 токенов (4.0 chars/token)
      Ответ: 355 / 10,000 токенов (4% от max_tokens)
      Итого: 3,987 / 32,768 токенов (12.2% контекста)
      Время: 1.4s

  [2] sql_generation (attempt 1)
      Промпт: 38,763 символов → 9,690 токенов (4.0 chars/token)
      Ответ: 1,333 / 15,000 токенов (9% от max_tokens)
      ⚠ prompt + max_tokens = 24,690 > 32,768 × 0.8 (близко к лимиту!)
      Время: 9.2s
```

Суммарная секция:
```
  СУММАРНО: 5 вызовов LLM
    Промпт: 19,200 токенов
    Ответ: 3,800 токенов
    Время: 16.5s
    Средний ratio: 3.8 chars/token
```

### Рекомендации: print_recommendations()

Три категории анализа:

**1. Переполнение контекста** — `prompt_tokens + max_tokens > context_window`:
```
  ⚠ sql_generation: prompt(9690) + max_tokens(15000) = 24690 > context_window(32768) × 0.8
  → Рекомендация: AI_ANALYST_LLM__SQL_GEN_MAX_TOKENS=20000  (текущее: 15000)
    Или увеличить: AI_ANALYST_LLM__CONTEXT_WINDOW_TOKENS=40960
```

**2. Обрезка ответа** — `finish_reason=length` или `completion > max_tokens × 0.9`:
```
  ⚠ response_generation: completion(2850) использует 95% max_tokens(3000) — ответ обрезан!
  → Рекомендация: AI_ANALYST_LLM__RESPONSE_MAX_TOKENS=4500
```

**3. Неиспользуемый бюджет** — `completion < max_tokens × 0.2`:
```
  ℹ question_analysis: completion(355) использует 4% max_tokens(10000)
  → Можно уменьшить: AI_ANALYST_LLM__QA_ANALYZE_MAX_TOKENS=2000
```

**4. Калибровка char-лимитов** — `response_max_prompt_length` через measured chars/token:
```
  Измеренный ratio для response_generation: 3.8 chars/token
  Безопасный бюджет: (32768 - 3000) × 0.9 = 26791 токенов → 101806 символов
  → Рекомендация: AI_ANALYST_LLM__RESPONSE_MAX_PROMPT_LENGTH=101000  (текущее: 100000)
```

**5. Итоговый блок .env** — все рекомендованные значения в формате copy-paste:
```
  # Рекомендуемые значения (скопировать в .env):
  AI_ANALYST_LLM__RESPONSE_MAX_TOKENS=4500
  AI_ANALYST_LLM__QA_ANALYZE_MAX_TOKENS=2000
  AI_ANALYST_LLM__CONTEXT_WINDOW_TOKENS=32768
  AI_ANALYST_LLM__RESPONSE_MAX_PROMPT_LENGTH=101000
```

## Маппинг operation → settings

```python
OPERATION_SETTINGS = {
    "question_analysis":  ("qa_analyze_max_tokens",  "AI_ANALYST_LLM__QA_ANALYZE_MAX_TOKENS"),
    "sql_generation":     ("sql_gen_max_tokens",     "AI_ANALYST_LLM__SQL_GEN_MAX_TOKENS"),
    "sql_validation":     ("sql_fix_max_tokens",     "AI_ANALYST_LLM__SQL_FIX_MAX_TOKENS"),
    "sql_fix":            ("sql_fix_max_tokens",     "AI_ANALYST_LLM__SQL_FIX_MAX_TOKENS"),
    "response_generation":("response_max_tokens",    "AI_ANALYST_LLM__RESPONSE_MAX_TOKENS"),
    "final_response":     ("qa_response_max_tokens", "AI_ANALYST_LLM__QA_RESPONSE_MAX_TOKENS"),
    "chart_generation":   ("chart_gen_max_tokens",   "AI_ANALYST_LLM__CHART_GEN_MAX_TOKENS"),
    "chart_fix":          ("chart_fix_max_tokens",    "AI_ANALYST_LLM__CHART_FIX_MAX_TOKENS"),
    "code_generation":    ("python_gen_max_tokens",  "AI_ANALYST_LLM__PYTHON_GEN_MAX_TOKENS"),
    "code_fix":           ("python_fix_max_tokens",  "AI_ANALYST_LLM__PYTHON_FIX_MAX_TOKENS"),
}
```

## Ключевые файлы (только чтение, не изменяются)

- `infrastructure/llm_client.py:189-200` — формат [PERF] лога
- `infrastructure/llm_client.py:181-186` — warning о finish_reason=length
- `infrastructure/settings.py` — LLMSettings, DataDisplaySettings
- `application/agent.py:321` — `process_question(question, skip_files)`

## Проверка

1. `python dev/test-connection.py` — Oracle и Ollama доступны
2. `python dev/calibrate_prompts.py` — прогон с дефолтным вопросом
3. `python dev/calibrate_prompts.py "Покажи топ-5 клиентов по PnL"` — с конкретным вопросом
4. Проверить что рекомендации содержат конкретные значения, а не эхо текущих настроек
