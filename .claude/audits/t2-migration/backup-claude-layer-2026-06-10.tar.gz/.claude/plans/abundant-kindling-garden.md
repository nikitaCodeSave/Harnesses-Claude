# Fix: ИНН форматируется как число с сокращениями в PDF-таблицах

## Context

В PDF-таблицах поле ИНН (и другие ID-колонки) форматируются с сокращениями (млн, млрд). Например, ИНН `7770708389` отображается как `"7.77 млрд"`. Причина: `_prepare_table_data()` применяет `use_units=True` ко ВСЕМ ячейкам, а `should_use_unit_abbreviations()` не исключает ID-колонки при определении флага.

Research: `docs/research/2026-03-18-pdf-table-inn-formatting-bug.md`

## Затронутые файлы

| Файл | Изменение |
|------|-----------|
| `core/report/formatters.py` | `should_use_unit_abbreviations()` — исключить ID-колонки |
| `core/report/pdf_generator.py` | `_prepare_table_data()` — per-column `use_units` |
| `tests/core/report/test_formatters.py` | Тесты для `should_use_unit_abbreviations` |
| `tests/core/report/test_pdf_integration.py` | Тест для `_prepare_table_data` (зеркальная структура) |

## План (TDD)

### Task 1: Тесты для `should_use_unit_abbreviations` (RED)

**Файл:** `tests/core/report/test_formatters.py`

Добавить тесты:

1. `test_should_use_unit_abbreviations_excludes_id_columns` — DataFrame с `INN` (7770708389), без метрик → ожидание `False`. **Сейчас:** функция вернёт `True` (INN > 1e8) → **RED**
2. `test_should_use_unit_abbreviations_with_id_and_metric` — DataFrame с `INN` (7770708389) + `REVENUE_SUM` (50e9) → ожидание `True`. **Сейчас:** функция вернёт `True` → **GREEN сразу** (валидирует что метрики по-прежнему работают)
3. `test_should_use_unit_abbreviations_only_id_large` — DataFrame с `CUSTOMER_ID` (999999999) + `AMOUNT` (100) → ожидание `False`. **Сейчас:** функция вернёт `True` → **RED**

**Done when:** тесты 1 и 3 FAIL, тест 2 PASS

### Task 2: Fix `should_use_unit_abbreviations()` (GREEN)

**Файл:** `core/report/formatters.py:257-271`

Изменения:
- Добавить `from infrastructure.utils import is_id_column`
- Фильтровать `numeric_cols` через `is_id_column()` перед проверкой max

```python
def should_use_unit_abbreviations(df: pd.DataFrame) -> bool:
    numeric_cols = df.select_dtypes(include=[np.number]).columns
    # Исключить ID-колонки (INN, CUSTOMER_ID, *_ID)
    metric_cols = [c for c in numeric_cols if not is_id_column(c)]
    if len(metric_cols) == 0:
        return False
    max_values = df[metric_cols].abs().max()
    return bool(any(max_values > 1e8))
```

**Done when:** все 3 теста из Task 1 PASS + старые тесты не ломаются

### Task 3: Тест для `_prepare_table_data` (RED)

**Файл:** `tests/core/report/test_pdf_integration.py`

Добавить тест:

`test_prepare_table_data_inn_not_abbreviated` — DataFrame с `INN=7770708389` + `REVENUE_SUM=50_000_000_000`. Вызвать `_prepare_table_data(df)`. Проверить:
- Ячейка INN НЕ содержит "млрд"/"млн"
- Ячейка INN содержит "7770708389" (как строка с пробелами-разделителями или без)
- Ячейка REVENUE_SUM содержит "млрд" (метрика форматируется с сокращением)

**Сейчас:** INN будет "7.77 млрд" → **RED**

**Done when:** тест FAIL

### Task 4: Fix `_prepare_table_data()` — per-column formatting (GREEN)

**Файл:** `core/report/pdf_generator.py:37-57`

Изменения:
- Добавить `from infrastructure.utils import is_id_column`
- Итерировать с учётом имени колонки:

```python
columns = df_display.columns.tolist()
table_data = [columns]
for _, row in df_display.iterrows():
    formatted_row = [
        format_cell_value(val, use_units=(use_units and not is_id_column(col)))
        for col, val in zip(columns, row.values)
    ]
    table_data.append(formatted_row)
```

**Done when:** тест из Task 3 PASS + все остальные тесты PASS

### Task 5: Верификация и devlog

1. `pytest tests/ -v` — полный прогон unit-тестов, 0 failures
2. Запись в `devlog/changelog.json`

## Риски

| Сценарий | Вероятность | Действие |
|----------|-------------|----------|
| Таблица без метрик, только ID → `use_units=False` | low | Корректно — ожидаемое поведение |
| Сигнатура `format_cell_value` не меняется | — | Нет риска |
| `is_id_column` не ловит новый ID-тип | low | Покрыто `TestIdColumnsSync` в test_utils.py |

## Масштаб

- 2 файла кода, 2 файла тестов, 1 devlog
- ~4 новых теста
- Сигнатуры функций НЕ меняются
- ADR не требуется (bugfix)

## Дальнейшие шаги

После утверждения — `/implement` для выполнения плана с TDD workflow.
