# План: Обновить устаревшие ссылки system.txt → sql_generation.txt

## Контекст

Файл `core/sql/prompts/v1/system.txt` был переименован в `sql_generation.txt` (коммит feat: LIKE-constraint). Python-код обновлён, но в документации и skill-файле осталось ~20 ссылок на старое имя. VSCode пытается индексировать/открыть несуществующий файл, что вызывает ошибку.

## Файлы для обновления

### 1. `.claude/skills/oracle-patterns/SKILL.md` (активный skill — приоритет)
- Строка 26: `prompts/v1/system.txt` → `prompts/v1/sql_generation.txt`
- Строка 46: `core/sql/prompts/v1/system.txt` → `core/sql/prompts/v1/sql_generation.txt`

### 2. `docs/plans/BACKLOG.md`
- Строка 128: `core/sql/prompts/v1/system.txt` → `core/sql/prompts/v1/sql_generation.txt`
- Строка 141: пример с `system.txt` → `sql_generation.txt`

### 3. `docs/decisions/ADR-014-client-product-migration.md`
- Строка 28: ссылка на `system.txt`

### 4. `docs/decisions/ADR-010-sql-generator-decomposition.md`
- Ссылки на `system.txt` в описании структуры

### 5. Документы в `docs/research/` (4 файла)
- `2026-03-04-stopped-operations-regression.md` — описание переименования (можно оставить как есть — это историческая запись о самом переименовании)
- `2026-03-04-like-constraint-validation-gap.md`
- `2026-03-02-llm-token-consumption-e2e-analysis.md`
- `2026-02-24-new-table-client-product-migration.md`
- `2026-02-19-sql-generator-decomposition.md`

### 6. `docs/archive/plans/MIGRATION_PLAN_FINAL.md`
- Архивный план

### 7. `dev/settings_audit.md`
- Упоминание system.txt

## Подход

Обновить только **4 активных файла**. Research и archive — оставить как исторические записи.

### Изменения

1. **`.claude/skills/oracle-patterns/SKILL.md`** (строки 26, 46):
   - `system.txt` → `sql_generation.txt`

2. **`docs/plans/BACKLOG.md`** (строки 128, 141):
   - `system.txt` → `sql_generation.txt`

3. **`docs/decisions/ADR-014-client-product-migration.md`** (строка 28):
   - `system.txt` → `sql_generation.txt`

4. **`docs/decisions/ADR-010-sql-generator-decomposition.md`**:
   - `system.txt` → `sql_generation.txt` в описании структуры

### Не трогаем
- `docs/research/*` — исторические исследования
- `docs/archive/*` — архивные планы
- `dev/settings_audit.md` — аудит (историческая справка)

## Проверка

```bash
# Убедиться что в активных файлах не осталось ссылок
grep -r "system\.txt" --include="*.md" --exclude-dir=docs/research --exclude-dir=docs/archive --exclude-dir=dev
grep -r "system\.txt" --include="*.py"
# VSCode: Ctrl+Shift+P → "Developer: Reload Window" для сброса индекса
```
