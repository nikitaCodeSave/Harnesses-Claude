# Fix: дубль первого сообщения и WinError 233 на Windows

## Context

На Windows бот Zulip создаёт дубликат первого прогресс-сообщения. Причина: `send_message()` получает OSError (WinError 233 — разрыв named pipe), сообщение доставлено на сервер, но ответ потерян → `send_message()` возвращает `None` → `_message_id` остаётся `None` → следующий `_sync()` отправляет НОВОЕ сообщение вместо PATCH → дубликат.

## Решение: флаг `_send_attempted` в `ZulipProgressUpdater`

Ограничить попытки создания нового сообщения до 1. Если первая попытка не вернула `message_id`, не пытаться снова — принять потерю прогресса вместо дубликата.

## Изменения

### 1. `presentation/zulip_bot.py` — ZulipProgressUpdater

**`__init__`** (строка 42): добавить `self._send_attempted: bool = False`

**`_sync()`** (строки 95-96): добавить guard перед `send_message`:

```python
if self._message_id is None:
    if self._send_attempted:
        return  # Повторная отправка может создать дубликат (WinError 233)
    self._send_attempted = True
    self._message_id = self._bot.send_message(self._recipient_email, content)
```

Логика:
- Первый `_sync()`: `_send_attempted=False` → ставим True, вызываем `send_message()`
- Если send вернул id → `_message_id` установлен, дальше всё через `update_message`
- Если send вернул None (OSError) → `_message_id=None`, `_send_attempted=True`
- Все последующие `_sync()`: `_send_attempted=True` → `return` (не дублируем)
- **Linux**: без ошибок первый send успешен, поведение не меняется

### 2. `tests/presentation/test_zulip_logger.py`

**Новый тест** `test_first_send_failure_no_duplicate` в `TestSync`:
- `send_message` возвращает None → `_message_id` остаётся None
- Добавляем строки, вызываем `_sync()` ещё раз
- Проверяем: `send_message` вызван РОВНО 1 раз (нет дубля)

**Обновить** `test_sync_continues_after_error` в `TestSyncSuppression`:
- Старое поведение: после OSError второй `_sync()` повторяет send → `_message_id == 42`
- Новое поведение: после OSError второй `_sync()` НЕ повторяет send → `_message_id is None`, `send_message.call_count == 1`

## Проверка

1. `pytest tests/presentation/test_zulip_logger.py -v` — все тесты зелёные
2. `pytest tests/ -v` — нет регрессий
3. На Windows: бот не дублирует первое прогресс-сообщение при WinError 233
