# Plan: Настраиваемые параметры здоровья Oracle connection pool

## Контекст

На Windows-машине Zulip-бот получает ошибку `[WinError 233] С обоих концов канала отсутствуют процессы` при обработке вопросов после idle-периода (~5.5 мин). Ошибка не попадает в логи — значит возникает на уровне транспорта (named pipes) при работе с Oracle или сетью.

**Важная находка:** `oracledb.create_pool()` уже имеет `ping_interval=60` по умолчанию, но наш код не позволяет настраивать его и другие параметры здоровья пула (`timeout`, `max_lifetime_session`). Текущий `PoolSettings` содержит только `pool_min`, `pool_max`, `pool_increment`.

**Цель:** Сделать параметры здоровья пула настраиваемыми через `.env`, чтобы операторы на Windows могли тюнить `ping_interval` (уменьшить до 30с), `timeout` (убивать idle-соединения) и `max_lifetime_session` (принудительное обновление соединений).

## Затронутые файлы

| Файл | Изменение |
|------|-----------|
| `infrastructure/settings.py` | +3 поля в `PoolSettings` |
| `infrastructure/db_connector.py` | Прокинуть новые параметры в `oracledb.create_pool()` |
| `.env.example` | +3 переменные |
| `docs/configuration.md` | +3 параметра в таблицу |
| `tests/infrastructure/test_connection_pool.py` | Тесты прокидывания новых параметров |
| `devlog/changelog.json` | Запись об изменении |

## Задачи

### Task 1: Добавить параметры в PoolSettings
**Files:** `infrastructure/settings.py`
**Depends on:** none

Добавить в `PoolSettings`:
```python
ping_interval: int = Field(default=60, ge=0, le=300)      # 0 = disable
timeout: int = Field(default=0, ge=0, le=3600)             # секунды idle до kill, 0 = never
max_lifetime_session: int = Field(default=0, ge=0, le=86400)  # макс жизнь, 0 = unlimited
```

**Done when:** `get_settings().pool.ping_interval == 60`

### Task 2: Прокинуть параметры в create_db_pool
**Files:** `infrastructure/db_connector.py`
**Depends on:** Task 1

Добавить `ping_interval`, `timeout`, `max_lifetime_session` в сигнатуру `create_db_pool()` и передать в `oracledb.create_pool()`.

**Done when:** `oracledb.create_pool()` получает все 6 параметров

### Task 3: Тесты
**Files:** `tests/infrastructure/test_connection_pool.py`
**Depends on:** Task 2

- Тест: `create_db_pool` передаёт `ping_interval`, `timeout`, `max_lifetime_session` в `oracledb.create_pool`
- Тест: дефолтные значения из settings прокидываются корректно

**Done when:** `pytest tests/infrastructure/test_connection_pool.py -v` — PASS

### Task 4: Документация и devlog
**Files:** `.env.example`, `docs/configuration.md`, `devlog/changelog.json`
**Depends on:** Task 2

- `.env.example`: добавить 3 переменные с комментариями
- `docs/configuration.md`: добавить 3 строки в таблицу pool
- `devlog/changelog.json`: запись

**Done when:** документация отражает новые параметры

## Риски

| Сценарий | Вероятность | Действие |
|----------|-------------|----------|
| Дефолтные значения совпадают с oracledb — нет изменения поведения | — | Это фича, не баг. Изменения opt-in |
| Оператор ставит ping_interval=0, пул не пингует | low | Документировать что 0 = disable |

## Верификация

```bash
pytest tests/infrastructure/test_connection_pool.py -v
pytest tests/ -v  # регрессии
```

## Рекомендация для оператора на Windows

После деплоя — выставить в `.env`:
```
AI_ANALYST_POOL__PING_INTERVAL=30
AI_ANALYST_POOL__TIMEOUT=300
AI_ANALYST_POOL__MAX_LIFETIME_SESSION=1800
```
Это будет пинговать соединения каждые 30с, убивать idle >5мин, и пересоздавать соединения каждые 30мин.
