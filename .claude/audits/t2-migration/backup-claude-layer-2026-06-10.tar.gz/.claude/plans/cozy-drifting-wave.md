# Итерация 1: dataframe_to_digest — structured digest для NL-ответов

## Контекст

`dataframe_to_text()` преобразует DataFrame в `.to_string()` с truncation до max_rows. При >20 строках LLM теряет статистику по всему датасету: нет median, нет полных min/max по всем строкам, нет распределения текстовых полей. Замена на structured digest улучшит качество NL-ответов без дополнительных LLM-вызовов.

Источник: `docs/research/2026-02-27-llm-excessive-usage-analysis.md`, раздел 2.

> Фаза 0 пропущена: feature — новые функции, текущее поведение `dataframe_to_text` не меняется (остаётся для chart/code контекстов).

---

## Анализ воздействия

| Модуль | Изменение | Риск | Зависимые |
|--------|-----------|------|-----------|
| `core/output/response_generator.py` | +2 функции, замена вызова в `generate_response()` (строки 352, 454), обновление промпта (строки 507, 509) | medium | question_analyzer (импорт) |
| `core/analysis/question_analyzer.py` | Замена импорта и вызова в `generate_final_response()` (строка 460, 476) | low | — |
| `core/output/__init__.py` | Добавить экспорт новых функций | low | — |
| `tests/core/output/test_response_generator.py` | +27 новых тестов, проверка существующих | low | — |
| `tests/core/analysis/test_question_analyzer.py` | Обновить mock (строка ~435) | low | — |

**Что НЕ меняется:** `dataframe_to_text()`, `aggregate_remaining_rows()`, все вызовы в `code_generator.py` и `chart_generator.py`.

---

## Задачи

### Task 1: Написать TDD-тесты для `dataframe_to_digest()`
**Files:** `tests/core/output/test_response_generator.py`
**Depends on:** —

Класс `TestDataframeToDigest` (~17 тестов):
- Структура: возвращает dict с ключами `total_rows, columns, top_rows, numeric_stats, text_stats`
- `total_rows == len(df)` (полный, не truncated)
- `top_rows`: list[dict], `len <= max_rows`, для маленького df == все строки
- `numeric_stats`: каждый числовой столбец имеет `sum, mean, min, max, median, non_null`
- `numeric_stats` считается по ВСЕМ строкам (не только top_rows) — ключевой тест
- `text_stats`: `unique_values` (int), `top_5` (dict value→count, макс 5 записей)
- Edge cases: empty df, single row, mixed dtypes, NaN в числах и тексте, date-колонки исключены из text_stats

**Done when:** Все тесты написаны и FAIL (ImportError — функция не существует)

---

### Task 2: Написать TDD-тесты для `digest_to_prompt_text()`
**Files:** `tests/core/output/test_response_generator.py`
**Depends on:** —

Класс `TestDigestToPromptText` (~10 тестов):
- Возвращает str, содержит total_rows, список столбцов
- top_rows отрендерены как таблица (не сырой dict)
- Содержит numeric stats с median (ключевое улучшение)
- Содержит text stats с unique_values и top_5
- Empty digest → "Результат запроса пуст (нет данных)."
- `max_chars` параметр: при превышении сокращаются top_rows, не stats

**Done when:** Все тесты написаны и FAIL

---

### Task 3: Реализовать `dataframe_to_digest()`
**Files:** `core/output/response_generator.py` (после `dataframe_to_text`, ~строка 206)
**Depends on:** Task 1

```python
def dataframe_to_digest(df: pd.DataFrame, max_rows: int | None = None) -> dict:
```

- `max_rows` default из `settings.data_display.default_max_rows` (20)
- `top_rows`: `df.head(max_rows).to_dict(orient="records")`
- `numeric_stats`: `select_dtypes(include=[np.number])` → `sum, mean, min, max, median (np.nanmedian), non_null (count)`
- `text_stats`: non-numeric, non-date (использовать `is_date_column()`) → `nunique(), value_counts().head(5).to_dict()`
- Empty df → `{"total_rows": 0, "columns": [], "top_rows": [], "numeric_stats": {}, "text_stats": {}}`

**Done when:** Все тесты Task 1 PASS

---

### Task 4: Реализовать `digest_to_prompt_text()`
**Files:** `core/output/response_generator.py` (после `dataframe_to_digest`)
**Depends on:** Task 2, Task 3

```python
def digest_to_prompt_text(digest: dict, max_chars: int | None = None) -> str:
```

Формат вывода:
```
Количество строк в результате: 150
Столбцы: ORGANIZATION_NM, INCOME, CLIENTS

Первые 20 строк:
  ORGANIZATION_NM     INCOME    CLIENTS
  ООО Альфа          1500000     45
  ...

Статистика по числовым столбцам (все 150 строк):
  INCOME: сумма=1.5 трлн, среднее=6.7 млрд, мин=1 млн, макс=50 млрд, медиана=2 млрд, непустых=150

Статистика по текстовым столбцам:
  ORGANIZATION_NM: 150 уникальных, топ-5: Сбер (5), ВТБ (3), ...
```

- top_rows рендерить через `pd.DataFrame(top_rows).to_string(index=False)` — сохраняет привычное выравнивание для LLM
- `max_chars` default из `settings.data_display.default_max_chars`; при превышении — сокращать top_rows (не stats)
- NaN в stats → "N/A"

**Done when:** Все тесты Task 2 PASS

---

### Task 5: Заменить вызовы в `generate_response()` + обновить промпт
**Files:** `core/output/response_generator.py`
**Depends on:** Tasks 3, 4

Замены:
1. **Строка 352** (основной путь): `dataframe_to_text(df)` → `digest = dataframe_to_digest(df)` + `data_text = digest_to_prompt_text(digest)`
2. **Строки 454-456** (fallback): аналогично с `response_prompt_max_rows` / `response_prompt_max_chars`
3. **Строка 507** (правило #13): убрать "топ-20 записей и Прочее" → "Данные содержат первые строки и полную статистику (сумма, среднее, мин, макс, медиана). Используй статистику для обобщений."
4. **Строка 509** (правило #15): убрать "топ-20 клиентов... прочее" → "Если данных больше чем показано, уточни что полный список — в выгруженном файле."
5. Оба промпта (основной строки 383-439 и fallback строки 481-511) обновить одинаково

**Done when:** `generate_response()` использует digest; промпт не содержит "Прочее"/"топ-20"

---

### Task 6: Заменить вызов в `generate_final_response()` + обновить mock в тестах
**Files:** `core/analysis/question_analyzer.py`, `tests/core/analysis/test_question_analyzer.py`
**Depends on:** Tasks 3, 4

1. `question_analyzer.py:460`: заменить `from core.output.response_generator import dataframe_to_text` → импорт `dataframe_to_digest, digest_to_prompt_text`
2. `question_analyzer.py:476-478`: заменить вызов на digest-вариант
3. `test_question_analyzer.py`: обновить mock `dataframe_to_text` → mocks для `dataframe_to_digest` и `digest_to_prompt_text`

**Done when:** `generate_final_response()` использует digest; тесты question_analyzer проходят

---

### Task 7: Экспорт в `__init__.py` + полный прогон тестов
**Files:** `core/output/__init__.py`
**Depends on:** Tasks 3-6

1. Добавить `dataframe_to_digest, digest_to_prompt_text` в import и `__all__`
2. Запустить `pytest tests/ -v` — все 655+ тестов + ~27 новых должны пройти

**Done when:** Zero failures, zero errors

---

### Task 8: Live-тест + документация + devlog
**Files:** `devlog/changelog.json`, `docs/research/2026-02-27-llm-excessive-usage-analysis.md`
**Depends on:** Task 7

1. `python dev/test-connection.py` → OK
2. `python run_agent.py` → тестовые вопросы (простая агрегация, топ-N, большой результат)
3. Devlog entry #054
4. Пометить пункт 2 в research-документе как реализованный

**Done when:** Live-тест без ошибок; devlog обновлён

---

## Риски

| Сценарий | Вероятность | Действие |
|----------|-------------|----------|
| Digest-текст длиннее старого формата → промпт не влезает | low | `max_chars` параметр; stats ~50-100 символов на колонку, укладывается в бюджет |
| LLM хуже отвечает на новый формат | medium | Live-тест (Task 8). Откат: revert 2 вызова обратно на `dataframe_to_text()` |
| NaN → "nan" в тексте промпта | low | Явная обработка: `np.nanmedian`, форматирование "N/A" |
| top_rows через `pd.DataFrame().to_string()` падает на пустом списке | low | Guard: `if not digest["top_rows"]` → пропустить секцию |

**Откат:** Замена затрагивает 2 строки вызова (response_generator:352, question_analyzer:476). Revert = замена обратно на `dataframe_to_text()`. Функция `dataframe_to_text()` не удаляется.

---

## Масштаб

- **Файлов к изменению:** 5 (response_generator, question_analyzer, `__init__`, 2 тест-файла)
- **Новых функций:** 2 (`dataframe_to_digest`, `digest_to_prompt_text`)
- **Новых тестов:** ~27
- **Settings:** без изменений (используются существующие `data_display.*`)
- **Параллелизм:** Tasks 1 и 2 можно писать параллельно; Tasks 5 и 6 — параллельно после 3+4
- **Agent Teams:** не требуется (одна зона ответственности)

## Дальнейшие шаги

После утверждения → запустить реализацию. Для крупных задач с параллелизмом можно использовать `/implement`.
