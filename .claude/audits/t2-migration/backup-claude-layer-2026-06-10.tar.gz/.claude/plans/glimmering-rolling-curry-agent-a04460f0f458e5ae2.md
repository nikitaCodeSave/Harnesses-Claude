# Deep Research: Claude Code Enterprise Workflows & Best Practices

Research completed 2026-03-26. All sources verified by reading actual page content.

---

## SOURCE 1: Official Docs -- Best Practices

**URL:** https://code.claude.com/docs/en/best-practices

### Key Insights

**Context window is the #1 constraint.** Performance degrades as context fills. Every file read, command output, and message consumes tokens. Track usage with custom status line.

**The single highest-leverage practice: give Claude a way to verify its own work.** Tests, screenshots, expected outputs. Without success criteria, you become the only feedback loop.

**Four-phase workflow recommended:**
1. **Explore** (Plan Mode) -- read files, understand code without changes
2. **Plan** -- create detailed implementation plan, Ctrl+G to edit in text editor
3. **Implement** (Normal Mode) -- code against the plan, run tests
4. **Commit** -- descriptive message, open PR

**When to skip planning:** If you could describe the diff in one sentence, skip the plan. Planning overhead is only worth it for uncertain approaches, multi-file changes, or unfamiliar code.

### CLAUDE.md Guidance (Critical)

**What to include:**
- Bash commands Claude can't guess
- Code style rules that differ from defaults
- Testing instructions and preferred test runners
- Repo etiquette (branch naming, PR conventions)
- Architectural decisions specific to your project
- Developer environment quirks (required env vars)
- Common gotchas or non-obvious behaviors

**What to exclude:**
- Anything Claude can figure out by reading code
- Standard language conventions Claude already knows
- Detailed API documentation (link to docs instead)
- Information that changes frequently
- Long explanations or tutorials
- File-by-file descriptions of the codebase
- Self-evident practices like "write clean code"

**Key rule:** "If Claude keeps doing something you don't want despite having a rule against it, the file is probably too long and the rule is getting lost."

**Emphasis works:** Add "IMPORTANT" or "YOU MUST" to improve adherence.

**@import syntax:** `@path/to/import` for importing files into CLAUDE.md.

### Session Management

- `/clear` between unrelated tasks -- the most important habit
- After 2 failed corrections, `/clear` and rewrite prompt from scratch
- Use subagents for investigation to keep main context clean
- `/compact <instructions>` for targeted compaction (e.g., `/compact Focus on the API changes`)
- `/btw` for quick questions that don't enter conversation history
- `Esc + Esc` or `/rewind` to restore checkpoints (conversation, code, or both)

### Scaling Patterns

**Writer/Reviewer pattern:** Session A implements, Session B reviews with fresh context (not biased toward code it wrote).

**Fan-out pattern for migrations:**
```bash
for file in $(cat files.txt); do
  claude -p "Migrate $file from X to Y. Return OK or FAIL." \
    --allowedTools "Edit,Bash(git commit *)"
done
```

**Non-interactive mode:** `claude -p "prompt"` for CI, pre-commit hooks, scripts. `--output-format stream-json` for structured output.

### Anti-patterns (from official docs)

1. **Kitchen sink session** -- mixing unrelated tasks in one session
2. **Correcting over and over** -- context polluted with failed approaches
3. **Over-specified CLAUDE.md** -- too long, important rules get lost
4. **Trust-then-verify gap** -- plausible code that doesn't handle edge cases
5. **Infinite exploration** -- unscoped investigation fills context

---

## SOURCE 2: Official Docs -- Agent Teams

**URL:** https://code.claude.com/docs/en/agent-teams

### When to Use

**Best for:** research/review, new modules/features, debugging with competing hypotheses, cross-layer coordination (frontend/backend/tests).

**Not for:** sequential tasks, same-file edits, work with many dependencies. Use single session or subagents instead.

### Subagents vs Agent Teams

| Aspect | Subagents | Agent Teams |
|--------|-----------|-------------|
| Context | Own window, results return to caller | Own window, fully independent |
| Communication | Report back to main agent only | Message each other directly |
| Coordination | Main agent manages all | Shared task list, self-coordination |
| Best for | Focused tasks where only result matters | Complex work requiring discussion |
| Token cost | Lower (results summarized) | Higher (each is separate instance) |

### Configuration

Enable in settings.json:
```json
{
  "env": {
    "CLAUDE_CODE_EXPERIMENTAL_AGENT_TEAMS": "1"
  }
}
```

Display modes: `"in-process"` (default, any terminal) or `"tmux"` (split panes, requires tmux/iTerm2).

### Key Patterns

**Plan approval for risky work:** Teammates work in read-only plan mode until lead approves. Lead approves/rejects autonomously based on criteria you set: "only approve plans that include test coverage."

**Competing hypotheses debugging:** Spawn 5 teammates investigating different theories, actively trying to disprove each other. Overcomes anchoring bias of sequential investigation.

**Parallel code review:** 3 reviewers each with different lens (security, performance, test coverage). Single reviewers gravitate toward one issue type.

### Hooks for Quality Gates

- `TeammateIdle` -- runs when teammate is about to go idle. Exit code 2 = send feedback, keep working.
- `TaskCreated` -- runs when task created. Exit code 2 = prevent creation.
- `TaskCompleted` -- runs when task marked complete. Exit code 2 = prevent completion.

### Sizing Guidance

- **3-5 teammates** for most workflows
- **5-6 tasks per teammate** keeps everyone productive
- 15 independent tasks = 3 teammates is a good starting point

### Limitations (important)

- No session resumption with in-process teammates
- Task status can lag (teammates forget to mark complete)
- One team per session, no nested teams
- Lead is fixed for team lifetime
- All teammates start with lead's permission mode

### Storage

- Team config: `~/.claude/teams/{team-name}/config.json`
- Task list: `~/.claude/tasks/{team-name}/`

---

## SOURCE 3: Official Docs -- GitHub Actions

**URL:** https://code.claude.com/docs/en/github-actions

### Setup

Quickest: `claude /install-github-app` in terminal.

Manual: Install Claude GitHub app, add ANTHROPIC_API_KEY to repo secrets, copy workflow from examples/claude.yml.

### Basic Workflow

```yaml
name: Claude Code
on:
  issue_comment:
    types: [created]
  pull_request_review_comment:
    types: [created]
jobs:
  claude:
    runs-on: ubuntu-latest
    steps:
      - uses: anthropics/claude-code-action@v1
        with:
          anthropic_api_key: ${{ secrets.ANTHROPIC_API_KEY }}
```

### Key Parameters (v1)

| Parameter | Description |
|-----------|-------------|
| `prompt` | Instructions (optional, auto-responds to @claude mentions) |
| `claude_args` | CLI arguments: `--max-turns 5 --model claude-sonnet-4-6` |
| `anthropic_api_key` | API key (required for direct API) |
| `trigger_phrase` | Custom trigger (default: "@claude") |
| `use_bedrock` / `use_vertex` | Enterprise cloud providers |

### Scheduled Automation

```yaml
name: Daily Report
on:
  schedule:
    - cron: "0 9 * * *"
jobs:
  report:
    runs-on: ubuntu-latest
    steps:
      - uses: anthropics/claude-code-action@v1
        with:
          anthropic_api_key: ${{ secrets.ANTHROPIC_API_KEY }}
          prompt: "Generate a summary of yesterday's commits and open issues"
```

### Enterprise: AWS Bedrock / Google Vertex AI

Both supported via OIDC federation (no stored credentials). Bedrock model format: `us.anthropic.claude-sonnet-4-6`. Vertex requires Workload Identity Federation.

---

## SOURCE 4: Official Docs -- Scheduled Tasks

**URL:** https://code.claude.com/docs/en/scheduled-tasks

### Three Scheduling Options

| | Cloud | Desktop | /loop |
|---|---|---|---|
| Runs on | Anthropic cloud | Your machine | Your machine |
| Requires open session | No | No | Yes |
| Persistent across restarts | Yes | Yes | No |
| Minimum interval | 1 hour | 1 minute | 1 minute |

### /loop Syntax

```
/loop 5m check if the deployment finished and tell me what happened
/loop 20m /review-pr 1234
```
Default interval: 10 minutes. Session-scoped only (gone when you exit).

### One-Time Reminders

Natural language: `remind me at 3pm to push the release branch` or `in 45 minutes, check whether the integration tests passed`.

### Technical Details

- Max 50 scheduled tasks per session
- 3-day auto-expiry for recurring tasks
- All times in local timezone
- Jitter: recurring tasks fire up to 10% late (capped 15 min); one-shot tasks up to 90s early
- Disable entirely: `CLAUDE_CODE_DISABLE_CRON=1`

---

## SOURCE 5: Official Docs -- Skills

**URL:** https://code.claude.com/docs/en/skills

### Skill Structure

```
my-skill/
├── SKILL.md           # Main instructions (required)
├── template.md        # Template for Claude to fill in
├── examples/
│   └── sample.md      # Example output
└── scripts/
    └── validate.sh    # Script Claude can execute
```

### Frontmatter Reference

```yaml
---
name: my-skill
description: What this skill does and when to use it
disable-model-invocation: true  # Only manual /invoke
user-invocable: false           # Only Claude can invoke
allowed-tools: Read, Grep, Glob
model: opus
effort: max
context: fork                   # Run in subagent
agent: Explore                  # Which subagent type
paths: "*.py, src/**"           # File pattern trigger
---
```

### Key Patterns

**Reference content** (conventions, style guides): runs inline, Claude applies to current work.

**Task content** (deploy, commit): step-by-step instructions. Add `disable-model-invocation: true` for side-effect workflows.

### Dynamic Context Injection

```yaml
## Pull request context
- PR diff: !`gh pr diff`
- PR comments: !`gh pr view --comments`
```
Shell commands run before skill content is sent to Claude.

### Bundled Skills

| Skill | Purpose |
|-------|---------|
| `/batch <instruction>` | Parallel changes across codebase (worktrees) |
| `/claude-api` | Load Claude API reference |
| `/debug [description]` | Enable debug logging, troubleshoot |
| `/loop [interval] <prompt>` | Recurring prompts |
| `/simplify [focus]` | Review + fix code quality issues (3 parallel agents) |

### String Substitutions

- `$ARGUMENTS` -- all args passed to skill
- `$ARGUMENTS[N]` or `$N` -- specific arg by index
- `${CLAUDE_SESSION_ID}` -- current session ID
- `${CLAUDE_SKILL_DIR}` -- skill directory path

### Invocation Control

| Frontmatter | User can invoke | Claude can invoke |
|-------------|-----------------|-------------------|
| (default) | Yes | Yes |
| `disable-model-invocation: true` | Yes | No |
| `user-invocable: false` | No | Yes |

### Skill Locations

| Location | Path | Scope |
|----------|------|-------|
| Enterprise | Managed settings | All org users |
| Personal | `~/.claude/skills/<name>/SKILL.md` | All your projects |
| Project | `.claude/skills/<name>/SKILL.md` | This project only |
| Plugin | `<plugin>/skills/<name>/SKILL.md` | Where plugin enabled |

Priority: enterprise > personal > project.

---

## SOURCE 6: Skill Authoring Best Practices (Anthropic Platform Docs)

**URL:** https://platform.claude.com/docs/en/agents-and-tools/agent-skills/best-practices

### Core Principles

**Concise is key.** "Default assumption: Claude is already very smart. Only add context Claude doesn't already have." Challenge each piece: "Does Claude really need this explanation?"

**Degrees of freedom:**
- High freedom (text instructions): multiple approaches valid, context-dependent
- Medium freedom (pseudocode/scripts with params): preferred pattern exists
- Low freedom (specific scripts): fragile operations, consistency critical

### Description Writing

- Always third person ("Processes Excel files" not "I can help you")
- Include both what skill does AND when to use it
- Must be specific enough for Claude to choose from 100+ skills

### Naming Conventions

- Gerund form recommended: `processing-pdfs`, `analyzing-spreadsheets`
- Lowercase letters, numbers, hyphens only
- No reserved words: "anthropic", "claude"

### Progressive Disclosure

- Keep SKILL.md under 500 lines
- Reference files one level deep (not nested references)
- Files in skill directory are loaded on-demand, zero context penalty until read
- Longer reference files: add table of contents at top

### Evaluation-Driven Development

"Create evaluations BEFORE writing extensive documentation."
1. Run Claude on tasks without skill, document failures
2. Create 3 evaluation scenarios
3. Establish baseline without skill
4. Write minimal instructions to pass evals
5. Iterate

### Iterative Development with Two Claudes

- **Claude A** (expert): designs and refines the skill
- **Claude B** (user): tests skill on real tasks
- Observe Claude B's behavior, bring insights back to Claude A
- Each iteration improves based on observed behavior, not assumptions

### Anti-patterns

- Windows-style paths (use forward slashes always)
- Too many options ("use pdfplumber or PyMuPDF or pypdf or...")
- Time-sensitive information
- Inconsistent terminology
- Deeply nested file references
- Magic numbers in scripts without justification

---

## SOURCE 7: "How Anthropic Teams Use Claude Code" (Official PDF)

**URL:** https://www-cdn.anthropic.com/58284b19e702b49db9302d5b6f135ad8871e7658.pdf

### Data Infrastructure Team

**Key workflows:**
- Feed screenshots of dashboards for K8s debugging (visual diagnosis)
- Plain text workflow files for non-technical finance team
- New hires use Claude Code to navigate codebase (replaces data catalogs)
- End-of-session documentation updates (continuous CLAUDE.md improvement loop)

**Tips:**
- Write detailed CLAUDE.md files -- "the better you document, the better Claude performs"
- Use MCP servers instead of CLI for sensitive data (better security control)
- Hold team demo sessions to share workflows

### Product Development Team (Claude Code itself)

**Key workflows:**
- Auto-accept mode (Shift+Tab) for rapid prototyping with autonomous loops
- Start from clean git state, commit checkpoints regularly
- 70% of Vim mode feature was autonomous Claude work
- GitHub Actions to auto-address PR comments

**Tips:**
- **Create self-sufficient loops** -- set up Claude to verify via builds, tests, lints
- **Develop task classification intuition** -- peripheral features async, core business logic sync
- **Form clear, detailed prompts** -- especially when components have similar names

### Security Engineering Team

**Key workflows:**
- Feed stack traces + docs for incident debugging (10-15 min -> 5 min)
- Copy Terraform plans for security review ("Am I going to regret this?")
- Ingest multiple doc sources -> create markdown runbooks
- TDD workflow: pseudocode first -> guide through TDD -> periodic check-ins

**Tips:**
- Use custom slash commands extensively (50% of all custom commands in their monorepo)
- Let Claude work autonomously ("commit as you go") with periodic check-ins
- Use it for documentation synthesis (structured outputs for Slack, Google Docs)

### Inference Team

**Key workflows:**
- Codebase comprehension for onboarding (find files/functions in seconds vs. manually searching)
- Unit test generation with edge cases (Claude handles tedious edge case thinking)
- Cross-language code translation (explain what to test, Claude writes in Rust)

**Tips:**
- Test knowledge base functionality first (is Claude faster than Google for your domain?)
- Start with code generation to build trust
- Use it for test writing (relieves significant mental burden)

### Data Science & ML Engineering

**Key workflows:**
- Build 5,000-line TypeScript apps despite minimal JS knowledge (visualization dashboards)
- "Slot machine" approach: commit state, let Claude run 30 min, accept or restart fresh
- Permanent React dashboards instead of throwaway Jupyter notebooks

**Tips:**
- **"Treat it like a slot machine"** -- save state, let it run, accept or start fresh. Starting over often beats wrestling with corrections.
- **Interrupt for simplicity** -- stop Claude and say "try something simpler." Model tends toward complex solutions.

### Growth Marketing Team (Non-technical)

**Key workflows:**
- Agentic workflow: CSV with hundreds of ads -> identify underperformers -> generate new variations (30-char headlines, 90-char descriptions)
- Two specialized sub-agents (one for headlines, one for descriptions)
- Figma plugin for mass creative production (100 variations in half a second)
- Meta Ads MCP server for campaign analytics

**Tips:**
- Identify API-enabled repetitive tasks
- Break workflows into specialized sub-agents (improves quality over single prompt)
- Brainstorm and prompt plan before coding (use Claude.ai to plan, then Claude Code to execute)

### Product Design Team (Non-developers)

**Key workflows:**
- Direct front-end polish (typefaces, colors, spacing) without engineer round-trips
- GitHub Actions automated ticketing (file issues, Claude proposes code)
- Paste mockups -> functional prototypes
- Edge case discovery during design phase (error states, logic flows)

**Tips:**
- Get engineering help for initial setup
- Custom memory files: "I'm a designer with little coding experience who needs detailed explanations and smaller changes"
- Paste screenshots directly for prototyping

### RL Engineering Team

**Key workflows:**
- "Try and rollback" methodology -- frequent checkpoints, revert if needed
- Supervised autonomy: Claude takes lead, human steers when off track
- Works on first attempt ~1/3 of the time for small-medium PRs

**Tips:**
- **Customize CLAUDE.md for repeated mistakes:** "run pytest not run and don't cd unnecessarily"
- **Checkpoint-heavy workflow:** commit regularly so experiments are reversible
- **Try one-shot first, then collaborate:** quick prompt first, if it works (1/3 of the time) you saved significant time

---

## SOURCE 8: Spec-Driven Development

**URL:** https://alexop.dev/posts/spec-driven-development-claude-code-in-action/

### Core Pattern

1. **Parallel Research** -- "spin up multiple subagents for your research task"
2. **Spec Creation** -- comprehensive markdown spec becomes source of truth
3. **Spec Refinement** -- AskUserQuestion interview to surface ambiguities
4. **Task Delegation** -- TaskCreate/TaskUpdate with subagent per task, commit after each

### Task System

Tasks persist in `.claude/tasks/{session-id}/` as JSON:
```json
{
  "id": "task-1",
  "subject": "Create idb-helpers.ts",
  "status": "pending | in_progress | completed",
  "blocks": ["task-3", "task-4"],
  "blockedBy": ["task-0"]
}
```

Shared task lists across sessions via env:
```json
{ "env": { "CLAUDE_CODE_TASK_LIST_ID": "myproject" } }
```

### Critical Success Factors

- **Role assignment:** "you are the main agent and your subagents are your devs"
- **Backpressure via pre-commit hooks:** typecheck + lint + test in pre-commit prevents bug accumulation
- **Spec as recovery point:** when session goes sideways, pin spec document + paste error = immediate fix
- **Dependency-aware parallelism:** blocks/blockedBy fields, execute in waves

### Real Results

- 14 tasks completed, 14 commits, 15+ files changed in one afternoon
- Main session context: 143k/200k tokens (71% used) -- no accumulated cruft

---

## SOURCE 9: TDD with Claude Code Subagents

**URL:** https://alexop.dev/posts/custom-tdd-workflow-claude-code-vue/

### Architecture: 3-Layer Enforcement

1. **Skill** (orchestrator): `.claude/skills/tdd-integration/SKILL.md` defines RED->GREEN->REFACTOR gates
2. **Subagents** (specialists): separate agents for test-writer, implementer, refactorer
3. **Hooks** (enforcement): `UserPromptSubmit` hook forces skill evaluation before any implementation

### Why Subagents Are Essential for TDD

"When everything runs in one context window, the LLM cannot truly follow TDD because the test writer's detailed analysis bleeds into the implementer's thinking."

Each agent starts with exactly the context it needs and nothing more.

### Subagent Specs

**tdd-test-writer:** Write failing test, run it, confirm failure, return path + failure output.
- Tools: Read, Glob, Grep, Write, Edit, Bash
- Can preload a `vue-integration-testing` skill

**tdd-implementer:** Minimal code to pass test. "Fix implementation, not tests."
- Principles: minimal, no extras, test-driven

**tdd-refactorer:** Evaluate and improve. Checklist: extract composable, simplify conditionals, improve naming, remove duplication, thin components.
- Decision criteria: refactor when clear duplication, reusable logic, unclear naming

### Hook for Activation (Critical)

Without hook: skill activation ~20%. With `UserPromptSubmit` hook: ~84%.

The hook injects a mandatory evaluation step:
```
Step 1 - EVALUATE: For each skill, state YES/NO with reason
Step 2 - ACTIVATE: Call Skill() tool for each relevant skill
Step 3 - IMPLEMENT: Only after Step 2, proceed
```

---

## SOURCE 10: 30 Tips for Agent Teams (Community)

**URL:** https://getpushtoprod.substack.com/p/30-tips-for-claude-code-agent-teams

### Most Actionable Tips

1. **Specify models per teammate** -- debugger on Opus, UI on Sonnet, simple tasks on Haiku. Controls costs.
2. **Require plans before implementation** -- without upfront scoping, agents diverge randomly and waste tokens.
3. **Guide lead's approval criteria** -- "Maintain a very high quality bar for code. Tell all subagents to maintain this standard."
4. **Tell lead to wait** -- orchestrators sometimes implement instead of delegating. Redirect: "Delegate this to teammates."
5. **Start with read-only tasks** -- investigations, research, code review. Zero file conflicts.
6. **Monitor and steer** -- don't set agents loose without oversight. They derail with extended unsupervised operation.
7. **Save task lists locally** -- plan ahead, save lists, have teams pick up next tasks on return.
8. **Hooks for lifecycle events** -- `teammate_idle` and `task_complete` can trigger Notion/Slack/Jira updates.

---

## SOURCE 11: Addy Osmani on Agent Teams

**URL:** https://addyosmani.com/blog/claude-code-agent-teams/

### Key Lessons

- **Activity does not equal value.** Watching agents work in parallel is compelling, but "commits per hour" doesn't guarantee correct, maintainable code.
- **Let the problem guide tooling.** If a single focused session solves the problem faster, use that.
- **File ownership matters.** Prevent merge conflicts by giving each teammate distinct files. Mirrors human team boundary-setting.
- **Better specs = better output.** Vague briefs hurt quality.
- **Human management skills directly translate** to effective agent orchestration: task sizing, clear ownership boundaries, context loading precision.

---

## SOURCE 12: Spec-Driven Development Framework

**URL:** https://github.com/Pimzino/claude-code-spec-workflow

### Workflow Structure

**New Features:** Requirements -> Design -> Tasks -> Implementation
- Initiate: `/spec-create feature-name "description"`
- Auto-generates: user stories, technical design, atomic task breakdown, task executor commands

**Bug Fixes:** Report -> Analyze -> Fix -> Verify
- Commands: `/bug-create`, `/bug-analyze`, `/bug-fix`, `/bug-verify`

### Steering Documents

Three foundational docs ensuring consistency:
1. **Product Document:** vision, target users, features, success metrics
2. **Technology Document:** stack, practices, constraints, integrations
3. **Structure Document:** file organization, naming conventions, code principles

### Key Technical Feature

**60-80% token reduction** through universal context sharing via `get-steering-context`, `get-spec-context`, `get-template-context` commands.

---

## SYNTHESIS: Actionable Patterns for This Project

### What the research shows consistently works:

1. **CLAUDE.md brevity is critical.** Multiple sources confirm: bloated files cause Claude to ignore rules. Only include what Claude can't infer. Prune regularly.

2. **Hooks > instructions.** For mandatory behavior, use hooks (deterministic) not CLAUDE.md rules (advisory). The TDD study showed activation jumped from 20% to 84% with hooks.

3. **Subagents for investigation, not implementation in same context.** Keep main session lean. Subagents explore in separate context, report back summaries.

4. **Spec-first for complex features.** Research -> spec -> interview -> tasks -> subagent implementation. Spec serves as recovery point when sessions go sideways.

5. **Pre-commit hooks as backpressure.** typecheck + lint + test prevents bug accumulation across tasks.

6. **"Slot machine" approach for autonomous work.** Commit state, let Claude run, accept or restart fresh. Starting over often beats wrestling with corrections.

7. **Task classification intuition.** Peripheral/prototyping = async auto-accept. Core business logic = synchronous supervision.

8. **Agent teams for 3+ independent parallel tasks.** But not for sequential work or same-file edits. 3-5 teammates, 5-6 tasks each.

9. **Writer/Reviewer pattern.** Session A implements, Session B reviews with fresh context. Eliminates self-bias.

10. **GitHub Actions for @claude PR automation.** `anthropics/claude-code-action@v1` with `claude_args` for CLI passthrough.

### What does NOT work:

- Unscoped "investigate X" prompts (fills context with irrelevant files)
- Correcting Claude more than twice (context pollution; /clear and restart)
- Agent teams for sequential dependencies
- TDD in single context window (test-writer analysis bleeds into implementer)
- CLAUDE.md longer than what Claude actively follows
- Nested file references in skills (Claude may only partially read)
- Setting agents loose without oversight

---

Sources:
- [Best Practices -- Official](https://code.claude.com/docs/en/best-practices)
- [Agent Teams -- Official](https://code.claude.com/docs/en/agent-teams)
- [GitHub Actions -- Official](https://code.claude.com/docs/en/github-actions)
- [Scheduled Tasks -- Official](https://code.claude.com/docs/en/scheduled-tasks)
- [Skills -- Official](https://code.claude.com/docs/en/skills)
- [Skill Authoring Best Practices -- Anthropic Platform](https://platform.claude.com/docs/en/agents-and-tools/agent-skills/best-practices)
- [How Anthropic Teams Use Claude Code -- PDF](https://www-cdn.anthropic.com/58284b19e702b49db9302d5b6f135ad8871e7658.pdf)
- [Spec-Driven Development in Action](https://alexop.dev/posts/spec-driven-development-claude-code-in-action/)
- [TDD with Claude Code Subagents](https://alexop.dev/posts/custom-tdd-workflow-claude-code-vue/)
- [30 Tips for Agent Teams](https://getpushtoprod.substack.com/p/30-tips-for-claude-code-agent-teams)
- [Claude Code Swarms -- Addy Osmani](https://addyosmani.com/blog/claude-code-agent-teams/)
- [Spec Workflow Framework](https://github.com/Pimzino/claude-code-spec-workflow)
