# План: детекция вложенных агрегатов (nested aggregates)

## Контекст

LLM генерирует `AVG(SUM(CA_LCY_RUB_SUM))` вместо subquery-паттерна. Oracle возвращает ORA-00937 ("not a single-group group function"). Промпт генерации (system.txt) содержит правильные примеры с subquery (строки 248–280), но LLM всё равно ошибается. Нет ни детерминированной проверки, ни анти-паттерна, ни секции ORA-00937 в fix-промпте.

**Цель:** поймать nested aggregates на этапе валидации (до DB) и дать LLM-фиксеру конкретную инструкцию с правильным паттерном.

---

## Task 1: Тесты (TDD red phase)

**File:** `tests/core/sql/test_validator.py`
**Depends on:** none

Новый класс `TestValidateNestedAggregates` + один интеграционный тест в `TestValidateAndFixSql`.

Тесты:
- `test_no_aggregates_returns_none` — `SELECT * FROM t` → None
- `test_single_aggregate_returns_none` — `SUM(PNL_SUM)` → None
- `test_avg_sum_at_depth_0_returns_error` — `AVG(SUM(x))` → строка с ошибкой
- `test_sum_count_at_depth_0_returns_error` — `SUM(COUNT(*))` → строка с ошибкой
- `test_count_distinct_sum_detected` — `COUNT(DISTINCT SUM(x))` → ошибка
- `test_valid_subquery_pattern_returns_none` — `AVG(x) FROM (SELECT SUM(...))` → None
- `test_nested_in_subquery_not_flagged` — nested agg внутри подзапроса (depth>0) → None
- `test_two_separate_aggregates_not_flagged` — `SUM(...), COUNT(*)` рядом → None
- `test_aggregate_in_string_literal_ignored` — `'SUM(COUNT(*))'` → None
- `test_error_message_contains_function_names` — проверка содержимого ошибки
- `test_multiple_violations_all_reported` — две вложенности → обе в сообщении
- `test_nested_agg_triggers_llm_fix` — `validate_and_fix_sql` запускает LLM fix при nested aggregate (mock call_llm, проверка mock_llm.called)

**Done when:** все тесты FAIL (функции ещё нет).

---

## Task 2: Реализация validate_nested_aggregates + интеграция

**Files:** `core/sql/validator.py`
**Depends on:** Task 1

### 2a. Новая regex-константа (после `_AGGREGATE_PATTERN`, строка 35):

```python
_NESTED_AGG_RE = re.compile(
    r"""\b(SUM|COUNT|AVG|MAX|MIN)\s*\(\s*(?:DISTINCT\s+)?(SUM|COUNT|AVG|MAX|MIN)\s*\(""",
    re.IGNORECASE,
)
```

### 2b. Новая функция `validate_nested_aggregates(sql) -> str | None` (~30 строк):

Алгоритм:
1. `_mask_string_literals(sql)` — маскировка строковых литералов (уже есть, строка 155)
2. `_NESTED_AGG_RE.finditer(masked)` — поиск вложенных агрегатов
3. Early return None если нет совпадений
4. `_compute_effective_depth(masked)` — depth для каждой позиции (уже есть, строка 60)
5. Фильтр: оставить только matches с `effective_depth[match.start()] == 0`
6. Если пусто → None. Иначе → сообщение об ошибке

Формат ошибки:
```
Обнаружены вложенные агрегатные функции: AVG(SUM(...)). Oracle не допускает
вложенные агрегаты (ORA-00937). Используй подзапрос: SELECT AVG(x)
FROM (SELECT SUM(...) AS x FROM ... GROUP BY ...)
```

### 2c. Интеграция в `validate_and_fix_sql` (строка 848, else-блок):

```python
    else:
        # --- Фаза 1.5: Проверка вложенных агрегатов (детерминированная) ---
        nested_agg_error = validate_nested_aggregates(sql)
        if nested_agg_error:
            error_message = nested_agg_error
            logger.error("Вложенные агрегаты: %s", error_message)
        else:
            # --- Фаза 2: LIKE-constraint fix ---
            sql, like_modified = validate_like_constraints(sql)
            ...
            # --- Фаза 3: DB validation ---
            ...
```

**Почему между Phase 1 и Phase 2:**
- Phase 1 (syntax) должна пройти первой — иначе regex на позициях ненадёжен
- LIKE-fix не нужен на сломанном запросе — сначала LLM исправит агрегаты
- Детерминированная ошибка даёт LLM конкретный паттерн исправления (лучше чем ORA-00937 от EXPLAIN PLAN)

**Done when:** все тесты из Task 1 GREEN.

---

## Task 3: Обновление промптов

**Files:** `core/sql/validator.py` (fix-промпт), `core/sql/prompts/v1/system.txt`
**Depends on:** Task 2

### 3a. Секция ORA-00937 в fix-промпте (после строки 681, перед `{history_section}`):

```
Вложенные агрегатные функции (ORA-00937):
- Oracle НЕ допускает вложенные агрегаты: SUM(COUNT(*)), AVG(SUM(x)), MAX(COUNT(*)).
- Переписать с использованием ПОДЗАПРОСА:
  - Было: SELECT SUM(COUNT(*)) FROM client_product GROUP BY MONTH_DT
  - Стало: SELECT SUM(cnt) FROM (SELECT COUNT(*) AS cnt FROM client_product GROUP BY MONTH_DT)
- Внутренний подзапрос ДОЛЖЕН содержать GROUP BY из исходного запроса.
- Сохрани ВСЕ условия WHERE из исходного запроса в подзапросе.
```

### 3b. Анти-паттерн в system.txt (после строки 227, после "NEVER override this metadata rule"):

```
❌ ANTI-PATTERN — NEVER USE NESTED AGGREGATES:
Oracle does NOT support nested aggregate functions like AVG(SUM(x)), SUM(COUNT(x)) etc.
This will cause ORA-00937. ALWAYS use a subquery instead (see examples 3.1–3.3 below).
```

**Done when:** промпты обновлены, тесты из Task 1 всё ещё GREEN.

---

## Task 4: Верификация и постобработка

**Depends on:** Task 3

1. `pytest tests/core/sql/test_validator.py -v` — все тесты зелёные
2. `pytest tests/ -v` — регрессий нет
3. Запись в `devlog/changelog.json`

**Done when:** 0 failures, devlog обновлён.

---

## Оценка рисков

| Сценарий сбоя | Вероятность | Воздействие | Действие |
|---|---|---|---|
| Regex ловит false positive (строковый литерал) | low | LLM fix цикл на валидном SQL | `_mask_string_literals` уже решает; тест покрывает |
| Regex пропускает edge case (CASE WHEN внутри) | low | Не поймает — EXPLAIN PLAN поймает | Консервативный подход, Phase 3 — safety net |
| Вложенный else увеличивает indentation | low | Читаемость | Минимальное — один уровень |
| LLM не исправляет nested agg с первой попытки | medium | 2-3 итерации фикса | Конкретное сообщение об ошибке + пример в fix-промпте минимизируют |

**Откат:** `git checkout core/sql/validator.py core/sql/prompts/v1/system.txt tests/core/sql/test_validator.py`

---

## Масштаб

- **Файлы:** 3 (validator.py, system.txt, test_validator.py) + devlog
- **Новый код:** ~35 строк функции + ~5 строк интеграции + ~15 строк промптов + ~3 строки system.txt
- **Тесты:** ~12 тестов (~80 строк)
- **Параллелизация:** не нужна, задачи последовательные (TDD)
- **Agent Teams:** не нужны

## Дальнейшие шаги

После утверждения — `/implement` для выполнения по TDD workflow.
