# Plan: SQL-Aware Aggregation Semantics (Approach D)

## Context

**Проблема:** Когда SQL содержит `AVG(CA_LCY_SUM) AS avg_balance`, DataFrame получает колонку `avg_balance`. Функция `_get_column_aggregation_rules()` не может матчить alias `avg_balance` с metadata-полем `CA_LCY_SUM` → LLM не получает предупреждений об агрегации → LLM суммирует средние и выдаёт некорректные ответы ("общий объём 5.3 млрд" вместо "среднее 529.8 млн").

**Решение (Подход D):** Новая функция `_extract_aggregation_semantics(sql)` — полнотекстовый поиск metadata-полей в SQL через `\bFIELD_NAME\b` regex. Для полей с `aggregation_between_month` не SUM/N/A формирует предупреждения и добавляет к `fields_description` в промпте.

**Масштаб:** 1 новая функция (~30 строк) + 2 строки интеграции + ~8 unit-тестов + 1 integration-тест. Затронут один файл `response_generator.py` и его тесты.

> Фаза 0 пропущена: наблюдение зафиксировано в research-документе (docs/research/2026-03-27-sql-aware-aggregation-semantics-implementation.md), проблема полностью описана с примерами.

## Impact Analysis

| Модуль | Текущее поведение | Изменение | Риск |
|--------|-------------------|-----------|------|
| `response_generator.py` | `_get_column_aggregation_rules()` пустой для alias-колонок | Новая `_extract_aggregation_semantics(sql)` ищет metadata-поля в SQL полнотекстово | low |
| `generate_response()` | `fields_description` без предупреждений об агрегации | += aggregation semantics после resolve fields_description | low |
| `_RESPONSE_PROMPT_TEMPLATE` | Без изменений | — | none |
| Callers (subquestion.py, reports.py) | Без изменений | — | none |

## Tasks

### Task 1: RED — Тесты для `_extract_aggregation_semantics()` (TDD)
- **Files:** `tests/core/output/test_response_generator.py`
- **Depends on:** nothing
- **What:**
  - Добавить import `_extract_aggregation_semantics`
  - Новый класс `TestExtractAggregationSemantics` с 8 тестами:
    1. `test_returns_empty_for_sql_without_metadata_fields` — `"SELECT 1 FROM dual"` → `""`
    2. `test_returns_empty_for_sum_only_fields` — SQL с `FX_VOLUME_RUB` (month=SUM) → `""`
    3. `test_returns_warning_for_avg_field` — SQL с `CA_LCY_SUM` → содержит `CA_LCY_SUM`, `AVG`, warning emoji
    4. `test_returns_warning_for_max_field` — SQL с `ACT_1M` → содержит `ACT_1M`, `MAX`
    5. `test_multiple_fields_multiple_warnings` — SQL с `CA_LCY_SUM` и `DEP_SUM` → оба
    6. `test_field_in_where_clause_detected` — `WHERE CA_LCY_SUM > 1000` → обнаружено
    7. `test_case_insensitive_matching` — `ca_lcy_sum` lowercase → работает
    8. `test_returns_empty_for_empty_sql` — `""` → `""`
- **Done when:** Тесты написаны и падают с ImportError/AttributeError

### Task 2: GREEN — Реализация `_extract_aggregation_semantics()`
- **Files:** `core/output/response_generator.py` (после line 69, перед `is_date_column`)
- **Depends on:** Task 1
- **What:**
  - Чистая функция `_extract_aggregation_semantics(sql: str) -> str`
  - Итерация по metadata fields: пропуск если `agg_month in ("N/A", "SUM")`
  - `re.search(rf"\b{field_name}\b", sql_upper)` — полнотекстовый поиск
  - Формирование warnings с `_AGG_LABELS` (reuse), category, emoji
  - Возврат `""` если нет warnings, иначе `"\n\nПравила агрегации...\n- field1...\n- field2..."`
- **Done when:** `pytest tests/core/output/test_response_generator.py::TestExtractAggregationSemantics -v` — 8/8 PASS

### Task 3: Интеграция в `generate_response()` + integration test
- **Files:** `core/output/response_generator.py` (lines 886-889), `tests/...`
- **Depends on:** Task 2
- **What:**
  - 2 строки после line 886: `if sql: fields_description += _extract_aggregation_semantics(sql)`
  - 1 integration test `test_aggregation_semantics_in_prompt`: mock LLM, вызов с alias SQL, assert `CA_LCY_SUM` и `AVG` в промпте
- **Done when:** `pytest tests/core/output/test_response_generator.py -v` — all PASS, включая новые

### Task 4: Верификация и постобработка
- **Depends on:** Task 3
- **What:**
  - Полный прогон unit-тестов: `pytest tests/ -v`
  - Обновить devlog/changelog.json
- **Done when:** Все unit-тесты зелёные, devlog обновлён

## Risks

| Сценарий | Вероятность | Действие |
|----------|-------------|----------|
| Regex false positive (имя поля совпадает с SQL keyword) | Very Low | 5 целевых полей (`CA_LCY_SUM`, `CA_LCY_RUB_SUM`, `DEP_SUM`, `ACT_1M`, `ACT_3M`) специфичны, `\b` предотвращает substring-матчи |
| Prompt budget overflow от добавленного текста | Very Low | Максимум ~300 chars для всех 5 полей; каскадная обрезка `_build_prompt_within_budget` не трогает `fields_description` |
| Caller передаёт `fields_description` + `sql` | None | Работает корректно — append к существующей строке |

## Scope
- **Файлов к изменению:** 2 (`response_generator.py`, `test_response_generator.py`)
- **Новых тестов:** 9 (8 unit + 1 integration)
- **Рекомендация:** последовательное выполнение (TDD: RED → GREEN → integrate)

## Next Steps
После утверждения → `/implement` для выполнения с TDD workflow.
