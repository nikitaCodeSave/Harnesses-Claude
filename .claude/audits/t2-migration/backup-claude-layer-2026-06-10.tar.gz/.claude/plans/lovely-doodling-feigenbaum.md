# План: типизированные прогресс-события

## Context

Сейчас `ZulipLogger.emit()` решает о flush через substring matching: ищет `[Шаг`, `[Подвопрос]`, `✅`, `❌`, `⚠️` в тексте сообщения. Это хрупко — любое изменение текста может сломать flush-логику. Замена на типизированные события (`ProgressEventType`) делает решение о flush явным и независимым от содержимого сообщений.

## Архитектурное решение

**Почему `NamedTuple`, а не `BaseModel`:** `ProgressEvent` создаётся на каждый `_emit` вызов (десятки за вопрос). NamedTuple — zero-overhead, immutable, не тянет pydantic в hot path.

**Почему `make_progress_emit()` в `application/progress.py`, а не изменение `make_emit()` в `infrastructure/utils.py`:** Избежать circular import (infrastructure не должен импортировать из application). `make_emit()` остаётся без изменений.

## Файлы и изменения

### Task 1: Модель + фабрика (`application/progress.py`)
- `ProgressEventType(str, Enum)`: STEP, SUBSTEP, STATUS, INFO
- `ProgressEvent(NamedTuple)`: type + message
- `IMMEDIATE_TYPES = frozenset({STEP, SUBSTEP, STATUS})`
- `make_progress_emit(callback: Callable[[ProgressEvent], None] | None) -> Callable[[str, ProgressEventType], None]`
  - `None` → print fallback (через `make_emit(None)`)
  - callback → оборачивает в `ProgressEvent` и вызывает callback
- Удалить `STEP_PREFIX`, `SUBSTEP_PREFIX`
- **Depends on:** nothing
- **Done when:** `pytest tests/application/test_progress.py -v` — PASS

### Task 2: Тесты модели (`tests/application/test_progress.py` — новый)
- `test_progress_event_type_values` — enum values
- `test_progress_event_creation` — NamedTuple fields
- `test_immediate_types_correctness` — STEP/SUBSTEP/STATUS in, INFO not in
- `test_make_progress_emit_none_prints` — print fallback
- `test_make_progress_emit_callback_wraps_event` — callback получает ProgressEvent
- `test_make_progress_emit_default_info` — без event_type → INFO
- `test_make_progress_emit_explicit_type` — STEP type preserved
- **Depends on:** Task 1
- **Done when:** все тесты PASS

### Task 3: ZulipLogger (`presentation/zulip_bot.py`)
- `emit(self, event: ProgressEvent)` вместо `emit(self, message: str)`
- `message = event.message` в начале метода
- Flush: `event.type in IMMEDIATE_TYPES` вместо 5 substring checks
- Импорт: `from application.progress import ProgressEvent, IMMEDIATE_TYPES` (убрать STEP_PREFIX, SUBSTEP_PREFIX)
- **Depends on:** Task 1
- **Done when:** `pytest tests/presentation/test_zulip_logger.py -v` — PASS

### Task 4: Тесты ZulipLogger (`tests/presentation/test_zulip_logger.py`)
- Добавить тесты flush-логики:
  - `test_emit_flushes_on_step_event`
  - `test_emit_flushes_on_status_event`
  - `test_emit_buffers_info_event`
  - `test_emit_info_with_emoji_no_flush` — INFO с "✅" в тексте НЕ вызывает flush (regression guard)
- `_should_skip_line` тесты — без изменений
- **Depends on:** Task 3
- **Done when:** все тесты PASS

### Task 5: Producers — agent.py, subquestion.py, reports.py (параллельно)
Для каждого файла:
- Импорт `from application.progress import make_progress_emit, ProgressEventType`
- Замена `make_emit(...)` → `make_progress_emit(...)`
- Добавить второй аргумент ко всем `_emit()` вызовам по маппингу:

**agent.py** — `on_progress: Callable[[ProgressEvent], None] | None`:
| Вызов | Тип |
|-------|-----|
| `"ОБРАБОТКА ВОПРОСА"` | INFO |
| `"[Шаг N] действие..."` | STEP |
| `"[Шаг N] ✅/❌/⚠️ ..."` | STATUS |
| `"▶ ПЕРЕХОД К ПОДВОПРОСУ"` | SUBSTEP |
| `"Подвопрос: ..."`, `"  {i}. ..."`, info-строки | INFO |
| `"  - SQL/Данные/График: ✅/❌"` | STATUS |

**subquestion.py** — `emit: Callable[[ProgressEvent], None] | None`:
| Вызов | Тип |
|-------|-----|
| `"[Подвопрос] 📝 Шаг N/5: ..."` | SUBSTEP |
| `"[Подвопрос] ✅/❌/⚠️ ..."` | STATUS |

**reports.py** — `emit: Callable[[ProgressEvent], None] | None`:
| Вызов | Тип |
|-------|-----|
| `"[Шаг N] ГЕНЕРАЦИЯ..."` | STEP |
| `"[Шаг N] ✅/❌/⚠️ ..."` | STATUS |
| `"[Шаг N] ⏭️ пропущено"` | INFO |

- **Depends on:** Task 1
- **Done when:** `pytest tests/application/ -v` — PASS

### Task 6: batch_cli.py
- `presentation/batch_cli.py:115` — `on_progress=lambda msg: None` → `on_progress=lambda event: None`
- **Depends on:** Task 5
- **Done when:** grep подтверждает изменение

### Task 7: Обновление тестов
- `tests/application/test_callback.py` — callback получает `ProgressEvent`, не `str`; lambda → `lambda event: emit_calls.append(event.message)`
- `tests/application/test_agent_methods.py` — аналогично для emit_count тестов
- `tests/infrastructure/test_utils.py` — `TestMakeEmit` без изменений (make_emit не меняется)
- **Depends on:** Task 5
- **Done when:** `pytest tests/ -v` — все unit-тесты PASS

### Task 8: Devlog
- Запись в `devlog/changelog.json`
- **Depends on:** Task 7

## Параллелизация

- Task 1 → {Task 2, Task 3, Task 5} параллельно
- Task 3 → Task 4
- Task 5 → {Task 6, Task 7} параллельно
- Task 7 → Task 8

## Оценка масштаба

| Метрика | Значение |
|---------|----------|
| Файлов изменить | 7 (progress.py, zulip_bot.py, agent.py, subquestion.py, reports.py, batch_cli.py, changelog.json) |
| Файлов тестов изменить | 2 (test_callback.py, test_agent_methods.py) |
| Файлов тестов создать | 1 (test_progress.py), дополнить 1 (test_zulip_logger.py) |
| ~40 _emit() вызовов | добавить второй аргумент |

## Риски

| Сценарий | Вероятность | Воздействие | Действие |
|----------|-------------|-------------|----------|
| Пропущен _emit вызов без event_type | low | INFO по умолчанию — безопасный fallback, не flush | grep `_emit(` без второго аргумента после реализации |
| batch_cli забыт | low | TypeError при запуске batch | grep `on_progress=lambda` |
| Тесты с MagicMock ломаются из-за новой сигнатуры | medium | test failures | Обновить все callback-моки в Task 7 |

## Верификация

1. `pytest tests/ -v` — все unit-тесты проходят
2. `grep -rn "STEP_PREFIX\|SUBSTEP_PREFIX" --include="*.py"` — нигде не используется
3. `grep -rn '_emit(' application/ | grep -v 'ProgressEventType'` — все вызовы типизированы (кроме make_progress_emit internals)
4. Live-тест (опционально): `python run_agent.py` — прогресс отображается как раньше
