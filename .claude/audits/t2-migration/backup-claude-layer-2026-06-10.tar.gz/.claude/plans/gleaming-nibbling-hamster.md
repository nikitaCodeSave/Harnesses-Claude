# Fix: chart_builder отображает INN как числовую метрику на графиках

## Context

При e2e прогоне пайплайна (вопрос "Покажи топ-5 организаций по сумме PnL за последний месяц") chart_builder строит grouped bar chart, где INN (10-значный ИНН — идентификатор, не метрика) отображается как числовой столбец рядом с PNL_SUM. INN-значения (~6-7 млрд) визуально доминируют над PNL_SUM (~3-5 млн), делая график бессмысленным.

**Корневая причина:** `_detect_chart_type()` (строка 156) вызывает `df.select_dtypes(include="number")`, который включает все числовые колонки без исключения ID-полей. Затем все 12 Rules классификации используют этот неочищенный `numeric_cols`.

**Проблемные поля:** `INN` (NUMBER, is_key=True), `CUSTOMER_ID` (NUMBER). Затрагиваются Rules 4, 11, 12 и `_pick_best_numeric_col`.

## Решение

Гибридный фильтр ID-колонок: константа с известными именами + паттерн суффиксов `_ID`. Фильтрация применяется один раз в `_detect_chart_type()` — на источнике `numeric_cols`, что автоматически исправляет все 12 Rules.

Подход скопирован с `df_merger.py:KNOWN_KEYS` — захардкоженная константа в `core/` с sync-тестом против `metadata.py`.

## Файлы

| Файл | Действие |
|------|----------|
| `core/output/chart_builder.py` | Добавить `_ID_COLUMN_NAMES`, `_is_id_column()`, фильтр в `_detect_chart_type()` |
| `tests/core/output/test_chart_builder.py` | Добавить тесты: sync, unit для `_is_id_column`, classification с ID-колонками |

## Задачи

### Task 1: Тесты (TDD — красные)
- **Files:** `tests/core/output/test_chart_builder.py`
- **Depends on:** none
- **Что добавить:**
  - `TestIsIdColumn` — 7 unit-тестов для `_is_id_column()` (INN/CUSTOMER_ID/lowercase/suffix/metric/middle/total)
  - `TestIdColumnExclusion` — 5 тестов на классификацию (INN excluded from STRUCTURE_WIDE, GROUPED_BAR, BAR_VERTICAL; only-ID fallback; date+INN+metric → LINE)
  - `TestIdColumnsSync` — sync-тест: все NUMBER-поля из metadata категории "Идентификация клиента" должны быть в `_ID_COLUMN_NAMES`
- **Done when:** тесты написаны, pytest собирает их, TestIsIdColumn и TestIdColumnExclusion FAIL (красные)

### Task 2: Реализация фильтра
- **Files:** `core/output/chart_builder.py`
- **Depends on:** Task 1
- **Что добавить:**
  1. Константа `_ID_COLUMN_NAMES = {"INN", "CUSTOMER_ID"}` (после строки ~40, рядом с `_TOTAL_KEYWORDS`)
  2. Константа `_ID_COLUMN_SUFFIXES = ("_ID",)`
  3. Функция `_is_id_column(col_name: str) -> bool` — проверка по имени (upper) и суффиксу
  4. В `_detect_chart_type()` строка 156: заменить `numeric_cols = df.select_dtypes(...)` на фильтрацию через `_is_id_column`
  5. **Без fallback восстановления.** Если все numeric колонки — ID, `numeric_cols` будет пуст → Fallback (строка 282) вернёт `KPI_CARD` с `y_cols=[]` → `_draw_kpi_card` покажет "Количество записей". Это корректно — лучше честный "нет метрик" чем мусор с INN.
- **Done when:** все новые тесты PASS (зелёные), все существующие тесты PASS

### Task 3: Верификация и постобработка
- **Files:** devlog/changelog.json
- **Depends on:** Task 2
- **Что сделать:**
  1. `pytest tests/core/output/test_chart_builder.py -v` — все тесты зелёные
  2. `pytest tests/ -v` — полный прогон, нет регрессий
  3. Live e2e: `echo "Покажи топ-5 организаций по сумме PnL" | python run_agent.py` — проверить что INN убран с графика
  4. Визуально проверить `output/chart_1.png` — только PNL_SUM на оси Y
  5. Добавить запись в devlog/changelog.json
- **Done when:** тесты зелёные, live-график корректный, devlog обновлён

## Риски

| Сценарий | Вероятность | Воздействие | Действие |
|----------|-------------|-------------|----------|
| Суффикс `_ID` ловит метрику (напр. `GRID_ID`) | Low | Метрика исключена из графика | В metadata.py нет таких полей; при появлении — добавить в whitelist |
| Все numeric — ID (напр. `SELECT INN FROM ...`) | Low | KPI_CARD "Количество записей" | Корректное поведение — numeric_cols пуст → Fallback KPI_CARD с y_cols=[] |
| Новое NUMBER ID-поле в metadata | Low | Попадёт в график | Sync-тест упадёт → напомнит обновить `_ID_COLUMN_NAMES` |

## Масштаб

- 2 файла, ~20 строк кода + ~70 строк тестов
- 0 изменений сигнатур, 0 новых зависимостей
- Последовательное выполнение (Task 1 → 2 → 3)
