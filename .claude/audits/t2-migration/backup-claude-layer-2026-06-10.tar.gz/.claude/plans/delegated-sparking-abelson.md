# Plan: validate_like_constraints() — детерминированная постобработка LIKE в SQL

## Context

**Проблема:** Когда пользователь спрашивает о конкретном клиенте/группе/организации, LLM генерирует SQL с `UPPER(FIELD) LIKE '%...'` в WHERE для фильтрации, но иногда забывает включить это LIKE-поле в SELECT и GROUP BY. Проблема затрагивает только запросы с LIKE — остальные SQL работают корректно.

**Почему не ловится:** EXPLAIN PLAN проверяет только синтаксис — запрос без LIKE-поля в SELECT синтаксически корректен. Промпт содержит ABSOLUTE LIKE RULE, но LLM нарушает его из-за перегруженности (~600 строк инструкций).

**Результат бага:** пользователь получает одну агрегированную строку без разбивки по искомому полю — ответ бесполезен.

**Решение:** детерминированная функция `validate_like_constraints(sql)` в validator.py. Срабатывает ТОЛЬКО на SQL с LIKE в WHERE, где LIKE-поле отсутствует в SELECT/GROUP BY. Запросы без LIKE не затрагиваются. 0 LLM-вызовов, ~80 строк кода.

Исследование: `docs/research/2026-03-04-like-constraint-validation-gap.md`

---

## Task 1: Написать тесты (TDD — RED)

**Files:** `tests/core/sql/test_validator.py`
**Depends on:** none

Добавить `from core.sql.validator import validate_like_constraints` в импорты.

Новый класс `TestValidateLikeConstraints` с тест-кейсами:

| # | Тест | Суть |
|---|------|------|
| 1 | `test_no_like_returns_unchanged` | SQL без LIKE → `(sql, False)` |
| 2 | `test_like_field_missing_from_select_added` | LIKE-поле есть в GROUP BY, но нет в SELECT → добавлено в SELECT |
| 3 | `test_like_field_missing_from_group_by_added` | LIKE-поле есть в SELECT, агрегация, но нет GROUP BY → создан GROUP BY |
| 4 | `test_like_field_missing_from_both_added` | Нет ни в SELECT, ни в GROUP BY при агрегации → добавлено в оба |
| 5 | `test_like_field_already_present_unchanged` | Уже в SELECT и GROUP BY → `(sql, False)` |
| 6 | `test_multiple_like_fields` | Два LIKE-поля → оба добавлены |
| 7 | `test_select_star_skipped` | `SELECT *` → не трогаем |
| 8 | `test_no_aggregation_select_only` | Нет агрегатов → добавлено только в SELECT, GROUP BY не создаётся |
| 9 | `test_plain_like_without_upper` | `FIELD LIKE` без UPPER() → тоже обрабатывается |
| 10 | `test_select_distinct_handled` | `SELECT DISTINCT` → поле вставляется после DISTINCT |
| 11 | `test_like_in_string_literal_ignored` | `'UPPER(X) LIKE'` внутри строкового литерала → игнорируется |
| 12 | `test_returns_tuple` | Возвращает `tuple[str, bool]` |

**Done when:** `pytest tests/core/sql/test_validator.py::TestValidateLikeConstraints -v` → все 12 тестов RED (ImportError или AssertionError).

---

## Task 2: Реализовать validate_like_constraints()

**Files:** `core/sql/validator.py`
**Depends on:** Task 1

### Константы (после строки 21, после `_strip_string_literals`)

```python
_LIKE_PATTERN = re.compile(
    r"""(?:(?:UPPER|LOWER)\s*\(\s*(\w+)\s*\)|(\w+))\s+LIKE\s""",
    re.IGNORECASE,
)
_AGGREGATE_PATTERN = re.compile(
    r"""\b(?:SUM|COUNT|AVG|MAX|MIN)\s*\(""",
    re.IGNORECASE,
)
```

### Приватные функции (~50 строк)

- `_extract_like_fields(sql_clean: str) -> list[str]` — regex-поиск LIKE-полей, дедупликация, работает только на глубине скобок = 0 (WHERE внешнего запроса)
- `_has_select_star(sql_clean: str) -> bool` — `SELECT *` или `SELECT DISTINCT *`
- `_field_in_clause(field: str, clause: str) -> bool` — `\bFIELD\b` в тексте
- `_insert_into_select(sql: str, field: str) -> str` — вставка после `SELECT ` / `SELECT DISTINCT `
- `_insert_into_group_by(sql: str, field: str) -> str` — добавить в существующий GROUP BY или создать новый (перед ORDER BY / FETCH FIRST / концом)

### Публичная функция

```python
def validate_like_constraints(sql: str) -> tuple[str, bool]:
    """Проверяет и исправляет LIKE-ограничения: поле из WHERE LIKE должно быть в SELECT и GROUP BY."""
```

Алгоритм:
1. `sql_clean = _strip_string_literals(sql, " ")` — для анализа
2. `like_fields = _extract_like_fields(sql_clean)` — поля из `UPPER(X) LIKE` / `X LIKE`
3. Если нет LIKE-полей или SELECT * → `(sql, False)`
4. `has_aggregates = bool(_AGGREGATE_PATTERN.search(sql_clean))`
5. Для каждого поля: проверить в SELECT, если отсутствует — `_insert_into_select()`; если агрегация и нет в GROUP BY — `_insert_into_group_by()`
6. После каждой мутации пересчитать `sql_clean`
7. Вернуть `(sql, modified)`

### Переиспользуемые компоненты

- `_strip_string_literals()` (validator.py:17) — уже есть
- Regex-паттерн из `test_metadata.py:102-104` — адаптирован в `_LIKE_PATTERN`

**Done when:** `pytest tests/core/sql/test_validator.py::TestValidateLikeConstraints -v` → все 12 тестов GREEN.

---

## Task 3: Интегрировать в validate_and_fix_sql()

**Files:** `core/sql/validator.py`, `tests/core/sql/test_validator.py`
**Depends on:** Task 2

### Точка вставки

В `validate_and_fix_sql()` после строки 487 (конец блока `if not is_valid: ... return sql, False`) и ДО строки 489 (`if db_executor is not None:`):

```python
    # LIKE-constraint fix (детерминированный, без LLM)
    sql, like_modified = validate_like_constraints(sql)
    if like_modified:
        logger.info("LIKE-поля добавлены в SELECT/GROUP BY")
```

### Тест интеграции

Добавить в `TestValidateAndFixSql`:

```python
def test_like_constraints_applied_before_db_validation(self):
    """validate_and_fix_sql применяет LIKE-fix для синтаксически валидного SQL."""
    sql = "SELECT SUM(PNL_SUM) FROM client_product WHERE UPPER(GROUP_NM) LIKE '%' || UPPER('test') || '%'"
    result_sql, is_valid = validate_and_fix_sql(sql, "test question", db_executor=None)
    assert is_valid
    assert "GROUP_NM" in result_sql.split("FROM")[0]  # в SELECT
    assert "GROUP BY" in result_sql.upper()
```

**Done when:** `pytest tests/core/sql/test_validator.py -v` → все тесты GREEN (существующие + новые).

---

## Task 4: Регрессия, devlog

**Files:** `devlog/changelog.json`
**Depends on:** Task 3

1. `pytest tests/ -v` → все 854+ тестов GREEN
2. Запись в `devlog/changelog.json`

**Done when:** Полный прогон тестов без ошибок, devlog обновлён.

---

## Анализ рисков

| Сценарий | Вероятность | Воздействие | Действие |
|----------|-------------|-------------|----------|
| Regex ложно срабатывает на LIKE в подзапросе | low | Добавит лишнее поле в внешний SELECT | `_extract_like_fields` работает на depth=0 (вне скобок) |
| CTE (`WITH ... AS`) ломает определение позиции SELECT | low | Поле вставлено в CTE вместо основного SELECT | `_insert_into_select` ищет SELECT на depth=0 |
| `_insert_into_group_by` конфликтует с HAVING | low | GROUP BY вставлен после HAVING | Regex ищет точку вставки перед ORDER BY/FETCH/HAVING |
| `check_sql_structure_preserved` ругается на добавленное поле | none | — | Проверка считает запятые; добавление поля только увеличивает count, условие `fixed < original/2` не сработает |

## Масштаб

- **Файлы:** 2 (validator.py, test_validator.py) + devlog
- **Новый код:** ~80 строк в validator.py, ~120 строк тестов
- **Новые тесты:** 13 (12 unit + 1 интеграционный)
- **Рекомендация:** последовательное выполнение (Task 1→2→3→4), один разработчик
