# Plan: Детерминированный df_merger

## Context

`code_generator.py` тратит 1-3 LLM-вызова (5-15с) на генерацию pandas-кода для объединения DataFrames. LLM часто ошибается: merge на несуществующих ключах, cartesian product, дублирование агрегатов на каждую строку. При этом 80% случаев — простой merge по общему ключу (INN, MONTH_DT), 15% — concat, и только 5% требуют сложной логики.

**Цель:** создать `core/output/df_merger.py` — модуль для детерминированного объединения DataFrames (0 LLM-вызовов, <10мс). LLM-генерация (`generate_python_code()` → `validate_and_fix_python_code()` → `execute_python_code()`) сохраняется как fallback при `auto_merge_dataframes() → None`.

**Паттерн:** аналогичен `chart_builder.py` (ADR-017) — deterministic-first, все исключения → return None → вызывающий код переключается на LLM. Без feature flag.

> Фаза 0: baseline из research doc — LLM merge: 1-3 вызова, 5-15с, частые ошибки (cartesian product, несуществующие ключи). Live-baseline будет получен на Task 5.

## Scope

- **2 новых файла:** `df_merger.py`, `test_df_merger.py`
- **3 изменённых файла:** `agent.py`, `__init__.py`, `test_agent_methods.py`
- **3 обновлённых docs:** `devlog/changelog.json`, `docs/architecture.md`, `docs/research/...`
- **~45 новых тестов** (~40 unit + 5 integration), ~250-300 строк модуля

---

## Task 1: Тесты для df_merger (TDD — тесты первыми)

**File:** `tests/core/output/test_df_merger.py` (new)

Детерминированные функции → 100% unit-тесты, без LLM-моков.

### Группы тестов:

**TestClassifyDataframes (4 теста):**
- 1 row → aggregated (AGGREGATED_THRESHOLD=1: ровно 1 строка = агрегат)
- 2 rows → detailed (2 сегмента GROUP BY — это детализация, не агрегат)
- 10 rows → detailed
- mix (1-row + 10-row + 1-row) → correct split (1 detailed, 2 aggregated)

**TestFindCommonKeys (6 тестов):**
- Оба имеют INN → ["INN"]
- MONTH_DT + INN → known keys first по приоритету
- Нет общих колонок → []
- Колонка all-NaN → исключена
- Не-metadata колонки тоже возвращаются (после known keys)
- Несколько known keys → все возвращены

**TestDtypeCompatibility (4 теста):**
- Одинаковый тип (int64+int64) → compatible
- int64 vs float64 → compatible
- object vs int64 → incompatible (нужен cast)
- Корректное разделение на compatible/incompatible

**TestSafeCastKeys (3 теста):**
- int key → str в обоих DataFrames
- Оригиналы не мутированы (возвращены копии)
- Не-ключевые колонки не затронуты

**TestCartesianDetection (3 теста):**
- Нормальный merge (10 строк, входы 8+8) → False
- Cartesian (100 строк, входы 10+10) → True
- Граница (точно CARTESIAN_MULTIPLIER) → False (<=)

**TestValidateMergeResult (3 теста):**
- Пустой DataFrame → False
- Cartesian product → False
- Нормальный merge → True

**TestMergeTwo (7 тестов):**
- Merge по INN → корректный результат
- Нет общих ключей → None
- dtype mismatch (int vs str INN) → auto-cast + merge
- Non-unique key → cartesian → None
- Merged df содержит union колонок
- Suffix collision, _y all-NaN: оба df имеют ORGANIZATION_NM (не ключ), outer merge → _y all-NaN → drop _y, rename _x → ORGANIZATION_NM
- Suffix collision, обе заполнены: оба df имеют VALUE (не ключ), данные в обеих → оставить VALUE_x и VALUE_y
- Merge с `how="outer"` сохраняет строки из обоих df

**TestAutoMergeDataframes (10 тестов):**
- Пустой список → None
- Один DataFrame → его копия
- Два detailed с общим ключом → merged DataFrame
- Только aggregated → concat
- Mixed (detailed + aggregated) → None (LLM fallback, агрегат может быть нужен для расчёта долей)
- Нет общих ключей → None (LLM fallback)
- Exception на входе → None (не raises)
- Три detailed с общим ключом → sequential merge
- Sequential merge partial failure: d1+d2 OK, result+d3 → None (нет общих ключей) → весь merge → None
- Один detailed + один aggregated → None (не теряем агрегат тихо)

**Итого: ~40 тестов**

**Done when:** тесты написаны, `pytest tests/core/output/test_df_merger.py` → все FAIL (модуль ещё не реализован).

---

## Task 2: Реализация df_merger.py

**File:** `core/output/df_merger.py` (new, ~250-300 строк)

### Константы:

```python
AGGREGATED_THRESHOLD = 1      # ==1 row = aggregated (буквально один итог), >=2 = detailed
CARTESIAN_MULTIPLIER = 2      # len(result) > max(len_a, len_b) * 2 → cartesian
KEY_UNIQUENESS_WARN = 0.5     # nunique/len < 0.5 → warning (non-unique key)

# Metadata is_key fields (infrastructure/metadata.py, проверено grep "is_key": True)
KNOWN_KEYS = frozenset({
    "MONTH_DT", "INN", "GROUP_NM", "ORGANIZATION_NM", "DESK", "MANAGER_NAME"
})
```

### Функции:

**`_classify_dataframes(dfs) -> tuple[list[DataFrame], list[DataFrame]]`**
- Разделяет на detailed (>AGGREGATED_THRESHOLD строк, т.е. >=2) и aggregated (==1 строка)
- Возвращает (detailed_list, aggregated_list)

**`_find_common_keys(df1, df2) -> list[str]`**
- Находит общие колонки, присутствующие в обоих DataFrames
- Приоритет: KNOWN_KEYS первыми, затем остальные общие
- Исключает колонки с all-NaN

**`_check_dtype_compatible(df1, df2, keys) -> tuple[list[str], list[str]]`**
- Возвращает (compatible_keys, incompatible_keys)
- Числовые типы (int/float) совместимы между собой
- Остальные несовпадения → incompatible (требуют cast к str)

**`_safe_cast_keys(df1, df2, keys) -> tuple[DataFrame, DataFrame]`**
- Приводит ключевые колонки к общему dtype (str fallback)
- Возвращает копии (не мутирует оригиналы)

**`_is_cartesian_product(result, df1, df2) -> bool`**
- `len(result) > max(len(df1), len(df2)) * CARTESIAN_MULTIPLIER`

**`_validate_merge_result(result, df1, df2, keys) -> bool`**
- Checks: not empty, not cartesian
- Логирование: строк до/после, использованные ключи

**`_merge_two(df1, df2) -> DataFrame | None`**
- Ядро: find keys → check dtypes → cast if needed → merge(how="outer") → cleanup suffixes → validate

**`_cleanup_suffixes(df, keys) -> DataFrame`**
- После merge pandas добавляет `_x`/`_y` суффиксы для одноимённых не-ключевых колонок
- Логика для каждой пары `COL_x`/`COL_y`:
  - Если `COL_y` all-NaN (outer merge, строки только из левого df) → drop `COL_y`, rename `COL_x` → `COL`
  - Если `COL_x` all-NaN → drop `COL_x`, rename `COL_y` → `COL`
  - Если оба содержат данные → оставить оба с суффиксами (не терять информацию)

**`auto_merge_dataframes(dfs) -> DataFrame | None`** — public entry point:
```python
def auto_merge_dataframes(dfs):
    valid = [df for df in dfs if df is not None and not df.empty]
    if len(valid) == 0:
        return None
    if len(valid) == 1:
        return valid[0].copy()
    try:
        detailed, aggregated = _classify_dataframes(valid)
        if not detailed:
            return pd.concat(aggregated, ignore_index=True)  # all aggregated
        if aggregated:
            return None  # mixed: LLM нужен для расчёта долей от агрегатов
        # Only detailed → sequential merge
        result = detailed[0]
        for df in detailed[1:]:
            result = _merge_two(result, df)
            if result is None:
                return None  # LLM fallback
        return result
    except Exception:
        logger.warning("df_merger: ошибка при объединении", exc_info=True)
        return None
```

**Ключевое изменение:** mixed (detailed + aggregated) → `return None` вместо потери агрегатов. LLM умеет вычислять `df1['share'] = df1['val'] / df2.iloc[0]['total'] * 100`.

### Переиспользование:
- Не импортирует из других core/output модулей (standalone)
- `get_settings()` не нужен (нет конфигурируемых параметров)
- Параметр `question` убран — не используется в логике. Логирование вопроса на стороне вызова (agent.py)

**Done when:** `pytest tests/core/output/test_df_merger.py -v` → все ~36 тестов PASS.

---

## Task 3: Интеграция в pipeline + тесты

### 3a. `core/output/__init__.py`

Добавить re-export:
```python
from core.output.df_merger import auto_merge_dataframes
# + добавить в __all__
```

### 3b. `application/agent.py:_merge_dataframes()` (строки 154-241)

Вставить deterministic-first перед LLM-путём. Текущий код:
```python
if len(dataframes) > 0:
    # Step 4.1: generate_python_code → LLM
    # Step 4.2: validate_and_fix_python_code → exec + retry
    # Step 4.3: execute_python_code → final_df
```

Новый код:
```python
if len(dataframes) > 0:
    # Step 4.0: Deterministic merge (0 LLM calls)
    self._emit(f"[Шаг 4] Найдено {len(dataframes)} DataFrames для обработки")
    with PerfTimer("deterministic_merge", timings):
        from core.output.df_merger import auto_merge_dataframes
        merged = auto_merge_dataframes(dataframes)

    if merged is not None:
        final_df = merged
        python_code = None  # нет сгенерированного кода
        self._emit(f"[Шаг 4] ✅ df_merger: детерминированный merge ({len(final_df)} строк, {len(final_df.columns)} колонок)")
    else:
        # Steps 4.1-4.3: LLM fallback (existing code, unchanged)
        self._emit("[Шаг 4] ℹ️ Детерминированный merge невозможен, LLM fallback...")
        # ... existing generate_python_code → validate → execute ...
```

### 3c. `tests/application/test_agent_methods.py` — новые тесты (~5)

- `test_merge_dataframes_deterministic_called` — auto_merge_dataframes вызван
- `test_merge_dataframes_deterministic_success_skips_llm` — при успехе deterministic, generate_python_code.assert_not_called()
- `test_merge_dataframes_deterministic_none_falls_to_llm` — при None, generate_python_code вызван
- `test_merge_dataframes_deterministic_python_code_is_none` — при deterministic успехе, python_code is None
- `test_merge_dataframes_timings_has_deterministic` — timings содержит "deterministic_merge"

**Done when:** `pytest tests/ -v` → все существующие + новые тесты PASS.

---

## Task 4: Документация и devlog

- `docs/architecture.md` — добавить df_merger.py в описание core/output
- `CLAUDE.md` — добавить df_merger.py в структуру проекта (если нужно)
- `devlog/changelog.json` — запись о реализации
- `docs/research/2026-02-27-llm-excessive-usage-analysis.md` — пометить item 2 как ✅ РЕАЛИЗОВАНО, статус: 3 из 3

**Done when:** все docs обновлены, devlog запись добавлена.

---

## Task 5: Верификация и live-тест

1. `pytest tests/ -v` — все unit-тесты
2. `ruff check` — lint
3. Import checks (run_agent.py, zulip_bot.py, packages)
4. `pytest -m "integration and not slow"` — интеграционные тесты
5. Live-тест: `python run_agent.py` → вопрос с 2+ подвопросами → проверить лог:
   - `[Шаг 4] ✅ df_merger: детерминированный merge` — или — `LLM fallback`
   - Корректность final_df (данные, колонки)

**Done when:** pipeline работает end-to-end, нет регрессий.

---

## Граничные случаи

| Сценарий | Поведение | Обоснование |
|----------|-----------|-------------|
| 0 DataFrames | None (handled before merge call) | Нечего объединять |
| 1 DataFrame | Копия этого df | Нет merge, прямой проброс |
| 2 detailed с общим INN | merge(on="INN", how="outer") | 80% случаев |
| 2 detailed без общих ключей | None → LLM fallback | Нет очевидной стратегии |
| Only aggregated (1 строка каждый) | pd.concat(ignore_index=True) | Объединяем итоги |
| Mixed (detailed + aggregated) | None → LLM fallback | Агрегат может быть нужен для долей |
| dtype mismatch на ключах (int vs str) | Cast к str, merge | INN бывает str и int |
| Cartesian product | None → LLM fallback | len > max*2 = взрыв строк |
| Пустой результат merge | None → LLM fallback | Что-то пошло не так |
| Non-unique key (INN повторяется) | Warning в логе, merge с дублями | Если не cartesian, OK |
| 3+ detailed DataFrames | Sequential merge: d1+d2 → r1+d3 → ... | Если любой шаг None → fallback |
| Suffix collision (_y all-NaN) | drop _y, rename _x → original | Outer merge: NaN-only колонка бесполезна |
| Suffix collision (обе заполнены) | Оставить оба с суффиксами _x/_y | Не терять данные |
| GROUP BY 2 сегмента (2 строки) | Classified as detailed (>=2 rows) | Порог 1: только literal aggregates |

---

## Риски

| Сценарий | Вер. | Действие |
|----------|------|----------|
| Ложная классификация detailed/aggregated | Low | AGGREGATED_THRESHOLD=1 (только 1 строка = агрегат); 40 тестов |
| Cartesian product проходит проверку | Low | CARTESIAN_MULTIPLIER=2; explicit check |
| dtype cast ломает данные | Medium | Cast к str (безопасно); копии (не мутация) |
| Mixed отправляется в LLM слишком часто | Medium | Осознанный выбор: лучше LLM для долей, чем тихая потеря агрегата |
| Deterministic path хуже LLM | Low | auto_merge → None → LLM fallback работает как раньше |
| Non-unique keys → дубли строк | Medium | _is_cartesian_product отлавливает; warning в логе |
| Suffix collision теряет данные | Low | _cleanup_suffixes: drop only all-NaN; keep both if data; 2 теста |

## Верификация

1. `pytest tests/core/output/test_df_merger.py -v` — все новые тесты
2. `pytest tests/ -v` — регрессии
3. Live-тест: `python run_agent.py` → multi-subquestion вопрос → проверить merge в логе
4. Batch A/B: прогнать batch, сравнить результаты с/без deterministic merge

### Критерии стабильности

- 20+ live-запросов с multi-subquestion прошли без ошибок
- Deterministic path работает для >=80% merge-случаев
- 0 открытых багов в течение 1 недели

## Дальнейшие шаги

После утверждения плана запустить реализацию. Последовательное выполнение Tasks 1→2→3→4→5.
