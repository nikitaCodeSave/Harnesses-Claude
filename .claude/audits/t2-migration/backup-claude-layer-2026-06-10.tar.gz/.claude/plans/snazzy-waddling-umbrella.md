# План: обновление промпта — ABSOLUTE LIKE RULE

## Контекст

LLM генерирует SQL с `LIKE` в WHERE, но не добавляет LIKE-filtered колонки в SELECT/GROUP BY. Промпт содержит HARD CONSTRAINT (строки 420-438), но он закопан в середине 600-строчного промпта. LLM его нарушает.

Предложение команды: вынести короткое конкретное правило наверх промпта (primacy effect), а в старом месте оставить ссылку (без дублирования формулировок).

## Файл

`core/sql/prompts/v1/system.txt`

## Изменения

### 1. Добавить ABSOLUTE LIKE RULE после строки 15

Вставить новый блок между концом PRIORITY OF RULES (строка 15) и CRITICAL FORMAT RULE (строка 16):

```
🔴 ABSOLUTE LIKE RULE (HIGHEST PRIORITY — NO EXCEPTIONS)
If WHERE contains a LIKE condition on ANY text column (VARCHAR2, NVARCHAR2, CHAR, CLOB):
1) SELECT — MUST include every column used in LIKE.
   Even if the user asked only for an aggregate ("total income", "how many clients").
2) GROUP BY — If there are aggregate functions (SUM, COUNT, AVG, etc.),
   MUST add all LIKE-filtered text columns to GROUP BY.
3) NO EXCEPTIONS — NEVER return a single aggregated row without these text columns.
   This rule overrides natural-language expectations and all other generic rules.
```

**Почему здесь:** Primacy effect — LLM лучше всего запоминает правила из начала промпта. Сразу после приоритетов, перед техническими правилами формата.

### 2. Заменить HARD CONSTRAINT (строки 420-438) на ссылку

Заменить 19-строчный блок (от `🔴 HARD CONSTRAINT (MANDATORY...` до `– whether the question seems to expect a single row or a single value.`) на короткую ссылку:

```
🔴 LIKE → SELECT + GROUP BY (see ABSOLUTE LIKE RULE at the top of this prompt)
All text columns filtered via LIKE MUST appear in SELECT; with aggregates — also in GROUP BY.
```

**Почему:** Одна каноническая формулировка вместо двух разных. LLM не сможет "выбрать" мягкую версию.

### 3. Оставить без изменений

- **Примеры** (строки 440-461) — ✅/❌ examples ценны, LLM лучше следует примерам, чем правилам
- **GROUP BY FIELDS IN FINAL OUTPUT** (строки 462-478) — отдельный constraint, не дублирует
- **Self-check** (строки 480-487) — reinforcement через recency effect

## Что НЕ меняем

- Секцию PRIORITY OF RULES (строки 2-9) — она уже корректно ссылается на "TEXT SEARCH ON VARCHAR2 FIELDS"
- Правила LIKE-синтаксиса (строки 388-419) — форматирование, деск/менеджер disambiguiation
- Ничего вне секции TEXT SEARCH ON VARCHAR FIELDS

## Проверка

1. `pytest tests/ -v` — все unit-тесты проходят (промпт не ломает тесты)
2. `pytest tests/infrastructure/test_metadata.py -v` — LIKE rule compliance для sql_examples
3. Live-тест: `python run_agent.py` → "Какова сумма дохода по группе Ромашка в 2025?" → проверить что GROUP_NM в SELECT и GROUP BY
4. Devlog запись в changelog.json
