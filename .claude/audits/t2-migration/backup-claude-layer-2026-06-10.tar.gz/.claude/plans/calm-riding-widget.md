# Рефакторинг LLMSettings — контекстное окно, унификация, защита промптов

## Context

При тестировании полного пайплайна обнаружено: Ollama с дефолтным `num_ctx=4096` обрезала промпты — модель теряла вопрос, Oracle-инструкции, sandbox-правила. После ручного исправления на `num_ctx=32768` всё заработало, но выявлены системные проблемы в `LLMSettings`:

1. **Нет context_window** — никто не проверяет что prompt+completion влезает в модель
2. **7 из 9 операций** не имеют `max_prompt_chars` — промпт может тихо переполнить контекст
3. **max_tokens завышены** — `qa_analyze=10000` при реальном ответе ~50 токенов
4. **Naming inconsistency** — `sql_max_prompt_length` (без `fix_`) при `sql_fix_max_tokens` (с `fix_`)
5. **Нет учёта reasoning** — Qwen3 Thinking генерирует 1-7K reasoning-токенов сверх max_tokens

## Что меняем

### 1. Новые model-level параметры в LLMSettings

```python
context_window: int = Field(default=32768)      # Общий бюджет модели
reasoning_overhead: int = Field(default=8000)    # Запас на reasoning-токены Qwen3
```

### 2. Каждая операция получает `max_prompt_chars`

Добавляем для 5 операций без защиты (2 уже имеют — sql_fix, response):

| Операция | Новый параметр | Default | Основание |
|----------|---------------|---------|-----------|
| sql_gen | `sql_gen_max_prompt_chars` | 50000 | Самый большой промпт: 36480ch |
| qa_analyze | `qa_analyze_max_prompt_chars` | 50000 | Промпт 14447ch + рост с данными |
| qa_response | `qa_response_max_prompt_chars` | 30000 | Финальный ответ, умеренный |
| chart_gen | `chart_gen_max_prompt_chars` | 50000 | Промпт 16887ch |
| code_gen | `code_gen_max_prompt_chars` | 50000 | Промпт 6461ch, может расти |
| chart_fix | `chart_fix_max_prompt_chars` | 20000 | Fix-промпт меньше |
| code_fix | `code_fix_max_prompt_chars` | 20000 | Fix-промпт меньше |

### 3. Пересчёт max_tokens по реальным данным

| Операция | Было | Стало | Реальный ответ | Обоснование |
|----------|------|-------|----------------|-------------|
| sql_gen | 6000 | 2000 | ~200 tok | 10x запас достаточен |
| qa_analyze | 10000 | 2000 | ~50 tok | JSON-массив, не нужно 10K |
| qa_response | 6000 | 4000 | ~200 tok | Может расти с подвопросами |
| sql_fix | 4000 | 2000 | ~200 tok | Фиксированный SQL |

Остальные (response=2000, chart_gen=4000, chart_fix=4000, code_gen=4000, code_fix=4000) — без изменений.

### 4. Переименования (с backward-compat)

| Старое имя | Новое имя | Причина |
|------------|-----------|---------|
| `sql_max_prompt_length` | `sql_fix_max_prompt_chars` | Принадлежит sql_fix, не sql; `_chars` единообразнее `_length` |
| `response_max_prompt_length` | `response_max_prompt_chars` | Единообразие с новыми `*_max_prompt_chars` |
| `chart_max_attempts` | `chart_fix_max_attempts` | Принадлежит chart_fix |
| `python_gen_*` | `code_gen_*` | Совпадение с `operation_name="code_generation"` в call_llm |
| `python_fix_*` | `code_fix_*` | Совпадение с operation_name |

Backward-compat через `@model_validator(mode="before")` — старые имена в .env продолжают работать.

### 5. Warning в call_llm при переполнении контекста

Не блокирует, только логирует warning:
```
estimated total=19000 tokens (prompt~13000 + max_tokens=2000 + reasoning=8000) > context_window=32768
```

## Файлы для изменения

### Phase 1: settings + call_llm

1. **`infrastructure/settings.py`** — основные изменения в `LLMSettings`:
   - Добавить `context_window`, `reasoning_overhead`
   - Добавить 7 новых `*_max_prompt_chars`
   - Переименовать 8 параметров (5 пар python→code, 3 отдельных)
   - Пересчитать 4 дефолта max_tokens
   - `_migrate_aliases` model_validator для backward-compat

2. **`infrastructure/llm_client.py`** — добавить context window warning в `call_llm()` (~10 строк)

### Phase 2: consumer modules (переименования + добавление prompt_chars проверок)

3. **`core/sql/generator.py`** — добавить `sql_gen_max_prompt_chars` проверку
4. **`core/sql/validator.py`** — `sql_max_prompt_length` → `sql_fix_max_prompt_chars`
5. **`core/analysis/question_analyzer.py`** — добавить `qa_analyze_max_prompt_chars` и `qa_response_max_prompt_chars` проверки
6. **`core/output/response_generator.py`** — `response_max_prompt_length` → `response_max_prompt_chars`
7. **`core/output/chart_generator.py`** — добавить `chart_gen_max_prompt_chars`, `chart_fix_max_prompt_chars`; `chart_max_attempts` → `chart_fix_max_attempts`
8. **`core/output/code_generator.py`** — `python_gen_*` → `code_gen_*`; добавить `code_gen_max_prompt_chars`
9. **`core/output/code_validator.py`** — `python_fix_*` → `code_fix_*`

### Phase 3: tests + docs

10. **`tests/infrastructure/test_settings.py`** — обновить defaults, field sets, добавить тест aliases
11. **`.env.example`** — обновить имена параметров
12. **`docs/configuration.md`** — обновить таблицу параметров
13. **`devlog/changelog.json`** — запись о рефакторинге
14. **`docs/decisions/ADR-016-llm-settings-refactoring.md`** — новый ADR

## Чего НЕ делаем

- Не делаем nested sub-models (`llm.sql_gen.temperature`) — ломает .env формат, избыточно
- Не добавляем token-counting API — приближение `chars/4` достаточно для warning
- Не делаем auto-truncation в call_llm — модули знают свою структуру лучше
- Не трогаем DataDisplaySettings — они уже работают корректно

## Проверка

1. `pytest tests/infrastructure/test_settings.py -v` — все тесты settings проходят
2. `pytest tests/ -v` — нет регрессий по переименованиям
3. `python dev/debug_llm_response.py` — контекст не обрезается
4. `echo "Топ-10 клиентов по сумме продуктов" | python run_agent.py` — полный прогон
5. Проверить что старые .env с `AI_ANALYST_LLM__PYTHON_GEN_TEMPERATURE` всё ещё работают
