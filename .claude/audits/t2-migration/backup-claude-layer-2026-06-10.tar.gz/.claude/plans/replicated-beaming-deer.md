# План: ZulipLogger dead code, _emit extraction, step constants

## Context

После Фазы 1 рефакторинга ZulipLogger (сокращение _emit 172→41, упрощение _should_skip_line 65→8 строк) остались 4 проблемы: dead code в ZulipLogger, дублирование _emit в 3 файлах, stringly-typed step prefixes, аллокация строк в _should_skip_line. Спецификация: `docs/research/2026-03-06-zulip-logger-and-emit-cleanup.md`.

## Зависимость между задачами

```
Задача 1 (dead code) — независимая
Задача 2 (_emit factory) — независимая
Задача 3 (step constants) — ЗАВИСИТ от Задачи 1 (write() удалён → flush-триггеры только в emit(), 2 замены вместо 4)
Задача 4 (micro-opt) — независимая
```

**Порядок**: 1 → 2 → 3 → 4 → верификация + devlog

---

## Задача 1: Удаление dead code ZulipLogger

**Файл**: `presentation/zulip_bot.py`

Удалить:
- `write()` — строки 46-89 (44 строки, включая flush-логику со строковыми триггерами "[Шаг", "[Подвопрос]")
- `isatty()` — строки 188-189
- `encoding` property — строки 191-194

**Обоснование**: `sys.stdout` нигде не переназначается на ZulipLogger. Guardrail-тест `tests/application/test_callback.py:92` это гарантирует. `emit()` — единственный используемый callback (agent.py:385 → `on_progress=zulip_logger.emit`).

**Тесты**: существующие тесты `test_zulip_logger.py` и `test_callback.py` должны оставаться зелёными. Новых тестов не нужно.

**Done when**: `grep -c 'def write\|def isatty\|def encoding' presentation/zulip_bot.py` → 0

---

## Задача 2: Извлечение _emit в make_emit фабрику

**Файлы**:
- `infrastructure/utils.py` — добавить `make_emit()` (~5 строк)
- `application/agent.py` — заменить метод `_emit` (строки 89-94) на `self._emit = make_emit(on_progress)` в `__init__`
- `application/subquestion.py` — заменить closure `_emit` (строки 53-57) на `_emit = make_emit(emit)`
- `application/reports.py` — заменить closure `_emit` (строки 246-250) на `_emit = make_emit(emit)`
- `tests/infrastructure/test_utils.py` — добавить 2 теста для make_emit

**Фабрика** (в `infrastructure/utils.py`):
```python
def make_emit(callback: Callable[[str], None] | None = None) -> Callable[[str], None]:
    """Создаёт emit-функцию: callback если задан, иначе print."""
    if callback is not None:
        return callback
    return lambda message: print(message, flush=True)
```

**Совместимость моков**: `test_callback.py` передаёт `on_progress=callback` → `agent._emit` станет самим callback → `agent._emit("test")` вызовет `callback("test")` — тест пройдёт. Тест `test_emit_prints_when_no_callback` — `agent._emit` станет lambda с print — тест пройдёт.

**Done when**: `grep 'def _emit' application/` → 0 результатов

---

## Задача 3: Step-константы для flush-триггеров (компромиссный вариант)

**Файлы**:
- `application/progress.py` — новый модуль (~5 строк: STEP_PREFIX, SUBSTEP_PREFIX)
- `presentation/zulip_bot.py` — заменить строки `"[Шаг"` и `"[Подвопрос]"` в flush-триггерах emit() на константы (2 места, т.к. write() уже удалён в Задаче 1)
- `tests/presentation/test_zulip_logger.py` — импортировать константы если используются в assertions (проверить при реализации)

**НЕ менять**: формирование строк в _emit вызовах (raw strings `"[Шаг 1] ..."` остаются как есть — читаемость важнее).

**Done when**: `grep 'STEP_PREFIX\|SUBSTEP_PREFIX' presentation/zulip_bot.py` → 2 результата

---

## Задача 4: Микро-оптимизация _should_skip_line

**Файл**: `presentation/zulip_bot.py`

Заменить:
```python
# Было:
if len(line) >= 4 and (line == "=" * len(line) or line == "-" * len(line)):

# Стало:
if len(line) >= 4 and line[0] in ("=", "-") and not line.strip(line[0]):
```

**Done when**: тесты `test_zulip_logger.py` зелёные

---

## Задача 5: Верификация и постобработка

1. `pytest tests/ -v` — все тесты зелёные
2. `grep 'def _emit' application/` → 0
3. `grep -c 'def write\|def isatty\|def encoding' presentation/zulip_bot.py` → 0
4. `grep 'STEP_PREFIX\|SUBSTEP_PREFIX' presentation/zulip_bot.py` → 2
5. Обновить `devlog/changelog.json`

---

## Риски

| Сценарий | Вероятность | Митигация |
|----------|-------------|-----------|
| Тесты моков _emit ломаются | Низкая | test_callback.py мокирует on_progress, не _emit — совместимо с make_emit |
| Внешний код вызывает write() | Нулевая | grep 0 вызовов, guardrail-тест |
| Circular import progress.py ↔ zulip_bot.py | Нулевая | application/ → presentation/ — односторонняя зависимость, zulip_bot импортирует из application |

## Масштаб

- **Файлов**: 7 изменённых + 1 новый (progress.py)
- **Тестов**: 2 новых (make_emit), остальные без изменений
- **Параллелизм**: Задачи 1, 2, 4 можно выполнять параллельно (разные файлы/функции). Задача 3 после Задачи 1.

## Рекомендация

Последовательное выполнение (1→2→3→4→5). Задачи мелкие и механические, параллелизм agent teams не оправдан.
