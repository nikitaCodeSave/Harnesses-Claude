# Research: Claude Code Plugins, Frameworks & Patterns (March 2026)

Deep web research on the Claude Code ecosystem -- official plugins, community frameworks, and production patterns relevant to a Python/Oracle analytics project.

---

## 1. Official Anthropic Plugin Ecosystem

### 1.1 Plugin Architecture

Claude Code uses a layered extension system:

- **Skills** (`.claude/skills/<name>/SKILL.md`) -- prompt-based instructions injected into context
- **Agents/Subagents** (`.claude/agents/<name>.md`) -- isolated execution contexts with tool restrictions
- **Hooks** (`.claude/settings.json`) -- deterministic shell commands on lifecycle events (24 event types)
- **MCP Servers** (`.mcp.json` or settings) -- external tool integrations via Model Context Protocol
- **Plugins** -- packaged bundles of skills + agents + hooks + MCP servers, distributable via marketplaces

### 1.2 Official Marketplace (claude-plugins-official)

Auto-available in Claude Code. Install via `/plugin install <name>@claude-plugins-official`.

**Code Intelligence Plugins** (LSP-based):
- `pyright-lsp` -- Python type checking and navigation (relevant to our project)
- `gopls-lsp`, `rust-analyzer-lsp`, `typescript-lsp`, `clangd-lsp`, etc.
- These give Claude automatic diagnostics after every file edit + code navigation (go-to-definition, find-references)

**External Integration Plugins**:
- `github`, `gitlab` -- source control
- `atlassian` (Jira/Confluence), `asana`, `linear`, `notion` -- project management
- `slack` -- communication
- `sentry` -- monitoring
- `vercel`, `firebase`, `supabase` -- infrastructure

**Development Workflow Plugins**:
- `commit-commands` -- git commit workflows
- `pr-review-toolkit` -- PR review agents
- `agent-sdk-dev`, `plugin-dev` -- development tools

**No official Oracle or financial-services-specific plugins found for Claude Code** (though Anthropic has a separate financial services offering for Claude).

### 1.3 Bundled Skills (built-in, every session)

| Skill | Purpose |
|-------|---------|
| `/batch <instruction>` | Parallel codebase changes across worktrees, spawns 5-30 agents |
| `/claude-api` | Claude API reference for Python/TS/etc. |
| `/debug [description]` | Debug logging and session troubleshooting |
| `/loop [interval] <prompt>` | Repeated prompt on schedule |
| `/simplify [focus]` | Three parallel review agents for code quality |

### 1.4 Built-in Subagents

| Agent | Model | Tools | Purpose |
|-------|-------|-------|---------|
| Explore | Haiku | Read-only | Fast codebase search |
| Plan | Inherits | Read-only | Research for plan mode |
| General-purpose | Inherits | All | Complex multi-step tasks |

Source: https://code.claude.com/docs/en/skills, https://code.claude.com/docs/en/sub-agents, https://code.claude.com/docs/en/discover-plugins

---

## 2. Community Frameworks

### 2.1 BMAD Method (Breakthrough Method for Agile AI-Driven Development)

**Repos**:
- https://github.com/bmad-code-org/BMAD-METHOD (core)
- https://github.com/24601/BMAD-AT-CLAUDE (Claude Code port)
- https://github.com/aj-geddes/claude-code-bmad-skills (v6 skills)

**What it is**: Full-lifecycle agentic development framework with 9 specialized roles operating across 8 phases.

**Key innovation**: Two-layer architecture:
1. **Agentic Planning** -- Analyst, PM, Architect agents create PRDs and architecture docs
2. **Context-Engineered Development** -- Scrum Master transforms plans into hyper-detailed story files for Dev agent

**Claude Code integration (v6)**:
- 9 skills installed under `~/.claude/skills/bmad/`
- 15 workflow commands (`/workflow-init`, `/prd`, `/architecture`, `/sprint-planning`, `/create-story`, `/dev-story`, etc.)
- Token-optimized: shared helpers.md referenced by section, 70-85% token reduction vs embedded approach
- Status persistence via YAML files (`bmad-outputs/bmm-workflow-status.yaml`)

**Applicable patterns for our project**:
- The **helper pattern** (shared reference docs loaded by section) is directly applicable to our metadata.py and prompt templates
- **Phase gating** (`/solutioning-gate-check`) before implementation prevents wasted work
- **Project levels 0-4** auto-determine workflow complexity -- useful for distinguishing simple SQL queries from multi-step analytics
- **Status persistence** across sessions via YAML -- similar to our request_tracker

### 2.2 Production Three-Pillar Pattern (BMAD + Langfuse + Agent Teams)

**Source**: https://vadim.blog/bmad-langfuse-claude-code-agent-teams

**Architecture**:
| Gap | System | Solution |
|-----|--------|----------|
| Agents lack structure | BMAD v6 | Step-file workflows with quality gates |
| No observability | Langfuse | Traces, versioning, scoring |
| Multi-agent conflicts | Agent Teams | Role-based ownership + permissions |

**Key patterns**:
- **Tool restrictions as ownership**: `defineSubagent()` constrains tools per role (reviewer gets only Read/Glob/Grep -- cannot modify files)
- **Spawn prompts bridge systems**: BMAD role conventions become agent constraints
- **Constraints beat documentation**: Tool restrictions enforce ownership more reliably than code comments
- **Composable prompts**: Langfuse prompt references `@@@langfusePrompt:name=X|label=Y@@@` resolved recursively

**Applicable to our project**: The observability layer (Langfuse or similar) for tracking LLM calls, prompt versions, and A/B testing prompt variants is directly relevant to our analytics pipeline.

### 2.3 Multi-Agent Orchestration Frameworks

**Claude Code Agent Teams** (official, experimental):
- Source: https://code.claude.com/docs/en/agent-teams
- Enable: `CLAUDE_CODE_EXPERIMENTAL_AGENT_TEAMS=1`
- Team lead coordinates, teammates work independently in own context windows
- Shared task list with file-locking for concurrent claims
- Communication via direct messaging + broadcast
- Hooks: `TeammateIdle`, `TaskCreated`, `TaskCompleted` for quality gates
- Best for: 3-5 teammates, 5-6 tasks per teammate
- Token cost scales linearly with team size

**Other frameworks found**:
- `ruflo` (github.com/ruvnet/ruflo) -- multi-agent swarm orchestration
- `claude-mpm` (github.com/bobmatnyc/claude-mpm) -- subprocess orchestration
- `ccswarm` (github.com/nwiizo/ccswarm) -- git worktree isolation per agent
- `claude-code-workflow-orchestration` -- hook-based task decomposition

---

## 3. Skills, Agents & Directory Structure Patterns

### 3.1 Recommended .claude/ Directory Structure

```
.claude/
  settings.json           # Project settings, hooks, permissions
  settings.local.json     # Local overrides (gitignored)

  skills/                 # Reusable knowledge modules
    <skill-name>/
      SKILL.md            # Main instructions (required)
      references/         # Detailed docs loaded on demand
      examples/           # Example outputs
      scripts/            # Executable scripts

  agents/                 # Subagent definitions
    <agent-name>.md       # YAML frontmatter + system prompt

  commands/               # Slash commands (legacy, merged into skills)
    <command-name>.md

  hooks/                  # Hook scripts
    protect-files.sh
    validate-query.sh

  rules/                  # Project-specific rules
    code-style.md
    testing.md

  agent-memory/           # Persistent memory per agent (project scope)
    <agent-name>/
      MEMORY.md
```

### 3.2 SKILL.md Format

```yaml
---
name: skill-name
description: What and when (under 50 words)
allowed-tools: Read, Grep, Glob, Bash(git *)
model: sonnet                    # optional model override
context: fork                    # optional: run in subagent
agent: Explore                   # which subagent type
disable-model-invocation: true   # manual-only
paths: "core/sql/**"             # auto-activate on matching files
effort: high                     # low/medium/high/max
---

Markdown instructions here.
Reference supporting files: [reference.md](reference.md)
Dynamic context: !`git log --oneline -5`
Arguments: $ARGUMENTS or $0, $1
```

### 3.3 Agent (.claude/agents/) Format

```yaml
---
name: db-reader
description: Execute read-only database queries
tools: Bash, Read, Grep
disallowedTools: Write, Edit
model: sonnet
permissionMode: dontAsk
maxTurns: 20
memory: project
skills:
  - api-conventions
  - error-handling-patterns
mcpServers:
  - postgres-mcp
hooks:
  PreToolUse:
    - matcher: "Bash"
      hooks:
        - type: command
          command: "./scripts/validate-readonly-query.sh"
---

System prompt in markdown.
```

### 3.4 Hooks System (24 Event Types)

Key events for our project:
- `PreToolUse` -- block dangerous operations (e.g., validate SQL is read-only)
- `PostToolUse` -- auto-format, auto-lint after edits
- `Stop` -- verify all tasks complete before finishing
- `SessionStart(compact)` -- re-inject critical context after compaction
- `Notification` -- desktop notifications when Claude needs input
- `SubagentStart/Stop` -- setup/cleanup for subagent lifecycle
- `ConfigChange` -- audit trail for settings changes

Hook types: `command` (shell), `http` (webhook), `prompt` (single LLM call), `agent` (multi-turn with tools)

### 3.5 Skill Architecture Internals

From the deep-dive analysis (leehanchung.github.io):
- Skills live as a single meta-tool "Skill" in the tools array, not in the system prompt
- 15,000-character token budget for all skill descriptions combined (configurable via `SLASH_COMMAND_TOOL_CHAR_BUDGET`)
- No algorithmic routing -- pure LLM reasoning based on descriptions
- Dual-message injection: visible metadata + hidden skill prompt
- Tool permissions pre-approved for skill duration only
- Skills only affect their execution context; behavior reverts post-completion

Source: https://leehanchung.github.io/blogs/2025/10/26/claude-skills-deep-dive/

---

## 4. Patterns Applicable to Our Python/Oracle Analytics Project

### 4.1 Immediate High-Value Additions

**1. Install pyright-lsp plugin**
```
/plugin install pyright-lsp@claude-plugins-official
```
Gives Claude automatic type-error diagnostics after every edit and go-to-definition across our codebase.

**2. Create a db-reader subagent** (`.claude/agents/db-reader.md`)
Read-only Oracle query agent with PreToolUse hook that blocks INSERT/UPDATE/DELETE. Directly applicable to our sql_validator pattern.

**3. Create a sql-review skill** (`.claude/skills/sql-review/SKILL.md`)
Inject metadata.py field descriptions, Oracle SQL conventions, and LIKE-constraint rules as context when reviewing SQL generation code.

**4. PostToolUse hook for auto-formatting**
Run ruff/black after Edit/Write operations.

**5. SessionStart(compact) hook**
Re-inject critical context: table schema summary, current sprint focus, architectural constraints.

### 4.2 BMAD-Inspired Workflow Skills

For structured feature development:
- `/analyze-feature` -- Business Analyst skill for requirements gathering
- `/design-architecture` -- Architect skill referencing docs/architecture.md
- `/plan-sprint` -- Scrum Master skill creating story files with embedded context
- `/implement-story` -- Dev skill with TDD workflow and quality gates

The helper pattern (shared reference docs) maps to our existing structure:
- `infrastructure/metadata.py` -> `references/field-dictionary.md`
- `docs/architecture.md` -> `references/architecture.md`
- `docs/decisions/` -> `references/adr-index.md`

### 4.3 Agent Teams for Complex Analytics

For multi-step analytical questions:
- **SQL Agent** -- generates and validates SQL against Oracle
- **Analysis Agent** -- pandas operations, DataFrame merging
- **Visualization Agent** -- chart generation, PDF reports
- **Review Agent** -- validates results, checks for data quality

This mirrors our existing 8-step pipeline but with parallel execution where possible.

### 4.4 Hook-Based Quality Gates

```json
{
  "hooks": {
    "PreToolUse": [
      {
        "matcher": "Bash",
        "hooks": [{
          "type": "command",
          "command": ".claude/hooks/validate-no-drop-table.sh"
        }]
      }
    ],
    "PostToolUse": [
      {
        "matcher": "Edit|Write",
        "hooks": [{
          "type": "command",
          "command": "jq -r '.tool_input.file_path' | xargs .venv/bin/ruff check --fix"
        }]
      }
    ],
    "Stop": [
      {
        "hooks": [{
          "type": "prompt",
          "prompt": "Check if all requested tasks are complete and tests pass."
        }]
      }
    ]
  }
}
```

---

## 5. Key Sources

1. [Claude Code Skills docs](https://code.claude.com/docs/en/skills) -- official skill format, frontmatter, patterns
2. [Claude Code Subagents docs](https://code.claude.com/docs/en/sub-agents) -- agent format, tool restrictions, memory
3. [Claude Code Agent Teams docs](https://code.claude.com/docs/en/agent-teams) -- experimental multi-agent coordination
4. [Claude Code Hooks Guide](https://code.claude.com/docs/en/hooks-guide) -- 24 event types, quality gates, automation
5. [Claude Code MCP docs](https://code.claude.com/docs/en/mcp) -- MCP server configuration
6. [Claude Code Plugin Discovery](https://code.claude.com/docs/en/discover-plugins) -- marketplace, LSP plugins, integrations
7. [Anthropic Official Plugins](https://github.com/anthropics/claude-plugins-official) -- curated plugin directory
8. [BMAD-AT-CLAUDE](https://github.com/24601/BMAD-AT-CLAUDE) -- BMAD framework for Claude Code
9. [BMAD v6 Skills](https://github.com/aj-geddes/claude-code-bmad-skills) -- token-optimized 9-skill implementation
10. [BMAD + Langfuse + Agent Teams](https://vadim.blog/bmad-langfuse-claude-code-agent-teams) -- production three-pillar pattern
11. [Claude Skills Deep Dive](https://leehanchung.github.io/blogs/2025/10/26/claude-skills-deep-dive/) -- technical architecture analysis
12. [Claude Code Best Practice](https://github.com/shanraisshan/claude-code-best-practice) -- 86+ tips, .claude/ patterns
13. [Production Structure Guide](https://dev.to/lizechengnet/how-to-structure-claude-code-for-production-mcp-servers-subagents-and-claudemd-2026-guide-4gjn) -- .claude/ for production
