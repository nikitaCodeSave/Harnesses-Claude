# Plan: Semantic-aware digest — фильтрация агрегатов + обогащение промпта

## Context

`dataframe_to_digest()` и `digest_to_prompt_text()` показывают все 5 агрегатов (sum, mean, min, max, median) для **каждой** числовой колонки одинаково. Но поля metadata имеют разную семантику агрегации:

- **CA_LCY_SUM** (средние остатки): `aggregation_between_month=AVG` → `сумма` по месяцам бессмысленна
- **ACT_1M** (бинарный флаг 0/1): `aggregation_between_month=MAX` → `среднее` и `медиана` бессмысленны

LLM видит `сумма=2.9 млрд` для средних остатков и пишет "общие остатки = 2.9 млрд" — **ошибка**.

Metadata (`infrastructure/metadata.py`) **уже содержит** `aggregation_between_clients` и `aggregation_between_month`, но `response_generator.py` их не использует.

**Источник**: `docs/thinking/2026-03-27-semantic-aware-digest.md` (status: decided)

## Scope — 1 файл + тесты

| Файл | Изменение |
|------|-----------|
| `core/output/response_generator.py` | Новая `_get_column_aggregation_rules()`, изменения в `dataframe_to_digest()`, `digest_to_prompt_text()`, `aggregate_remaining_rows()` |
| `tests/core/output/test_response_generator.py` | ~15 новых тестов |
| `devlog/changelog.json` | Запись |

**НЕ затрагивается**: metadata.py, chart_builder.py, chart_generator.py, code_generator.py, subquestion.py, agent.py, точки входа.

**Потребитель `dataframe_to_digest()`**: `question_analyzer.py:230` — также получит фильтрацию. Это корректно (та же семантика).

## Правила фильтрации агрегатов

| aggregation_between_month | Показать | Скрыть |
|--------------------------|----------|--------|
| SUM | sum, mean, min, max, median | — |
| AVG | mean, min, max, median | **sum** |
| MAX | min, max | **sum, mean, median** |
| N/A / fallback (no match) | sum, mean, min, max, median | — |

## Формат аннотаций (Вариант 3: category + правило)

```
CA_LCY_SUM (Балансы; между клиентами: суммируется, между месяцами: усредняется):
  среднее=82304, мин=0, макс=5000000, медиана=12000, непустых=150
```

Используем `category` из metadata (7-20 символов), **не** `description` (93-469 символов — слишком длинный).

## Tasks

### Task 1: `_get_column_aggregation_rules()` + `_ALLOWED_STATS` + `_AGG_LABELS`
**Files**: `core/output/response_generator.py`
**Depends on**: none
**TDD**: тест первым

Новые private-функции/константы:

```python
# Правила фильтрации: agg_month → допустимые ключи stats
_ALLOWED_STATS: dict[str, tuple[str, ...]] = {
    "SUM": ("sum", "mean", "min", "max", "median"),
    "AVG": ("mean", "min", "max", "median"),
    "MAX": ("min", "max"),
}

# Человекочитаемые подписи агрегации
_AGG_LABELS: dict[str, str] = {
    "SUM": "суммируется",
    "AVG": "усредняется",
    "MAX": "берётся максимум",
}

def _get_column_aggregation_rules(df_columns: list[str]) -> dict[str, dict]:
    """Маппит колонки DataFrame на правила агрегации из metadata.

    Returns:
        {col: {"agg_clients": "SUM", "agg_month": "AVG", "category": "Балансы"}}
        Колонки без match — не включаются (fallback = все агрегаты).
    """
```

**Done when**: `_get_column_aggregation_rules()` корректно маппит CA_LCY_SUM → AVG, PNL_SUM → SUM, ACT_1M → MAX; alias-колонки → пустой dict.

### Task 2: Фильтрация в `dataframe_to_digest()`
**Files**: `core/output/response_generator.py`
**Depends on**: Task 1
**TDD**: тест первым

В `dataframe_to_digest()` добавить поле `aggregation_rules` в возвращаемый dict:
```python
return {
    ...
    "aggregation_rules": _get_column_aggregation_rules(list(df.columns)),
}
```

`numeric_stats` **не фильтруем** на этом этапе — вычисляем все 5, фильтрация при рендеринге (Task 3). Это позволяет потребителям digest получить полные данные.

**Done when**: `dataframe_to_digest()` возвращает `aggregation_rules` с корректным маппингом.

### Task 3: Фильтрация + аннотации в `digest_to_prompt_text()`
**Files**: `core/output/response_generator.py`
**Depends on**: Task 2
**TDD**: тест первым

В секции numeric_stats:
1. Для каждой колонки проверяем `aggregation_rules`
2. Если match — фильтруем stats по `_ALLOWED_STATS[agg_month]` и добавляем аннотацию `(category; между клиентами: X, между месяцами: Y)`
3. Если no match — все stats как сейчас, без аннотации

**Done when**:
- CA_LCY_SUM показывает `среднее, мин, макс, медиана` (без `сумма`) с аннотацией `(Балансы; ...)`
- PNL_SUM показывает все 5 с аннотацией
- ACT_1M показывает `мин, макс` (без `сумма, среднее, медиана`) с аннотацией
- Alias-колонка `total_income` показывает все 5, без аннотации

### Task 4: Фильтрация в `aggregate_remaining_rows()`
**Files**: `core/output/response_generator.py`
**Depends on**: Task 1
**TDD**: тест первым

В строке "Прочее" для matched колонок показывать только допустимые агрегаты.

**Done when**: "Прочее" для CA_LCY_SUM содержит `avg, min, max` (без `сумм`), для ACT_1M — `min, max`.

### Task 5: Верификация и постобработка
**Depends on**: Tasks 1-4

1. `pytest tests/core/output/test_response_generator.py -v` — все тесты зелёные
2. `pytest tests/ -v` — нет регрессий
3. Обновить `devlog/changelog.json`

## Риски

| Сценарий | Вероятность | Воздействие | Действие |
|----------|-------------|-------------|----------|
| Alias-колонки не матчатся | высокая | нулевое | Fallback = все агрегаты, как сейчас |
| SQL уже агрегировал (GROUP BY) | средняя | нулевое | Alias не матчится → fallback; или матчится → фильтрация корректна |
| Новые поля без `aggregation_between_*` | низкая | нулевое | Нет match → fallback |
| Тест `test_numeric_other_row_contains_statistics` сломается | высокая | низкое | Обновить тест — теперь "Прочее" может не содержать `сумм=` для matched колонок |
| Увеличение промпта на ~500-1000 символов | средняя | низкое | В рамках cascade budget (15000) |

**Откат**: `git revert` — все изменения в 1 файле + тесты.

## Оценка масштаба

- **Файлы**: 1 модуль + 1 тестовый файл + devlog
- **Новый код**: ~60 строк (функции + константы)
- **Изменённый код**: ~30 строк (3 функции)
- **Новые тесты**: ~15
- **Обновлённые тесты**: 1-2 (existing aggregate tests)

## Рекомендация

Последовательное выполнение (Tasks 1→2→3→4→5). Все изменения в одном файле, нет смысла в параллелизации.
