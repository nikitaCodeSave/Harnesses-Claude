# Plan: Упрощение access control — отказ от row-level фильтрации

## Context

ADR-021 реализовал двухуровневую систему доступа: whitelist пользователей (YAML email→LOGIN) + row-level SQL-фильтрацию по DESK через Oracle. Row-level фильтрация больше не нужна — все пользователи получают полный доступ к `client_product`. Остаётся только контроль **кто может пользоваться ботом** (whitelist по email).

Сейчас параллельно существуют две системы: `ZULIP_ALLOWED_USERS` (JSON в .env, без hot-reload) и `access_rules.yaml` (hot-reload). Предложение: единый YAML-whitelist (`allowed_users.yaml`) с hot-reload, mtime-кэшем и wildcard `*@domain.com`.

**Итого:** удаляется ~1172 LOC (production + tests), добавляется ~130 LOC (`user_access.py` + тесты). 3 настройки → 1.

Источник: `docs/research/2026-03-25-access-control-simplification.md`

> Фаза 0 пропущена: задача — рефакторинг access control по верифицированному research-документу, текущее поведение зафиксировано в research.

## Анализ воздействия

| Модуль | Изменение | Риск | Зависимые |
|--------|-----------|------|-----------|
| `infrastructure/user_access.py` (NEW) | Новый модуль: `load_allowed_users()` + `is_user_allowed()` + mtime-кэш + `AccessDeniedError` | low | zulip_bot |
| `infrastructure/settings.py:200-207` | Убрать 3 поля, добавить 1 (`allowed_users_path`) | low | zulip_bot, agent |
| `presentation/zulip_bot.py` | Рефакторинг `is_user_allowed()` → делегация в `user_access`; убрать `allowed_users`/`allowed_domains` из `__init__`/`main()`; убрать `except AccessDeniedError`; убрать `user_email` из AIAgent() | medium | — |
| `application/agent.py:15-16,53,95-110,132,337` | Убрать `user_email`, `_access`, `resolve_access()` блок | medium | subquestion |
| `application/subquestion.py:25-26,40,148,181` | Убрать параметр `access` | low | — |
| `core/sql/validator.py:14,737,750,780,832` | Убрать параметр `access` из `_run_db_validation` и `validate_and_fix_sql` | low | — |
| `infrastructure/db_connector.py:14,17,82-93,96,110,138,153` | Убрать `_apply_access()`, параметр `access` из `validate_sql_syntax`/`execute_query` | medium | validator, subquestion |
| `infrastructure/request_tracker.py:22-25,69,79-82,110,127,135,212,232` | Убрать `access_info` параметр и desk-поля | low | analytics |
| `infrastructure/analytics.py:78-81,130-134,247-254,260-282,325,402-408` | Убрать desk-колонки, лист "По дэскам" (7→6 листов) | low | — |
| `infrastructure/access_config.py` | DELETE | — | — |
| `infrastructure/access_filter.py` | DELETE | — | — |

## Риски

| Сценарий | Вероятность | Действие |
|----------|-------------|----------|
| PyYAML не в pyproject.toml | high | Добавить `pyyaml>=6.0` в dependencies |
| Существующие JSON мониторинга с desk-полями | low | Старые файлы сохраняются, новые без desk — analytics обработает оба формата (проверка `if col in df.columns`) |
| Тесты ломаются после удаления access параметров | medium | Последовательная правка: сначала production code, потом тесты, прогон pytest между шагами |

## Задачи реализации

### Task 1: Создать `infrastructure/user_access.py` + тесты (TDD)
- **Files:** `infrastructure/user_access.py`, `tests/infrastructure/test_user_access.py`
- **Depends on:** none
- **Что делать:**
  - `AccessDeniedError` exception
  - `load_allowed_users(path) -> list[str]` с mtime-кэшем и `yaml.safe_load()`
  - `is_user_allowed(user_email) -> bool` с `fnmatch` для wildcard
  - Fail-closed: ошибка чтения → `return False`
  - Нет файла/пустой path → `return True` (доступ для всех)
  - Тесты: валидный YAML, wildcard matching, mtime-кэш, невалидный формат, FileNotFoundError, пустой path
- **Done when:** `pytest tests/infrastructure/test_user_access.py -v` — все зелёные

### Task 2: Обновить `settings.py` — заменить 3 настройки на 1
- **Files:** `infrastructure/settings.py`
- **Depends on:** Task 1
- **Что делать:**
  - Убрать `zulip_allowed_users`, `zulip_allowed_domains` (строки 200-201)
  - Убрать `access_rules_path` (строки 206-207)
  - Добавить `allowed_users_path: str = ""` (рядом с monitoring_dir)
- **Done when:** `pytest tests/infrastructure/test_settings.py -v` — зелёные (после правки тестов в Task 7)

### Task 3: Добавить `pyyaml>=6.0` в pyproject.toml
- **Files:** `pyproject.toml`
- **Depends on:** none
- **Done when:** `pyyaml` в `[project.dependencies]`

### Task 4: Убрать access из pipeline (agent → subquestion → validator → db_connector)
- **Files:** `application/agent.py`, `application/subquestion.py`, `core/sql/validator.py`, `infrastructure/db_connector.py`
- **Depends on:** Task 2
- **Что делать:**
  - `agent.py`: убрать TYPE_CHECKING import AccessInfo; убрать `user_email` из `__init__`; убрать блок resolve_access (строки 95-110); убрать `access=self._access` (строка 132); убрать `access_info=self._access` (строка 337)
  - `subquestion.py`: убрать TYPE_CHECKING import; убрать `access` параметр; убрать `access=access` из вызовов validate/execute
  - `validator.py`: убрать TYPE_CHECKING import; убрать `access` из `_run_db_validation` и `validate_and_fix_sql`; убрать `access=access` из вызовов
  - `db_connector.py`: убрать import `apply_access_filter`; убрать TYPE_CHECKING import AccessInfo; убрать `_apply_access()` staticmethod; убрать `access` параметр из `validate_sql_syntax`/`execute_query`; убрать вызовы `self._apply_access()`
- **Done when:** `pytest tests/ -v` — зелёные (основные тесты, часть access-тестов может ещё падать)

### Task 5: Рефакторить `zulip_bot.py` — делегация в user_access
- **Files:** `presentation/zulip_bot.py`
- **Depends on:** Task 1, Task 2, Task 4
- **Что делать:**
  - Убрать `from infrastructure.access_config import AccessDeniedError` (строка 22)
  - Убрать `allowed_users`/`allowed_domains` из `__init__` параметров и `self.*` (строки 128-129, 148-150, 191-192)
  - Рефакторить `is_user_allowed()` (строки 323-347) → вызов `from infrastructure.user_access import is_user_allowed as _is_user_allowed; return _is_user_allowed(user_email)`
  - Убрать `user_email=sender_email` из AIAgent() (строка 395)
  - Убрать `except AccessDeniedError` блок (строки 401-403)
  - В `main()`: убрать строки 720-721, 724-729, 746-747; добавить print allowed_users_path
- **Done when:** `zulip_bot.py` не импортирует access_config/access_filter

### Task 6: Убрать access_info из request_tracker и desk из analytics
- **Files:** `infrastructure/request_tracker.py`, `infrastructure/analytics.py`
- **Depends on:** Task 4
- **Что делать:**
  - `request_tracker.py`: убрать TYPE_CHECKING import; убрать `access_info` параметр из `_build_common_fields`, `build_request_rows`, `track_request`; убрать desk-поля (строки 79-82); убрать `access_info=access_info` из вызовов
  - `analytics.py`: убрать desk-колонки из review sheet (строки 78-81); убрать метрику дэсков из summary (строки 130-134); убрать desk merge из users sheet (строки 247-254); убрать `_build_desks_sheet()` целиком (строки 260-282); убрать вызов в generate (строки 405-408); обновить docstring (7→6 листов)
- **Done when:** grep `access_info` в request_tracker = 0; grep `_build_desks_sheet` в analytics = 0

### Task 7: Обновить тесты
- **Files:** `tests/infrastructure/test_request_tracker.py`, `tests/infrastructure/test_analytics.py`, `tests/presentation/test_zulip_logger.py`, `tests/infrastructure/test_settings.py`, `tests/application/test_subquestion.py`, `tests/core/sql/test_validator.py`
- **Depends on:** Tasks 4, 5, 6
- **Что делать:**
  - `test_request_tracker.py`: убрать asserts на desk-поля (строки 122-126); удалить `test_with_access_info` (строки 128-152)
  - `test_analytics.py`: убрать desk из фикстуры; убрать `test_columns_with_desk`; убрать `TestBuildDesksSheet`
  - `test_zulip_logger.py`: убрать `allowed_domains` из `_make_bot_and_client`; убрать domain ACL тесты; обновить `is_user_allowed` тесты
  - `test_settings.py`: убрать тесты `zulip_allowed_users`/`zulip_allowed_domains` парсинга
  - `test_subquestion.py`: убрать `access` из вызовов если есть
  - `test_validator.py`: убрать `access` из вызовов если есть
- **Done when:** `pytest tests/ -v` — все зелёные

### Task 8: Удалить файлы + создать allowed_users.yaml.example
- **Files:** DELETE: `infrastructure/access_config.py`, `infrastructure/access_filter.py`, `tests/infrastructure/test_access_filter.py`, `tests/infrastructure/test_access_config.py`, `access_rules.yaml`, `access_rules.yaml.example`; CREATE: `allowed_users.yaml.example`
- **Depends on:** Task 7 (все тесты зелёные)
- **Done when:** файлы удалены; `pytest tests/ -v` — зелёные; `allowed_users.yaml.example` создан

### Task 9: Обновить документацию + ADR-022 + devlog
- **Files:** `.env.example`, `docs/architecture.md`, `docs/configuration.md`, `CLAUDE.md`, `docs/decisions/ADR-022-access-simplification.md`, `devlog/changelog.json`
- **Depends on:** Task 8
- **Что делать:**
  - `.env.example`: убрать ZULIP_ALLOWED_USERS, ZULIP_ALLOWED_DOMAINS; заменить ACCESS_RULES_PATH → ALLOWED_USERS_PATH
  - `docs/architecture.md`: убрать access_config/access_filter из диаграмм и описаний; убрать шаг 0 из pipeline; убрать лист 7 из мониторинга
  - `docs/configuration.md`: убрать 3 настройки, добавить 1; убрать секцию Access Control YAML
  - `CLAUDE.md`: убрать access_config/access_filter из структуры; обновить описания; добавить user_access.py
  - ADR-022: отмена row-level фильтрации
  - Перенести `ADR-021`, `ADR-015` в `docs/archive/`
  - devlog: запись в changelog.json
- **Done when:** документация актуальна, ADR-022 создан

### Task 10: Верификация — pytest + live-тест
- **Files:** —
- **Depends on:** Task 9
- **Done when:** `pytest tests/ -v` — все зелёные; `python run_agent.py` — smoke-test пройден

## Рекомендация

**Последовательное выполнение.** Tasks 1+3 можно параллельно. Tasks 4+6 можно параллельно (разные файлы). Task 9 (документация) можно делегировать docs-sync агенту. Всего ~10 задач, основной объём — удаление кода.

Agent Teams рекомендуется для Task 9 (docs-sync) параллельно с Task 10 (верификация).
