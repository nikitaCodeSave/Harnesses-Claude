# План: удаление stdout эхо из ZulipLogger.emit()

## Контекст

В `ZulipLogger.emit()` (presentation/zulip_bot.py:106-110) каждое прогресс-событие дублируется в `sys.__stdout__` перед отправкой в Zulip. Это создаёт два бага:
1. **Критический**: `_should_skip_line()` применяется ПОСЛЕ эхо — отфильтрованные строки (разделители, пустые) всё равно попадают в stdout
2. **Архитектурный**: ZulipLogger не должен писать в stdout — его ответственность только Zulip. Серверное логирование обеспечивается через `logging` (log_setup.py → stdout_handler)

Решение: удалить блок `sys.__stdout__.write()` из `emit()`. Фильтрация останется только для Zulip-буфера.

## Task 1: Удалить stdout эхо из emit()

**Files:** `presentation/zulip_bot.py`
**Depends on:** none

Удалить строки 106-110:
```python
# Эхо в серверную консоль для отладки
_stdout = sys.__stdout__
if _stdout is not None:
    _stdout.write(message + "\n")
    _stdout.flush()
```

Также убрать `import sys` если он больше не используется в файле. Проверить — `sys` используется в `main()` (sys.exit), так что импорт остаётся.

**Done when:** `sys.__stdout__` отсутствует в zulip_bot.py

## Task 2: Добавить мета-тест запрета stdout в emit()

**Files:** `tests/application/test_callback.py`
**Depends on:** Task 1

Добавить тест, проверяющий что `zulip_bot.py` не содержит `sys.__stdout__`:
```python
def test_no_sys_stdout_in_zulip_bot():
    """zulip_bot.py should not use sys.__stdout__ (no echo to console)."""
    ...
    assert "sys.__stdout__" not in source
```

Это согласуется с существующими мета-тестами в test_callback.py (test_no_sys_stdout_assignment, test_no_sys_stdout_flush_in_agent).

**Done when:** тест проходит, `pytest tests/application/test_callback.py -v` зелёный

## Task 3: Обновить devlog

**Files:** `devlog/changelog.json`
**Depends on:** Task 1, Task 2

## Верификация

```bash
pytest tests/application/test_callback.py tests/presentation/test_zulip_logger.py -v
grep -n "sys.__stdout__" presentation/zulip_bot.py  # должен быть пуст
```

## Масштаб

- 1 файл изменяется (zulip_bot.py — удаление 5 строк)
- 1 файл дополняется (test_callback.py — 1 новый тест)
- 1 файл дополняется (devlog)
- Риск: LOW — удаление debug-эхо, не влияет на Zulip-доставку или logging
