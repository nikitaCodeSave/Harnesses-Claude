# Sync docs: INN formatting bugfix

## Context
Багфикс в `core/report/formatters.py` и `core/report/pdf_generator.py` добавил зависимость на `infrastructure/utils.is_id_column()`. Документация не отражает новые зависимости. Также нужно убрать точные цифры количества тестов из CLAUDE.md (быстро устаревают).

## Изменения

### 1. architecture.md — Mermaid-диаграмма (после строки 127)
Добавить рёбра:
```
PDFF --> UTL
PDF --> UTL
```

### 2. architecture.md — описание utils.py (строка 315)
Обновить список потребителей `is_id_column()`:
```
- `is_id_column()` — определение ID-колонок (INN, CUSTOMER_ID, *_ID) для исключения из числовой агрегации (используется в chart_builder, response_generator, formatters, pdf_generator)
```

### 3. architecture.md — граф зависимостей (строки 426-427)
```
+-- core/report/pdf_generator.py -------- infrastructure/output_config, infrastructure/utils, reportlab, core/report/formatters, core/report/styles, core/report/table_builder
|   +-- core/report/formatters.py ------- infrastructure/utils (форматирование значений и DataFrame)
```

### 4. CLAUDE.md — строка 140
Убрать точные цифры тестов, оставить суть:
```
Тестовое покрытие: pytest, структура зеркалирует src. Интеграционные тесты: `@pytest.mark.integration`, по умолчанию не запускаются (pyproject.toml `addopts`). Быстрый прогон: `pytest -m "integration and not slow"`.
```

## Файлы
- `docs/architecture.md` — 3 правки
- `CLAUDE.md` — 1 правка

## Проверка
Визуально проверить что Mermaid рендерится корректно (нет синтаксических ошибок в диаграмме).
