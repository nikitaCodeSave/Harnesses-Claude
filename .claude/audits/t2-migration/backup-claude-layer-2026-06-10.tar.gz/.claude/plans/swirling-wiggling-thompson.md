# План: Token-Budget каскадная обрезка промптов

## Контекст

Текущая каскадная обрезка имеет две проблемы:

1. **`generate_response()`**: 2 уровня (20 строк → 5) с лимитом 15000 символов. При контекстном окне 32K токенов используется ~5% контекста. Переход резкий, нет гарантии fit, при overflow промпт дублируется.

2. **`dataframe_to_text()`** (chart/code генераторы): хардкод 5 → 3 → 1. При `chart_max_rows=50` прыжок с 50 до 5 строк теряет 90% данных, хотя может влезть 30+ строк.

**Ключевой принцип:** каскад сокращает ТОЛЬКО размер таблицы данных. Системный промпт (инструкции, SQL, описания полей) — ВСЕГДА полный. Все 16 требований к ответу сохраняются.

---

## Часть A: generate_response()

### Шаг A1: Новые параметры в settings.py

**Файл:** `infrastructure/settings.py`

В `LLMSettings`:
```python
context_window_tokens: int = Field(default=32768, ge=1024, le=1048576)
```

Изменить дефолты:
- `response_max_prompt_length`: 15000 → **100000**
- `response_max_tokens`: 2000 → **3000**

В `DataDisplaySettings`:
```python
response_cascade_rows: list[int] = Field(default=[20, 10, 5, 3])
response_cascade_chars: list[int] = Field(default=[8000, 4000, 2000, 1500])
```

### Шаг A2: Тесты (TDD)

**Файл:** `tests/core/output/test_response_generator.py`

~10 тестов:
- `test_cascade_l0_fits_normal_data` — обычный DataFrame влезает в L0
- `test_cascade_escalates_for_large_data` — большой DataFrame падает на L1+
- `test_cascade_guarantees_fit` — промпт всегда ≤ бюджет
- `test_full_instructions_at_all_levels` — все 16 требований на каждом уровне
- `test_sql_context_preserved_at_all_levels` — SQL не зависит от каскада
- `test_fields_preserved_at_all_levels` — описания полей полные
- `test_statistics_never_truncated` — digest stats сохраняются
- `test_generate_response_backward_compatible` — сигнатура и mock не сломаны

### Шаг A3: Каскад данных в generate_response()

**Файл:** `core/output/response_generator.py`

#### Что НЕ меняется:
- Полный промпт со всеми 16 требованиями — ОДИН шаблон
- SQL обрезка как сейчас (>2000 → head+tail)
- Описания полей — полностью
- Python код — обрезка как сейчас (>800)
- `digest_to_prompt_text()`, `dataframe_to_digest()` — не трогаем

#### Новые функции:

**`_CascadeLevel`** (dataclass):
```python
@dataclass(frozen=True)
class _CascadeLevel:
    name: str           # "L0".."L3"
    max_rows: int       # для dataframe_to_digest
    max_data_chars: int # для digest_to_prompt_text
```

4 уровня (из `response_cascade_rows` / `response_cascade_chars`):

| Level | rows | data_chars | Описание |
|-------|------|-----------|----------|
| L0 | 20 | 8000 | Полные данные |
| L1 | 10 | 4000 | Средние данные |
| L2 | 5 | 2000 | Минимальные |
| L3 | 3 | 1500 | Emergency |

**`_build_prompt_within_budget()`** — основная функция:
```
1. char_budget = s.llm.response_max_prompt_length
2. Собрать ФИКСИРОВАННЫЕ части (всегда полные):
   - role + question + chart_info
   - SQL контекст (обрезка >2000, не зависит от каскада)
   - Описания полей (полностью)
   - Python код (обрезка >800, не зависит от каскада)
   - ВСЕ 16 инструкций
3. fixed_size = len(фиксированных частей)
4. data_budget = char_budget - fixed_size
5. for level in cascade_levels:
6.     data_text = digest_to_prompt_text(
7.         dataframe_to_digest(df, level.max_rows),
8.         max_chars=min(level.max_data_chars, data_budget)
9.     )
10.    if fixed_size + len(data_text) <= char_budget:
11.        log cascade level
12.        return assemble(fixed, data_text)
13. # Emergency: hard truncate data_text
```

#### Рефакторинг generate_response():
Строки 516-681 заменяются на:
```python
if fields_description is None:
    fields_description = _extract_and_describe_fields(sql) if sql else ""
prompt = _build_prompt_within_budget(question, df, sql, fields_description, python_code, chart_path)
```

Сигнатура `generate_response()` НЕ меняется.

---

## Часть B: dataframe_to_text() — бинарный поиск

### Шаг B1: Тесты

**Файл:** `tests/core/output/test_response_generator.py`

~4 теста:
- `test_dataframe_to_text_binary_search_optimal_rows` — при max_chars=2000 находит максимум строк, а не прыгает 5→3→1
- `test_dataframe_to_text_wide_dataframe_still_works` — DataFrame с 20 столбцами корректно обрезается
- `test_dataframe_to_text_small_fits_without_cascade` — маленький DataFrame без обрезки
- `test_dataframe_to_text_one_row_fallback` — если даже 1 строка > max_chars

### Шаг B2: Замена хардкод каскада на бинарный поиск

**Файл:** `core/output/response_generator.py`, строки 186-206

Текущий код (5 → 3 → 1):
```python
if len(text) > max_chars:
    if original_count > 5:
        processed_df = aggregate_remaining_rows(df, 5)
        ...
    if len(text) > max_chars:
        if original_count > 3:
            processed_df = aggregate_remaining_rows(df, 3)
            ...
    if len(text) > max_chars:
        if original_count > 1:
            text = df.head(1).to_string(index=False)
```

Новый код — бинарный поиск (как уже работает `digest_to_prompt_text()` строка 356):
```python
if len(text) > max_chars:
    # Бинарный поиск максимального количества строк, влезающих в max_chars
    lo, hi = 1, min(max_rows, original_count)
    while lo < hi:
        mid = (lo + hi + 1) // 2
        candidate_df = aggregate_remaining_rows(df, mid)
        candidate = candidate_df.to_string(index=False)
        if len(candidate) <= max_chars:
            lo = mid
        else:
            hi = mid - 1
    processed_df = aggregate_remaining_rows(df, lo)
    text = processed_df.to_string(index=False)
    text += f"\n\nПримечание: Показаны топ {lo} записей из {original_count}."

    # Fallback: если даже 1 строка + aggregate не влезает
    if len(text) > max_chars:
        text = df.head(1).to_string(index=False)
        text += f"\n\nПримечание: Показана 1 запись из {original_count} (ограничение размера)."
```

**Выигрыш:** при `chart_max_rows=50, chart_max_chars=8000` — вместо прыжка 50→5 бинарный поиск найдёт, например, 35 строк — максимум, влезающий в 8000 символов. Паттерн уже проверен в `digest_to_prompt_text()`.

---

## Часть C: Dev-утилита калибровки

### Шаг C1: Создать dev/calibrate_prompts.py

**Файл:** `dev/calibrate_prompts.py`

Скрипт:
1. Инициализирует LLMClient из .env
2. Рендерит шаблон промпта `generate_response` с минимальными данными (1 строка, фиктивный вопрос)
3. Вызывает `LLMClient.get_client().chat.completions.create(max_tokens=1)` напрямую
4. Читает `response.usage.prompt_tokens`
5. Выводит отчёт:
```
=== Калибровка промптов ===
Модель: GenAI/Qwen3-30B-A3B
Контекстное окно: 32768 токенов

response_generator (L0, минимальные данные):
  Промпт: 2150 символов → 780 prompt_tokens
  response_max_tokens: 3000
  Доступно: 32768 - 780 - 3000 = 28988 токенов на данные

response_generator (L0, 20 строк × 5 столбцов):
  Промпт: 8500 символов → 3200 prompt_tokens
  Итого: 3200 + 3000 = 6200 из 32768 (19% контекста)

Рекомендации для .env:
  AI_ANALYST_LLM__RESPONSE_MAX_PROMPT_LENGTH=100000  ✓ дефолт достаточен
  AI_ANALYST_LLM__RESPONSE_MAX_TOKENS=3000
```

**Запуск:** `python dev/calibrate_prompts.py`

---

## Часть D: Документация

- `.env.example`: обновить дефолты, добавить `context_window_tokens`
- `docs/configuration.md`: секция о каскаде и калибровке
- `devlog/changelog.json`: запись
- `docs/decisions/ADR-019-token-budget-cascade.md`: ADR (меняет поведение промптов)

---

## Критические файлы

| Файл | Изменение |
|------|-----------|
| `infrastructure/settings.py` | +3 поля, 2 дефолта |
| `core/output/response_generator.py` | A: каскад в generate_response() (~170 строк), B: бинарный поиск в dataframe_to_text() (~20 строк) |
| `tests/core/output/test_response_generator.py` | ~14 тестов |
| `dev/calibrate_prompts.py` | Новый файл |
| `.env.example` | 3 параметра |
| `docs/configuration.md` | Секция |
| `docs/decisions/ADR-019-token-budget-cascade.md` | Новый ADR |
| `devlog/changelog.json` | Запись |

## Порядок реализации

1. `settings.py` — параметры
2. Тесты (TDD) — A2 + B1
3. `dataframe_to_text()` — бинарный поиск (B2, проще, разогрев)
4. `generate_response()` — каскад (A3)
5. `pytest tests/ -v` — регрессии
6. `dev/calibrate_prompts.py` — утилита (C1)
7. Документация (D)

## Верификация

1. `pytest tests/core/output/test_response_generator.py -v` — новые тесты
2. `pytest tests/ -v` — регрессий нет
3. `python dev/calibrate_prompts.py` — реальные токены
4. `python run_agent.py` — live-тест:
   - Лог: "Cascade level L0, prompt 8500 chars (budget 100000)"
   - Все 16 требований в промпте
   - chart_generator: "Binary search: 35 of 50 rows fit in 8000 chars"
   - Качество ответов не хуже
