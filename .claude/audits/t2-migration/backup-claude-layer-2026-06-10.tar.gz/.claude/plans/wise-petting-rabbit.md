# Plan: Улучшенное логирование LLM-ошибок

## Context

**Проблема**: при сбоях LLM-сервера (таймауты, connection errors, 5xx) серверные логи содержат минимум информации — только `str(exception)` (например, "Connection error"). Нет HTTP статус-кода, нет контекста операции, нет request_id, нет структурированных логов для постанализа.

**Источник**: `docs/research/2025-02-25-llm-error-logging.md` — анализ прод-логов от 2026-02-25 (875 сек, 6/8 вызовов с ошибкой).

**Цель**: информативные ошибки с operation_name, defensive-распаковка OpenAI exceptions, типизированное исключение LLMCallError, JSONL-логирование (opt-in), request_id через contextvars.

---

## P0: Информативные ошибки + LLMCallError в llm_client.py

**Решает ~80% проблемы.** Единственный файл с новым кодом + обновление 8 call sites.

### Файлы

| Файл | Изменение |
|------|-----------|
| `infrastructure/llm_client.py` | LLMCallError, _format_llm_error(), operation_name, exc_info=True, raise...from |
| `core/sql/generator.py` | `operation_name="sql_generation"` в call_llm() (строка 136) |
| `core/sql/validator.py` | `operation_name="sql_validation"` в call_llm() (строка 365) |
| `core/analysis/question_analyzer.py` | `operation_name="question_analysis"` (строка 306), `operation_name="final_response"` (строка 523) |
| `core/output/chart_generator.py` | `operation_name="chart_generation"` (строка 406), `operation_name="chart_fix"` (строка 525) |
| `core/output/response_generator.py` | `operation_name="response_generation"` (строка 513) |
| `core/output/code_generator.py` | `operation_name="code_generation"` (строка 259), `operation_name="code_fix"` (строка 315) |

### Задачи

**Task P0-1: LLMCallError + _format_llm_error()** (~25 мин)
- Файл: `infrastructure/llm_client.py`
- Добавить `class LLMCallError(Exception)` с полями: operation, attempt, status_code. `__cause__` устанавливается через `raise ... from`.
- Добавить `def _format_llm_error(e: Exception) -> str` — defensive-распаковка:
  - `APIConnectionError` → `__cause__` (ConnectionRefusedError, SSLError и т.д.), НЕТ response
  - `APITimeoutError` → "timeout", НЕТ response
  - `APIStatusError` → `status_code` + тело ответа (первые 500 символов)
  - Остальные → `type(e).__name__: str(e)`
- Использовать `hasattr(e, 'response') and e.response is not None` перед обращением к response.*
- Done when: `_format_llm_error()` возвращает информативную строку для каждого типа исключения

**Task P0-2: Интеграция в call_llm()** (~20 мин)
- Файл: `infrastructure/llm_client.py`
- Добавить параметр `operation_name: str = ""` в сигнатуру `call_llm()`
- В retry warning (строки 140, 165): заменить `%s", e` на `%s [%s]: %s", ..., operation_name, _format_llm_error(e)`
- В финальных logger.error (строки 192, 204, 208): добавить `exc_info=True`
- Заменить 3 `raise Exception(...)` на `raise LLMCallError(..., operation=operation_name, ...) from last_exception`/`from e`
- Добавить `operation_name` в [PERF] лог (необязательно, но полезно)
- Done when: retry-лог содержит operation_name и _format_llm_error() вывод

**Task P0-3: Прокинуть operation_name во все 9 call sites** (~15 мин)
- 7 файлов (см. таблицу выше)
- Каждый call_llm(...) получает keyword argument `operation_name="<value>"`
- Значения: sql_generation, sql_validation, question_analysis, final_response, chart_generation, chart_fix, response_generation, code_generation, code_fix
- Done when: grep по `call_llm(` не находит вызовов без operation_name (кроме тестов)

**Task P0-4: Тесты P0** (~30 мин)
- Создать: `tests/infrastructure/test_llm_error_format.py`
- Тесты для `_format_llm_error()`:
  - APIConnectionError с `__cause__=ConnectionRefusedError` → содержит "ConnectionRefusedError"
  - APIConnectionError без `__cause__` → содержит "APIConnectionError"
  - APITimeoutError (нет response) → содержит "timeout"
  - APIStatusError (status_code=500, response.text) → содержит "500" и фрагмент body
  - APIStatusError с response.text > 500 символов → обрезает
  - Generic Exception → содержит type name
- Тесты для `LLMCallError`:
  - Поля operation, attempt, status_code заполняются
  - `isinstance(LLMCallError(...), Exception)` → True (backward compat)
  - `__cause__` устанавливается через `raise ... from`
- Тесты для operation_name в call_llm():
  - Mock call_llm() → проверить что LLMCallError.operation == "sql_generation"
  - Проверить что retry warning содержит operation_name
- Обновить: `tests/infrastructure/test_llm_retry.py`
  - Заменить `pytest.raises(Exception, match="Ошибка при вызове LLM")` на `pytest.raises(LLMCallError, ...)`
  - Проверить что `e.value.operation`, `e.value.attempt`, `e.value.status_code` корректны
- Done when: `pytest tests/infrastructure/test_llm_error_format.py tests/infrastructure/test_llm_retry.py -v` → все зелёные

### Риски P0

| Сценарий | Вероятность | Воздействие | Mitigation |
|----------|-------------|-------------|------------|
| Downstream `except Exception as e: str(e)` — текст сообщения изменился | medium | Тесты с match на текст сломаются | Прогнать ВСЕ unit-тесты перед коммитом. LLMCallError.__str__ = message, формат не меняется |
| test_llm_retry.py ловит `Exception`, не `LLMCallError` | high | 6 тестов сломаются | Task P0-4 обновляет эти тесты |
| call site пропущен (забыли добавить operation_name) | low | Без operation_name будет "" — не ломает, но неинформативно | grep -r "call_llm(" после P0-3 |

### Критерии готовности P0
- [x] `_format_llm_error()` покрыта тестами для 4 типов исключений
- [x] `LLMCallError` заменяет `Exception` во всех 3 exit-точках
- [x] `operation_name` передаётся во всех 9 call sites
- [x] `exc_info=True` в финальных logger.error (строки 192, 204, 208)
- [x] `raise ... from` сохраняет цепочку
- [x] `pytest tests/ -v` — все unit-тесты зелёные (включая обновлённый test_llm_retry.py)
- [x] Rollback: `git revert <commit>` (один коммит на всю фазу)

---

## P1: JSONL + configure_logging + request_id через contextvars

**Opt-in через `.env`.** Два новых файла + расширение settings + интеграция в agent.py.

### Файлы

| Файл | Изменение |
|------|-----------|
| `infrastructure/log_context.py` | **Новый**: ContextVar("request_id"), set/get |
| `infrastructure/log_setup.py` | **Новый**: JSONLFormatter, RequestIdFilter, configure_logging() |
| `infrastructure/settings.py` | Расширение LogSettings: error_file, error_file_max_bytes, error_file_backup_count, обновление format |
| `application/agent.py` | Заменить logging.basicConfig → configure_logging(), set_request_id() в process_question() |
| `presentation/zulip_bot.py` | set_request_id() в process_question() worker |
| `.env.example` | Добавить AI_ANALYST_LOG__ERROR_FILE |

### Задачи

**Task P1-1: log_context.py** (~10 мин)
- Файл: `infrastructure/log_context.py` (~20 LOC)
- `_request_id: ContextVar[str] = ContextVar("request_id", default="-")`
- `def set_request_id(rid: str) -> contextvars.Token`
- `def get_request_id() -> str`
- Done when: тесты set/get/default проходят

**Task P1-2: log_setup.py** (~30 мин)
- Файл: `infrastructure/log_setup.py` (~80 LOC)
- `JSONLFormatter(logging.Formatter)`:
  - `format(record)` → JSON-строка: `{"ts": ..., "level": ..., "logger": ..., "message": ..., "request_id": ..., "exc_type": ..., "traceback": ...}`
  - Использует `record.request_id` (добавляется RequestIdFilter)
- `RequestIdFilter(logging.Filter)`:
  - `filter(record)` → `record.request_id = get_request_id(); return True`
- `configure_logging(settings: LogSettings) -> None`:
  - **Идемпотентность**: проверяет `if root.handlers and any(isinstance(h, logging.StreamHandler) for h in root.handlers): return`
  - Или лучше: проверять наличие маркера `_configured` на root logger
  - Создать stdout StreamHandler с уровнем из settings
  - Подключить RequestIdFilter ко всем handlers
  - Если `settings.error_file`:
    - `os.makedirs(os.path.dirname(error_file), exist_ok=True)` (если dirname не пустой)
    - `RotatingFileHandler(error_file, maxBytes=..., backupCount=...)` с уровнем ERROR
    - `JSONLFormatter` на file handler
- Done when: configure_logging() не дублирует handlers при повторном вызове; JSONL валиден

**Task P1-3: Расширение LogSettings** (~10 мин)
- Файл: `infrastructure/settings.py`
- Добавить в `LogSettings`:
  - `error_file: str = ""` (пусто = выключено)
  - `error_file_max_bytes: int = 10_485_760` (10 MB)
  - `error_file_backup_count: int = 3`
- Обновить `format` default: `"%(asctime)s - %(name)s - %(levelname)s - [%(request_id)s] %(message)s"`
- Done when: `get_settings().log.error_file == ""`; формат содержит request_id

**Task P1-4: Интеграция в agent.py + zulip_bot.py** (~20 мин)
- Файл: `application/agent.py`
  - Заменить строки 31-37 (`logging.basicConfig(...)`) на `from infrastructure.log_setup import configure_logging; configure_logging(get_settings().log)`
  - В `process_question()` (строка 309 area): `from infrastructure.log_context import set_request_id; set_request_id(self.request_id)`
- Файл: `presentation/zulip_bot.py`
  - В `process_question()` worker (после генерации request_id, строка ~424): `from infrastructure.log_context import set_request_id; set_request_id(request_id)`
  - **Важно**: `ContextVar` в ThreadPoolExecutor — contextvars **копируются** из parent thread в Python 3.12+ через `executor.submit()`. В Python 3.10-3.11 нужно вызывать `set_request_id()` внутри worker-функции. Т.к. request_id уже генерируется внутри worker (`process_question`), достаточно `set_request_id()` после его генерации.
- Done when: request_id виден в stdout-логах при запуске через run_agent.py; JSONL пишется при установке AI_ANALYST_LOG__ERROR_FILE

**Task P1-5: Тесты P1** (~25 мин)
- Создать: `tests/infrastructure/test_log_context.py`
  - set/get request_id
  - default == "-"
  - Изоляция: после set в одном ContextVar, другой thread видит default (через threading)
- Создать: `tests/infrastructure/test_log_setup.py`
  - JSONLFormatter: output — валидный JSON с ts, level, logger, message, request_id
  - JSONLFormatter: с exc_info → содержит traceback
  - RequestIdFilter: добавляет request_id в LogRecord
  - configure_logging() идемпотентен: вызвать 2 раза → количество handlers не удваивается
  - configure_logging() с error_file: создаёт директорию (tmpdir), RotatingFileHandler добавлен
  - configure_logging() без error_file: только stdout handler
- Обновить: `tests/application/` — если есть тесты, ловящие logging.basicConfig
- Done when: `pytest tests/infrastructure/test_log_context.py tests/infrastructure/test_log_setup.py -v` → зелёные

### Риски P1

| Сценарий | Вероятность | Воздействие | Mitigation |
|----------|-------------|-------------|------------|
| configure_logging() конфликтует с ZulipLogger (перехватывает stdout) | medium | Логи Zulip дублируются или теряются | ZulipLogger заменяет sys.stdout → StreamHandler(sys.stdout) увидит исходный stdout до подмены. Порядок: configure_logging() вызывается в agent.py import-time, ZulipLogger подменяет позже. Протестировать вручную |
| ContextVar не копируется в thread (Python <3.12) | low | request_id == "-" в worker | set_request_id() вызывается ВНУТРИ worker-функции → работает в любой версии |
| format с %(request_id)s при отсутствии RequestIdFilter | medium | KeyError при форматировании | RequestIdFilter подключается ко ВСЕМ handlers в configure_logging(). Но если кто-то вызовет logging.basicConfig напрямую → проблема. Убрать basicConfig, использовать только configure_logging() |

### Критерии готовности P1
- [x] `configure_logging()` идемпотентен (тест)
- [x] `configure_logging()` создаёт mkdir для error_file (тест)
- [x] JSONLFormatter выдаёт валидный JSON (тест)
- [x] request_id виден в stdout-логах в формате `[<request_id>]`
- [x] JSONL пишется ТОЛЬКО при AI_ANALYST_LOG__ERROR_FILE (тест)
- [x] `pytest tests/ -v` — все unit-тесты зелёные
- [x] .env.example обновлён
- [x] Rollback: `git revert <commit>`

---

## P2: exc_info=True в ключевых downstream-модулях

**Минимальная фаза.** Только модули, где traceback не дублирует llm_client.

### Файлы

| Файл | Строки | Изменение |
|------|--------|-----------|
| `infrastructure/db_connector.py` | 55, 72, 143, 166 | Добавить `exc_info=True` в 4 logger.error() |
| `core/output/code_validator.py` | 107, 119, 131, 143 | Добавить `exc_info=True` в 4 logger.error() (exec-ошибки содержат сгенерированный код) |

### Задачи

**Task P2-1: exc_info=True в db_connector.py** (~10 мин)
- 4 правки: строки 55 (`"Ошибка подключения"`), 72 (`"Ошибка при закрытии"`), 143 (`"Ошибка при выполнении запроса"`), 166 (`"Ошибка проверки подключения"`)
- Done when: все 4 logger.error содержат exc_info=True

**Task P2-2: exc_info=True в code_validator.py** (~10 мин)
- 4 правки: строки 107 (SyntaxError), 119 (NameError), 131 (KeyError), 143 (generic Exception)
- Done when: все 4 logger.error в except-блоках содержат exc_info=True

**Task P2-3: Тесты P2** (~10 мин)
- Опционально: убедиться что существующие тесты для db_connector и code_validator не ломаются
- `pytest tests/ -v` → зелёные
- Done when: регрессий нет

### Риски P2

| Сценарий | Вероятность | Воздействие | Mitigation |
|----------|-------------|-------------|------------|
| Увеличение объёма логов в проде | low | Больше текста в stdout | exc_info=True только в ERROR-уровне, это ожидаемо при ошибках |

### Критерии готовности P2
- [x] 8 logger.error() в двух файлах содержат exc_info=True
- [x] `pytest tests/ -v` → зелёные

---

## Критерии приёмки всего изменения

1. **retry/error логи содержат operation_name**: `Retry 1/3 через 1s [sql_generation]: ...`
2. **Ошибки OpenAI распаковываются безопасно**: `_format_llm_error()` не падает при отсутствии response (APIConnectionError, APITimeoutError)
3. **request_id есть в stdout и JSONL**: формат `[20260225_100109_8579f6c3_user10801]`, default="-"
4. **JSONL включается только через AI_ANALYST_LOG__ERROR_FILE**: `error_file=""` → нет JSONL handler
5. **configure_logging() не дублирует handlers при повторном вызове**: тест идемпотентности
6. **LLMCallError сохраняет backward compat**: `isinstance(LLMCallError(...), Exception)` → True

---

## Масштаб

| Метрика | Значение |
|---------|----------|
| Новые файлы | 2 (log_context.py, log_setup.py) |
| Изменённые файлы | 11 (llm_client, 7 call sites, settings, agent, .env.example) + 2 (P2: db_connector, code_validator) |
| Новые тест-файлы | 3 (test_llm_error_format, test_log_context, test_log_setup) |
| Обновляемые тесты | 1 (test_llm_retry.py) |
| Оценочных тестов | ~25-30 новых тестов |

---

## Верификация (после каждой фазы)

```bash
# Unit-тесты
pytest tests/ -v

# Lint/type check (если настроен)
ruff check .

# Live-тест (после P0 и P1)
python dev/test-connection.py
python run_agent.py  # задать вопрос, проверить формат логов

# Интеграционные (при доступности Oracle + Ollama)
pytest -m "integration and not slow"
```

**Post-implementation:**
- `/verify` — полный pipeline verification
- `/review` — multi-perspective code review
- Обновить docs/configuration.md (новые параметры LogSettings)
- Обновить devlog/changelog.json

---

## Рекомендация

**Последовательное выполнение P0 → P1 → P2.** P0 — самостоятельная ценность, можно мержить отдельно. P1 зависит от P0 (operation_name в логах). P2 независима, но логически завершает картину.

Agent Teams не нужны — фазы имеют зависимости, параллелизация внутри фаз минимальна.
