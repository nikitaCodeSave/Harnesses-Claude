# План: перенос _configure_logging() из module-level в точки входа

## Контекст

`application/agent.py:36` вызывает `_configure_logging(get_settings().log)` на уровне модуля. Это side-effect при импорте: любой `from application.agent import AIAgent` триггерит инициализацию логирования и создание settings-синглтона. Это ломает lazy-singleton паттерн settings и делает поведение неявным.

## Изменения

### 1. `application/agent.py` — удалить module-level вызов

- Удалить строку 36: `_configure_logging(get_settings().log)`
- Удалить строку 31: `from infrastructure.log_setup import configure_logging as _configure_logging`
- Оставить остальные импорты без изменений

### 2. `presentation/cli.py` — добавить configure_logging

В `main()`, после успешного импорта и валидации settings, перед созданием AIAgent:
```python
from infrastructure.log_setup import configure_logging
configure_logging(s.log)
```

### 3. `presentation/zulip_bot.py` — добавить configure_logging

В module-level (после импортов, перед `logger = logging.getLogger`), или лучше в `main()`:
```python
from infrastructure.log_setup import configure_logging
configure_logging(get_settings().log)
```
Важно: `logger = logging.getLogger(__name__)` на строке 27 — это нормально, он просто создаёт logger без handlers. Handlers добавятся после `configure_logging()`.

### 4. `presentation/batch_cli.py` — добавить configure_logging

В `main()`, после загрузки settings:
```python
from infrastructure.log_setup import configure_logging
configure_logging(s.log)
```

## Файлы

| Файл | Действие |
|------|----------|
| `application/agent.py` | Удалить строки 31, 36 |
| `presentation/cli.py` | Добавить вызов configure_logging в main() |
| `presentation/zulip_bot.py` | Добавить вызов configure_logging в main() |
| `presentation/batch_cli.py` | Добавить вызов configure_logging в main() |

## Проверка

1. `pytest tests/ -v` — все unit-тесты проходят (тесты не зависят от module-level configure_logging, у них своя фикстура `_clean_root_logger`)
2. `python -c "from application.agent import AIAgent"` — импорт без side-effects (не должен создавать handlers на root logger)
3. `python run_agent.py` — логирование работает как прежде
