# Fix: двойное логирование в reports.py + print() в zulip_bot.py

## Контекст

Два hygiene-фикса из code review:
1. `save_dataframes_to_excel()` логирует ошибку (L135) и re-raises → caller `generate_reports()` ловит и логирует повторно (L337). Дублирование.
2. `ZulipBot.run()` (L503-509) — startup banner через `print()`, должен быть `logger.info()`.

Не трогаем (by design / pre-existing):
- `infrastructure/progress.py:49` — print в console fallback, by design
- `zulip_bot.py` `main()` — это entry point, print() допустим по code-style rules
- `zulip_bot.py:90` — `_should_skip_line`, pre-existing

## Задачи

### Task 1: Убрать двойное логирование Excel в reports.py

**Файл:** `application/reports.py`

Убрать `logger.error` на L337 — `save_dataframes_to_excel` уже логирует ошибку на L135. В caller оставить только `pass` (или просто убрать лишний лог, оставив `except`).

Текущий код (L330-338):
```python
with PerfTimer("excel_export", timings):
    try:
        excel_filename = save_dataframes_to_excel(...)
        logger.info("[Шаг 7] Excel файл создан: %s", excel_filename)
    except Exception as e:
        logger.error("[Шаг 7] Ошибка при создании Excel файла: %s", e)  # ДУБЛЬ
```

После:
```python
with PerfTimer("excel_export", timings):
    try:
        excel_filename = save_dataframes_to_excel(...)
        logger.info("[Шаг 7] Excel файл создан: %s", excel_filename)
    except Exception:
        pass  # Ошибка уже залогирована в save_dataframes_to_excel
```

### Task 2: print() → logger в ZulipBot.run()

**Файл:** `presentation/zulip_bot.py`

Заменить `print()` на `logger.info()` в методе `run()` (L503-509). Форматирование баннера адаптировать для logger (без `\n` обёрток, каждая строка — отдельный вызов).

## Проверка

```bash
pytest tests/application/ tests/presentation/ -v
```

## Масштаб

2 файла, 0 новых тестов (поведенческих изменений нет).
