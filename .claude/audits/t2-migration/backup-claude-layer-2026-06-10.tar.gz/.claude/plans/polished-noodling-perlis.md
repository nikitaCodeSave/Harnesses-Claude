# План: Техническое логирование для мониторинга

## Context

До запуска на реальных пользователей нужно сохранять ВСЕ логи (не только ERROR) в машиночитаемом формате. Сейчас INFO/WARNING уходят только в stdout и теряются. LLM-метрики и тайминги пайплайна логируются текстом — нет возможности парсить через `jq`. request_id в Zulip bot устанавливается после первого log-сообщения.

Источник: `.claude/plans/composed-waddling-allen.md`

## Group 1: Структурированное логирование всех уровней

### 1.1 Новые поля в LogSettings
**Файл**: `infrastructure/settings.py:149-156`
- Добавить `all_file`, `all_file_max_bytes`, `all_file_backup_count` (opt-in, пусто = выключено)

### 1.2 Обогащение JSONLFormatter
**Файл**: `infrastructure/log_setup.py:28-42`
- Добавить поля `module`, `func`, `line` в JSON
- Добавить поддержку `extra={"perf": {...}}` → `perf` в JSON

### 1.3 All-level JSONL handler
**Файл**: `infrastructure/log_setup.py:82-96` (после error handler)
- Новый `RotatingFileHandler` с level=DEBUG, аналогично error handler
- opt-in: если `all_file` пустой — handler не создаётся

### 1.4 .env.example
**Файл**: `.env.example:144` (после ERROR_FILE секции)

### Тесты Group 1
**Файл**: `tests/infrastructure/test_log_setup.py` — добавить 5 тестов

## Group 2: Структурированные метрики

### 2.1 PerfTimer: extra perf field
**Файл**: `infrastructure/perf_timer.py:41` — добавить `extra={"perf": {...}}`

### 2.2 llm_client: DRY helper + structured perf
**Файл**: `infrastructure/llm_client.py`
- Добавить `_log_llm_perf()` helper (строка ~125)
- Заменить 10 call sites `logger.info("[PERF] LLM: ...")` на вызов helper
- Текстовый вывод stdout идентичен текущему

### Тесты Group 2
- `tests/infrastructure/test_perf_timer.py` — 1 тест (perf extra в LogRecord)
- `tests/infrastructure/test_llm_client.py` (новый файл) — 2 теста (_log_llm_perf с/без usage)

## Group 3: request_id от точки входа

### 3.1 Ранний request_id в Zulip bot
**Файл**: `presentation/zulip_bot.py:357-378`
- Переместить генерацию request_id и set_request_id ПЕРЕД первым logger.info

## Постобработка
- `docs/configuration.md` — 3 новых параметра
- `devlog/changelog.json` — запись

## Верификация
1. `pytest tests/ -v` — все тесты проходят (существующие + новые)
2. `ruff check` на изменённых файлах
3. Import check: `python -c "from infrastructure.log_setup import configure_logging; ..."`
4. Smoke: `python run_agent.py` + `jq 'select(.perf)' logs/all.jsonl`
