# План: улучшение системы логирования для пост-анализа ошибок

## Контекст

На проде LLM-сервер нестабилен — один запрос обрабатывался 875 секунд, из которых ~750s ушло на безрезультатные retry. Из логов невозможно понять причину: видно только `Connection error.` без типа исключения, HTTP-деталей, traceback. Логи пишутся только в stdout — после закрытия терминала теряются. Нет JSONL-файла для автоматического анализа ошибок.

## Изменения (4 фазы, каждая независимо деплоится)

### Фаза 1: информативные ошибки в llm_client.py

**Файл:** `infrastructure/llm_client.py`

Добавить helper `_format_llm_error(e)` — формирует строку с типом исключения и HTTP-деталями:
- `APIConnectionError` → показать `__cause__` (реальная причина: ConnectionRefusedError, timeout, etc.)
- `APITimeoutError` → пометить "timeout"
- `APIStatusError` → показать `status_code` + тело ответа (первые 500 символов)
- Остальные → `type(e).__name__` + `str(e)`

Применить `_format_llm_error()` в:
- строка 140: retry warning
- строка 165: retry warning (5xx)
- строки 192, 204, 208: logger.error + добавить `exc_info=True`

Сохранить цепочку исключений — `raise ... from last_exception` (строки 193, 205, 209).

**Было:** `Retry 1/3 через 1s: Connection error.`
**Станет:** `Retry 1/3 через 1s: APIConnectionError | cause=ConnectionRefusedError: [Errno 111] Connection refused`

### Фаза 2: JSONL-файл для ERROR+ записей

**Новый файл:** `infrastructure/log_setup.py` (~50 LOC)
- `JSONLFormatter` — форматирует LogRecord как JSON-строку: `ts`, `level`, `logger`, `message`, `exception_type`, `traceback`, `request_id`
- `configure_logging()` — создаёт stdout handler + опциональный `RotatingFileHandler` (ERROR+, JSONL)

**Изменить:** `infrastructure/settings.py` — расширить `LogSettings`:
```python
error_file: str = ""          # пусто = отключено; "output/errors.jsonl"
error_file_max_bytes: int = 10_485_760  # 10 MB
error_file_backup_count: int = 3
```

**Изменить:** `application/agent.py` строки 31-37 — заменить `logging.basicConfig(...)` на:
```python
from infrastructure.log_setup import configure_logging
configure_logging()
```

Фича opt-in (default отключена через `error_file=""`). Включается в `.env`:
```
AI_ANALYST_LOG__ERROR_FILE=output/errors.jsonl
```

### Фаза 3: exc_info=True во всех downstream-модулях

Добавить `exc_info=True` ко всем `logger.error()` внутри `except` блоков (~25 мест в 11 файлах):

| Файл | Кол-во правок |
|------|--------------|
| `infrastructure/db_connector.py` | 4 |
| `core/sql/validator.py` | 2 (только внутри except) |
| `core/sql/generator.py` | 1 |
| `core/output/chart_generator.py` | 5 |
| `core/output/response_generator.py` | 1 |
| `core/output/code_generator.py` | 2 |
| `core/output/code_validator.py` | 2 (только внутри except) |
| `core/report/pdf_generator.py` | 1 |
| `core/analysis/question_analyzer.py` | 2 |
| `application/reports.py` | проверить (может уже есть) |
| `presentation/zulip_bot.py` | проверить |

Механическое изменение, без риска регрессии.

### Фаза 4: request_id в лог-записях через contextvars

**Новый файл:** `infrastructure/log_context.py` (~25 LOC)
- `ContextVar("request_id", default="-")`
- `set_request_id(request_id)` / `get_request_id()`
- `RequestIdFilter(logging.Filter)` — добавляет `request_id` в каждый LogRecord

**Изменить:** `infrastructure/log_setup.py` — подключить `RequestIdFilter` ко всем handlers.

**Изменить:** `infrastructure/settings.py` — обновить формат:
```
%(asctime)s - %(name)s - %(levelname)s - [%(request_id)s] %(message)s
```

**Изменить:** `application/agent.py` (`process_question`) — `set_request_id(self.request_id)`

**Было:** `2026-02-25 10:01:59 - infrastructure.llm_client - WARNING - Retry 1/3...`
**Станет:** `2026-02-25 10:01:59 - infrastructure.llm_client - WARNING - [20260225_100109_8579f6c3_user10801] Retry 1/3...`

## Тесты

- `tests/infrastructure/test_llm_error_format.py` — `_format_llm_error()` для каждого типа исключения + проверка `__cause__` в raised exception
- `tests/infrastructure/test_log_setup.py` — `JSONLFormatter` выдаёт валидный JSON; `configure_logging()` с/без error_file
- `tests/infrastructure/test_log_context.py` — `RequestIdFilter` добавляет request_id в LogRecord

## Порядок реализации и коммиты

1. **Фаза 1** — llm_client.py + тесты (быстрый win, 1 файл)
2. **Фаза 3** — exc_info=True (механические правки, 11 файлов)
3. **Фаза 2** — JSONL error file (новый модуль, settings, agent.py)
4. **Фаза 4** — request_id в логах (новый модуль, settings, agent.py)
5. **Docs** — .env.example, configuration.md, CLAUDE.md, devlog

## Верификация

1. `pytest tests/ -v` — все unit-тесты проходят после каждой фазы
2. Ручной тест: установить `AI_ANALYST_LOG__ERROR_FILE=output/errors.jsonl`, запустить `python run_agent.py`, задать вопрос → проверить что errors.jsonl содержит структурированные записи
3. Симуляция ошибки: временно указать несуществующий LLM URL → проверить что в логах и JSONL видно полную информацию об ошибке
