# Plan: Обновление pipeline_walkthrough.ipynb с аудитом токенов и truncation

## Context

Notebook `dev/pipeline_walkthrough.ipynb` — основной инструмент для трассировки 8-шагового пайплайна. Текущая версия:
- Использует простой вопрос с 1 подвопросом
- Не показывает размеры промптов и потребление токенов
- Не отслеживает каскадную обрезку данных перед LLM
- Не отражает последние изменения: ADR-017 (chart_builder), ADR-018 (df_merger), digest-based truncation

Исследование `docs/research/2026-03-02-llm-token-consumption-e2e-analysis.md` выявило 8 проблем (P1-P8) с потреблением токенов и обрезкой данных. Notebook должен их визуализировать.

## Подход

Полная перезапись notebook с сохранением 8-шаговой структуры, но с добавлением:
1. Settings dashboard — все лимиты в одной таблице
2. Сложный вопрос для 2-3+ подвопросов
3. Token audit после каждого LLM-вызова
4. Digest introspection — что именно видит LLM vs исходный DataFrame
5. Автоматический цикл по всем подвопросам (вместо ручного SUBQ_INDEX)
6. Итоговая сводка потребления токенов и проблем P1-P8

## Файл для изменения

`dev/pipeline_walkthrough.ipynb` — полная перезапись (единственный файл)

## Структура ячеек (по секциям)

### Секция 0: Инициализация (cells 0-9)

| # | Тип | Содержание |
|---|-----|------------|
| 0 | md | Заголовок v2: с аудитом токенов, multi-subquestion, ADR-017/018 |
| 1 | md | ## 0. Инициализация |
| 2 | code | Импорты, sys.path, load_dotenv, get_settings, print DSN/models |
| 3 | code | LLMClient.initialize |
| 4 | code | DB connector (create_db_connector, test, connect) |
| 5 | code | logging.basicConfig + PerfTimer import |
| 6 | md | ## 0.1 Settings Dashboard |
| 7 | code | **НОВОЕ**: Таблица всех LLMSettings + DataDisplaySettings через pd.DataFrame + display. Помечает P1/P4/P6/P8 |
| 8 | md | ## 0.2 Вопрос |
| 9 | code | QUESTION = сложный вопрос (структура доходов + ВЭД + динамика активности по топ-N клиентам за 3 мес). Печать длины в chars и est tokens |

### Секция 1: Проверка релевантности (cells 10-13)

| # | Тип | Содержание |
|---|-----|------------|
| 10 | md | ## Шаг 1. Проверка релевантности (0 LLM) |
| 11 | code | check_relevance() с PerfTimer |
| 12 | code | Детали: совпавшие ключевые слова |
| 13 | code | assert is_relevant |

### Секция 2: Анализ вопроса (cells 14-17)

| # | Тип | Содержание |
|---|-----|------------|
| 14 | md | ## Шаг 2. Анализ вопроса (1 LLM call) |
| 15 | code | analyze_question() с PerfTimer |
| 16 | code | **НОВОЕ**: TOKEN AUDIT — размер промпта analyze_question (~17K chars), est tokens, completion tokens, P7 (статические инструкции = N% бюджета) |
| 17 | code | Вывод подвопросов с длиной каждого |

### Секция 3: Обработка подвопросов — авто-цикл (cells 18-24)

| # | Тип | Содержание |
|---|-----|------------|
| 18 | md | ## Шаг 3. Обработка подвопросов (5-шаговый pipeline) — описание шагов |
| 19 | code | Импорты для ручного прохода (все функции из sql/generator, extraction, validator, chart_builder, chart_generator, response_generator, field_search, metadata, output_config) + инициализация metadata, table_name, `llm_call_log = []`, `subquestion_results = []` |
| 20 | code | **КЛЮЧЕВАЯ ЯЧЕЙКА** — автоматический цикл по ВСЕМ подвопросам. Для каждого: |

Детали ячейки 20 (большой цикл):

```
for subq_idx, subq in enumerate(subquestions):
    === 3.1 SQL Generation ===
    - find_relevant_fields_vector_search + get_key_fields
    - _build_sql_generation_system_prompt → измерить len(sql_prompt)
    - Печать: chars, est tokens, sql_max_prompt_length, WARNING P3 если превышен
    - call_llm → raw_llm_response
    - llm_call_log.append(...)
    - extract_sql_from_response

    === 3.2 SQL Validation ===
    - validate_and_fix_sql
    - Печать: valid, changed, time

    === 3.3 DB Execution ===
    - db.execute_query → df
    - Печать: rows, cols, display(df.head(10))

    === 3.4 Chart Generation ===
    - build_chart (deterministic first)
    - Если None → generate_chart (LLM fallback) + audit log

    === 3.5 Response Generation + DIGEST INTROSPECTION ===
    - dataframe_to_digest(df) → digest (без override — default max_rows)
    - digest_to_prompt_text(digest) → data_text
    - ПЕЧАТЬ: digest.total_rows, len(top_rows), numeric_stats (каждый столбец), text_stats
    - DATA LOSS: len(df.to_string()) vs len(data_text) → процент потерь
    - extract_fields_from_sql + get_relevant_fields_description
    - Оценка размера промпта: ~2500 (инструкции) + sql + data_text + fields_desc
    - response_max_prompt_length check → БУДЕТ ЛИ TRUNCATION?
    - Если да: показать cascade: default_max_rows → response_prompt_max_rows, default_max_chars → response_prompt_max_chars, P2/P5
    - generate_response() с PerfTimer
    - llm_call_log.append(...)
    - Печать: ответ (preview), тайминги

    === Save result ===
    - subquestion_results.append({question, answer, sql, df, chart_path, timings})
```

| 21 | code | Вывод всех графиков подвопросов |
| 22 | md | ### Промежуточный аудит LLM-вызовов |
| 23 | code | **НОВОЕ**: pd.DataFrame(llm_call_log) → display. Итого est tokens, response chars |

### Секция 4: Объединение DataFrame (cells 24-27)

| # | Тип | Содержание |
|---|-----|------------|
| 24 | md | ## Шаг 4. Объединение DataFrames (ADR-018: deterministic / LLM fallback) |
| 25 | code | Сбор DataFrames + печать shapes |
| 26 | code | auto_merge_dataframes → если None, LLM fallback (generate_python_code + validate + execute) + audit log для P6 |
| 27 | code | display(final_df) |

### Секция 5: Итоговый график (cells 28-30)

| # | Тип | Содержание |
|---|-----|------------|
| 28 | md | ## Шаг 5. Итоговый график |
| 29 | code | build_chart (deterministic) → generate_chart (LLM fallback) |
| 30 | code | display Image |

### Секция 6: Финальный ответ (cells 31-34)

| # | Тип | Содержание |
|---|-----|------------|
| 31 | md | ## Шаг 6. Финальный ответ — Path A vs Path B, P4 |
| 32 | code | **НОВОЕ**: Path detection + digest introspection для final_df + P4 аудит (2000 vs 6000 max_tokens). generate_response или generate_final_response + llm_call_log |
| 33 | code | Печать финального ответа |

### Секция 7-8: Экспорт (cells 34-37)

| # | Тип | Содержание |
|---|-----|------------|
| 34 | md | ## Шаг 7. Excel + Шаг 8. PDF |
| 35 | code | save_dataframes_to_excel |
| 36 | code | create_pdf_document |

### Секция 9: Итоговая сводка (cells 37-43)

| # | Тип | Содержание |
|---|-----|------------|
| 37 | md | ## Итоговая сводка: токены, truncation, проблемы |
| 38 | code | **НОВОЕ**: Полная таблица LLM-вызовов (pd.DataFrame(llm_call_log)) — operation, prompt_chars, est_tokens, max_tokens, response_chars, time, truncation |
| 39 | code | **НОВОЕ**: Визуализация каскада truncation (P5) — для каждого df показать размеры на уровнях 20→5→3→1 |
| 40 | code | **НОВОЕ**: Таблица проблем P1-P8 с severity и описанием |
| 41 | code | Тайминги пайплайна (format_timing_summary) + результаты подвопросов |
| 42 | code | Финальный ответ + файлы (Excel, PDF, charts) |
| 43 | code | db.disconnect() |

## Ключевые изменения vs текущий notebook

| Аспект | Было | Стало |
|--------|------|-------|
| Вопрос | Простой, 1 подвопрос | Сложный, 2-3+ подвопросов |
| Settings | Не видны | Dashboard в cell 7 |
| Цикл подвопросов | Ручной SUBQ_INDEX | Автоматический for-loop |
| Промпты | Частичная видимость | Размер каждого + est tokens |
| Truncation | Не отслеживается | Cascade levels + data loss % |
| Digest | Частичная видимость | Полный: stats, top_rows, text_stats |
| Аудит токенов | Нет | llm_call_log после каждого вызова |
| Проблемы P1-P8 | Нет | Помечены в dashboard + итоговая таблица |

## Структура `llm_call_log`

```python
llm_call_log = []  # Аккумулятор по всему notebook

# Каждая запись:
{
    'subq': int,             # 0=global, 1+=subquestion
    'operation': str,        # sql_generation, sql_fix, response_generation, chart_generation, code_generation, final_response
    'prompt_chars': int,     # len(prompt)
    'est_prompt_tokens': int,# prompt_chars // 3.5
    'max_tokens': int,       # setting applied
    'response_chars': int,   # len(response)
    'time_s': float,
    'truncation': str,       # NONE / TRUNCATED (P2/P5) / P3: no check / P6: no check
}
```

## Функции для переиспользования

Все функции уже существуют в кодовой базе:
- `dataframe_to_digest(df, max_rows)` — `core/output/response_generator.py:216`
- `digest_to_prompt_text(digest, max_chars)` — `core/output/response_generator.py:292`
- `dataframe_to_text(df, max_rows, max_chars)` — `core/output/response_generator.py:153`
- `_build_sql_generation_system_prompt(...)` — `core/sql/generator.py`
- `extract_fields_from_sql(sql)` — `core/output/response_generator.py:373`
- `get_relevant_fields_description(...)` — `core/sql/field_search.py`
- `find_relevant_fields_vector_search(...)` — `core/sql/field_search.py`
- `get_key_fields(table_name)` — `core/sql/field_search.py`
- `format_timing_summary(timings, detail_timings)` — `infrastructure/perf_timer.py`

## Верификация

1. `python dev/test-connection.py` — Oracle + Ollama доступны
2. Запустить notebook через Jupyter: `jupyter notebook dev/pipeline_walkthrough.ipynb`
3. Проверить что:
   - Settings dashboard отображается корректно
   - Вопрос генерирует 2+ подвопросов
   - Все LLM-вызовы логируются в llm_call_log
   - Digest introspection показывает numeric_stats и data loss %
   - Итоговая таблица содержит все LLM-вызовы
   - P1-P8 помечены в dashboard и итоговой таблице
   - Excel и PDF генерируются
