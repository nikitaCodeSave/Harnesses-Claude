# План: удаление legacy completions API из llm_client.py

## Контекст

В `call_llm()` есть параметр `use_chat` с двумя ветками: chat completions API (`use_chat=True`) и legacy completions API (`use_chat=False`). Legacy ветка — мёртвый код: ни один модуль в production не вызывает `call_llm(use_chat=False)`. Код дублирует логику (вызов API → извлечение результата → finish_reason → логирование), усложняет поддержку. ADR-001 явно фиксирует: "ни один модуль не вызывает call_llm с use_chat=False".

## Изменения

### 1. `infrastructure/llm_client.py` — удалить legacy ветку

- Удалить параметр `use_chat` из сигнатуры `call_llm()` (строка 170)
- Удалить упоминание `use_chat` из docstring (строка 181)
- Удалить ветку `else` (строки 226-239) — оставить только chat completions путь
- Убрать `if use_chat:` (строка 205) — код chat completions становится единственным путём

### 2. `tests/infrastructure/test_llm_retry.py` — удалить `TestCompletionsApiRetry`

- Удалить класс `TestCompletionsApiRetry` (строки 314-345)
- Удалить хелпер `_make_completion_response` если он есть (нет — он в другом файле)

### 3. `tests/infrastructure/test_llm_token_logging.py` — удалить completions-тесты

- Удалить хелпер `_make_completion_response()` (строки 49-66)
- Удалить класс `TestCompletionsTokenUsageLogging` (строки 208-250)
- Удалить класс `TestCompletionsFinishReasonWarning` (строки 258-295)

### 4. `docs/decisions/ADR-001-dev-environment.md` — обновить раздел 3

- Раздел "3. use_chat=False" (строка 40-42): заменить на пометку что legacy API удалён, используется только chat completions

### 5. `devlog/changelog.json` — добавить запись

## Верификация

```bash
# 1. Unit-тесты
pytest tests/infrastructure/test_llm_client.py tests/infrastructure/test_llm_retry.py tests/infrastructure/test_llm_token_logging.py -v

# 2. Все unit-тесты (регрессия)
pytest tests/ -v

# 3. Grep — убедиться что use_chat нигде не осталось
grep -rn "use_chat" infrastructure/ core/ application/ presentation/ tests/
```
