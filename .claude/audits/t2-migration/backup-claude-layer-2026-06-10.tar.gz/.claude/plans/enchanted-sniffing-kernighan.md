# Рефакторинг presentation/zulip_bot.py — SDK-нативное упрощение

## Context

После добавления outer retry-loop + resilient HTTP adapter (commit-in-progress, 1244 unit-тестов зелёные, verified live on demo-ai-analyst.zulipchat.com), в коде бота остались три артефакта, которые избыточны относительно того что предоставляет `python-zulip-api` SDK:

1. **Самодельная дедупликация `self.last_message_id`** дублирует SDK-нативный `last_event_id` трекинг (`zulip/__init__.py:798`: `last_event_id = max(last_event_id, int(event["id"]))`).
2. **Две копии `zulip.Client`** (`self._event_client` + `self.client`) появились как workaround против дублей `send_message` при SDK retry. Теперь POST исключён из `urllib3.Retry.allowed_methods` в нашем `_build_resilient_session` (`presentation/zulip_bot.py:70`) — HTTP-уровень защищает от дублей.
3. **Клиент-сайд фильтрация** `message["type"] != "private"` (`zulip_bot.py:647`) выполняется вручную; Zulip API поддерживает `narrow=[["is","dm"]]` в `register()` — сервер сам отфильтрует не-DM до event queue.

Цель — уменьшить объём кода, убрать дубли state, делегировать фильтрацию серверу. SDK-нативные API (`call_on_each_event`, `retry_on_errors`, `has_connected`) покрывают все эти потребности. Ожидаемый выигрыш: ~40 строк кода, одно «true» место управления event queue, меньше трафика от сервера.

---

## Behavioral scenarios (фиксируем ДО кода)

Каждая задача изменяет код только если все перечисленные сценарии остаются валидными.

### Scenarios после всех 3 задач

| # | GIVEN | WHEN | THEN |
|---|---|---|---|
| S1 | Bot запущен, alice@corp в allowlist | alice → DM "вопрос про клиента X" | Ровно одно "✅ принят в обработку", progress-updater редактирует message, финальный ответ + PDF/Excel |
| S2 | Бот только что отправил Alice "✅ принят" | SDK доставляет событие о *собственном* исходящем DM бота (narrow `is:dm` включает их) | `sender_email == self.bot_email` → ранний return; handler не вызывается; self-loop отсутствует |
| S3 | Бот подписан на стрим `#general` | Пользователь постит в стрим `@bot help` | Event queue сервером отфильтрован; wrapper/handler не вызывается; лога нет |
| S4 | Event loop активен | SDK бросает `UnrecoverableNetworkError` (SSL EOF) | Outer retry в `run()` ловит → `_recreate_client()` → sleep(backoff) → resume. Новая очередь регистрируется, `last_event_id` стартует с баузлайна сервера; возможный gap в событиях за время обрыва — приемлем |
| S5 | Alice отправляет 3 DM подряд за 500ms | SDK доставляет 3 события с уникальными `event["id"]` | Все 3 обрабатываются (никакой самодельной dedup); `last_event_id` монотонно растёт внутри SDK |
| S6 | Alice отправляет `/help`, `/status`, `/analytics month 2026-03` | Event → wrapper → handle_message | `/help` — синхронный ответ; `/status` — синхронный с pool info; `/analytics` — `executor.submit(_handle_analytics, ...)` |
| S7 | Вопрос обработан успешно, `pdf_path` существует | `send_file` вызывается | `upload_file` через единый `self.client`; markdown-link в DM |
| S8 | Сетевой 502 на send_message | HTTPAdapter НЕ ретраит POST (allowed_methods исключает POST); SDK c `retry_on_errors=False` тоже не ретраит | Исключение пробрасывается → возвращается `None` → лог warning. Дубли невозможны |
| S9 | Сетевой 503 на update_message (PATCH) | HTTPAdapter ретраит (PATCH в allowed_methods) | Успех после retry |
| S10 | `__init__` с невалидным API key | `get_profile()` возвращает `{"result":"error"}` | `raise Exception(...)` → `main()` → exit(1). `has_connected` НЕ выставляется до успешной проверки |

---

## Task breakdown

Порядок: от самого безопасного к самому структурному. Каждая задача — **отдельный коммит**, между ними — **unit + ruff + манульный smoke на demo-zulip**.

### Task 1 — Упростить `has_connected` cleanup (Goal #3) [~15 мин]

**Файлы**: `presentation/zulip_bot.py:214-291`

**Суть**: `has_connected=True` устанавливается в двух местах (inline в `__init__:241` и в `_new_client:282`). Факторизовать в `_new_client`, убедиться что флаг выставляется **только после** успешного `get_profile()` в __init__ (mitigation R4).

**Изменения**:
- В `__init__`: создать клиент через `_new_client(retry_on_errors=True)` без has_connected, вызвать `get_profile()`, если успех — `self._event_client.has_connected = True`. Send-клиент симметрично через `_new_client(retry_on_errors=False)`.
- `_new_client` перестать автоматически выставлять `has_connected=True` — это делает caller после валидации.
- Или проще: оставить как есть, но задокументировать в docstring `_new_client` что он safe для использования только post-validation.

**Tests**: unit suite остаётся зелёным без изменений (поведение идентично).

**Verify**: `pytest tests/presentation/ -x` → 112 passed. `ruff check`.

**Rollback**: `git revert`.

---

### Task 2 — narrow + удалить last_message_id (Goal #1) [~30 мин]

**Файлы**:
- `presentation/zulip_bot.py:253, 635-665, 790-800`
- `tests/presentation/test_zulip_logger.py:495-546, 877-889`
- `tests/presentation/test_zulip_resilience.py` (только имя метода в TestRunRetryLoop, существенных изменений нет т.к. оба клиента ещё живы)

**Изменения**:
1. `zulip_bot.py:253` — удалить `self.last_message_id = -1`.
2. `handle_message:635` — удалить проверки `message["type"] != "private"` (`:647-648`) и `message["id"] <= self.last_message_id` + её обновление (`:651-655`). **Оставить** `sender_email == self.bot_email` (`:643`) — сервер narrow `is:dm` включает самосообщения.
3. `run():800` — заменить:
   ```python
   self._event_client.call_on_each_message(self.handle_message)
   ```
   на:
   ```python
   self._event_client.call_on_each_event(
       lambda event: self.handle_message(event["message"]),
       event_types=["message"],
       narrow=[["is", "dm"]],
   )
   ```
4. Добавить startup-лог: `logger.info("Zulip narrow: is:dm (server-side filter)")`.

**Tests**:
- **DELETE** `test_zulip_logger.py:504-513` `test_ignores_duplicate_message_id`.
- **DELETE** `test_zulip_logger.py:539-546` `test_updates_last_message_id`.
- **DELETE** `test_zulip_logger.py:495-502` `test_ignores_non_private_messages` (фильтрация теперь на сервере).
- **UPDATE** `test_zulip_logger.py:877-889` `test_run_uses_event_client` → переименовать `test_run_uses_call_on_each_event`; проверить `call_on_each_event.called`, `kwargs == {"event_types": ["message"], "narrow": [["is","dm"]]}`.
- **UPDATE** `test_zulip_logger.py:529` `test_help_command` → убрать строку `bot.last_message_id = -1`.
- **UPDATE** `test_zulip_resilience.py::TestRunRetryLoop` (7 тестов, 262-397) — глобальный rename `call_on_each_message` → `call_on_each_event`. Fixture `bot_for_run` менять не надо.

**Verify**:
- `pytest tests/presentation/ -v -x`
- `ruff check`
- **Manual smoke** (demo-zulip, 5 мин):
  1. Запустить бота: `python zulip_bot.py`
  2. С другого аккаунта Zulip → DM `/help` → ответ ≤ 5s
  3. Запостить в стрим где бот присутствует — бот НЕ отвечает (сервер отфильтровал)
  4. 3 быстрых DM подряд → все 3 получают "✅ принят в обработку"
- Прогон `dev/test_zulip_resilience.py proxy` + SIGUSR1/USR2 → бот переживает (regression).

**Rollback**: `git revert` — `last_message_id` и client-side фильтры возвращаются.

---

### Task 3 — Объединить event и send клиентов (Goal #2) [~45 мин]

**Файлы**:
- `presentation/zulip_bot.py:214-291, 285-291, 775-831`
- `tests/presentation/test_zulip_logger.py:823-900` (TestDualClient + test_recreate)
- `tests/presentation/test_zulip_resilience.py:170-208` (TestZulipBotConfiguresResilientSessions) и `388-397` (test_run_recreates_*)

**Изменения**:
1. `__init__`: создать единственный `self.client = self._new_client(retry_on_errors=False)` (**R2 mitigation** — SDK retry не должен реплеить POST; наш outer retry достаточен). Затем `get_profile` → `has_connected = True`.
2. Удалить `self._event_client` (строки 222-223).
3. Удалить `_recreate_event_client()` (289-291). `_recreate_client()` остаётся единственным.
4. `run()` 790, 800, 827 — заменить все `self._event_client` на `self.client`; вызов `_recreate_event_client()` → `_recreate_client()`.
5. Docstring `_new_client` обновить — больше не «с прогретым has_connected», caller сам управляет.

**Tests**:
- **UPDATE** `test_zulip_logger.py:823-852` `TestDualClient` → переименовать в `TestSingleClient`, тесты:
  - `test_client_created_with_retry_disabled`: `mock_cls.call_count == 1`, `retry_on_errors=False`.
  - **DELETE** `test_event_client_created_with_retry_enabled` — больше не актуален.
- **UPDATE** `test_zulip_logger.py:891-900` `test_recreate_client_sets_has_connected` — оставить, `bot.client.has_connected is True`.
- **UPDATE** `test_zulip_resilience.py:170-208` TestZulipBotConfiguresResilientSessions (3 теста) — `mock_cls.call_count == 1`, `mock_config.call_count == 1`; **DELETE** `test_recreate_event_client_rebuilds_with_resilient_session`, оставить `test_recreate_client_configures_session`.
- **UPDATE** `test_zulip_resilience.py:388-397` `test_run_recreates_event_client_between_attempts` → `test_run_recreates_client_between_attempts`; patch `_recreate_client`.

**Verify**:
- `pytest tests/presentation/ -v -x`
- `ruff check`
- **Manual smoke** (demo-zulip, 10 мин):
  1. Запустить бота; `/help`, `/status`, DM с вопросом — все сценарии S1, S6, S7.
  2. `dev/test_zulip_resilience.py proxy` + SIGUSR1 → recovery → SIGUSR2 → send_message после recovery НЕ дублируется (проверить количество сообщений у отправителя).
  3. Оставить бота на 10 минут под прокси (без kill) — убедиться что long-poll стабилен.

**Rollback**: `git revert` — возвращает dual-client архитектуру. Task 1+2 остаются valid.

---

### Task 4 — Automated live integration tests [~30 мин]

**Новые файлы**: `tests/presentation/test_zulip_bot_live.py`

**Зачем**: ловить регрессии narrow-фильтрации, self-loop и single-client в CI-подобном режиме. По умолчанию skip (требует env `AI_ANALYST_ZULIP_LIVE=1` + demo credentials в `.env`).

**Pattern** (gated fixture):
```python
@pytest.fixture
def live_bot():
    if not os.getenv("AI_ANALYST_ZULIP_LIVE"):
        pytest.skip("set AI_ANALYST_ZULIP_LIVE=1 to run live tests")
    # launch ZulipBot in background thread...
```

**Test cases**:
- `test_bot_replies_to_help_dm` — второй `zulip.Client` (test-user creds) отправляет DM `/help`, через `get_messages` narrow `sender:bot, is:dm` ждёт ответа ≤ 10s.
- `test_bot_ignores_own_outgoing_dm` — проверить что после того как бот отправил сообщение, он не реагирует на него через event queue (нет повторных ответов в 5s окне).
- `test_bot_ignores_stream_messages` — post в стрим; ждать 5s; 0 ответов от бота.
- `test_register_uses_narrow_is_dm` — monkeypatch `zulip.Client.register` (через intercept на единственном `self.client`), проверить что narrow в вызове `[["is","dm"]]`.

**Регистрация маркера**: в `pyproject.toml` секция `[tool.pytest.ini_options] markers = ["live: marks tests as requiring live Zulip server"]`.

**Verify**:
- `pytest tests/ -q` (без live env) — skip'ы видны, остальные green.
- `AI_ANALYST_ZULIP_LIVE=1 pytest -m live tests/presentation/test_zulip_bot_live.py -v` — все 4 зелёные.
- **Финальный manual checklist** (§E2E ниже).

**Rollback**: удалить файл — production не затронут.

---

## E2E test plan

### Automated (Task 4)
`tests/presentation/test_zulip_bot_live.py` — 4 кейса, gated `AI_ANALYST_ZULIP_LIVE=1`. Ожидает наличия test-user credentials и demo-ai-analyst.zulipchat.com. Не запускается в CI по умолчанию.

### Manual checklist (после Task 3 и после Task 4)

```
□ Запуск: python zulip_bot.py — в логах "Бот подключен как ai-analyst-bot@demo-ai-analyst.zulipchat.com", "Zulip narrow: is:dm"
□ С второго Zulip-аккаунта: DM /help — help text ≤ 5s
□ DM /status — статус + pool info
□ DM /analytics — Excel-файл прилетает (может упасть если в dev нет всех данных — ок)
□ DM с произвольным вопросом — "✅ принят", progress-editing, финальный ответ
□ Пост в стрим, где бот присутствует — бот молчит
□ 3 быстрых DM подряд — все 3 получают "✅ принят"
□ Во время обработки одного DM отправить второй — второй встаёт в очередь, не теряется
□ Ctrl+C — в логах "👋 Бот остановлен пользователем", executor.shutdown, pool.close
```

### Resilience regression
```
□ Терминал 1: python dev/test_zulip_resilience.py proxy --port 9443
□ Терминал 2: HTTPS_PROXY=http://127.0.0.1:9443 HTTP_PROXY=http://127.0.0.1:9443 NO_PROXY=localhost python zulip_bot.py
□ Терминал 3: kill -USR1 <proxy_pid> — в логах бота warnings про retries, но процесс ЖИВ
□ Подождать 30с
□ kill -USR2 <proxy_pid> — event loop восстанавливается, новые CONNECT в логах прокси
□ Отправить DM с второго аккаунта — ответ приходит (бот работает)
```

---

## Risk matrix

| # | Риск | Likelihood | Impact | Mitigation |
|---|---|---|---|---|
| R1 | `narrow=[["is","dm"]]` не поддерживается старым Zulip-сервером (используется `is:private` до feature level 247) | Medium | Бот не получает сообщений | В Task 2 проверить feature_level: `self._event_client.feature_level >= 247`; если меньше — fallback на `[["is","private"]]`. Demo-zulip современный, на проде — проверить перед merge. |
| R2 | SDK `retry_on_errors=True` ретраит POST на 5xx → дубль `send_message` | High при retry_on_errors=True | Дубли сообщений пользователю | **Использовать `retry_on_errors=False` в unified client (Task 3).** Outer retry loop в `run()` покрывает event loop resilience. HTTPAdapter защищает update/upload. |
| R3 | Удаление `last_message_id` открывает гонку при re-register event queue (BAD_EVENT_QUEUE_ID) | Low | Возможно повторное сообщение пользователю одного DM | SDK гарантирует монотонный `last_event_id` в рамках очереди. При queue rebirth сервер даёт свежий baseline. В логах ловить warnings "duplicate processing" через request_id. Приемлемо. |
| R4 | `has_connected=True` выставлен ДО `get_profile()` → реальный auth error трактуется как retryable | Low | Бот уходит в retry-loop вместо чёткого fail | Task 1: явно выставлять `has_connected=True` ТОЛЬКО после успеха `get_profile`. Unit-тест `test_init_raises_on_profile_failure`. |
| R5 | Live-тесты (Task 4) флейкают из-за rate limits demo-сервера | Medium | Ложные красные | Gated env-var; unique timestamps в test DMs; не в CI. |

---

## Rollback plan

- Каждая задача — отдельный коммит, ревертится независимо.
- Task 1 rollback: чисто cosmetic, без tests changes.
- Task 2 rollback: возвращает dedup + client-side фильтры. Tasks 3,4 откатятся автоматом если были.
- Task 3 rollback: возвращает dual-client. Task 2 остаётся (narrow + без last_message_id).
- Task 4 rollback: удалить файл.
- Emergency full: `git revert <task1>..<task4>` в обратном порядке; 1244 unit-тест зелёные на пре-refactor коммите.

---

## Critical files to modify

- `/home/nikita/PROJECTS/AI_analyst_for_work/AI_analyst_migration/presentation/zulip_bot.py`
- `/home/nikita/PROJECTS/AI_analyst_for_work/AI_analyst_migration/tests/presentation/test_zulip_logger.py`
- `/home/nikita/PROJECTS/AI_analyst_for_work/AI_analyst_migration/tests/presentation/test_zulip_resilience.py`
- `/home/nikita/PROJECTS/AI_analyst_for_work/AI_analyst_migration/tests/presentation/test_zulip_bot_live.py` (NEW)
- `/home/nikita/PROJECTS/AI_analyst_for_work/AI_analyst_migration/pyproject.toml` (live marker)

**Existing utilities to reuse** (не пересоздавать):
- `_make_bot_and_client()` в `tests/presentation/test_zulip_logger.py` — возвращает mock где оба клиента = один MagicMock, идеально для single-client перехода.
- `_make_bot()`, `_BOT_KWARGS`, `_mock_zulip_client()` в `tests/presentation/test_zulip_resilience.py` (после simplify-pass) — можно расширить для live-тестов.
- `dev/test_zulip_resilience.py` CONNECT-прокси — регрессионный инструмент для Task 2 и Task 3.
- `_build_resilient_session`, `_configure_client_session`, `_new_client` в `presentation/zulip_bot.py` — остаются без изменений.

**SDK reference** (read-only):
- `/home/nikita/PROJECTS/AI_analyst_for_work/AI_analyst_migration/.venv/lib/python3.12/site-packages/zulip/__init__.py` — ключевые точки: `call_on_each_event:718`, `register:1138`, `last_event_id:798`, `has_connected:508,638,663`, `do_api_query:560-691` (retry matrix).

---

## Verification checklist (после всех 4 задач)

```
□ pytest tests/ -q — все unit-тесты зелёные (ожидается 1244 - 3 удалённых + 4 новых live-тестов = ~1245 collected, 4 skipped без AI_ANALYST_ZULIP_LIVE)
□ ruff check — all checks passed
□ python dev/test-connection.py — Oracle + Ollama доступны
□ python zulip_bot.py — подключается к demo, в логах narrow
□ Manual checklist выше — все пункты пройдены
□ Resilience regression checklist — event loop переживает SIGUSR1/USR2
□ AI_ANALYST_ZULIP_LIVE=1 pytest -m live — 4 зелёных
□ devlog/changelog.json — новая запись
□ docs/architecture.md — раздел про Zulip-бот обновлён (narrow, single client)
```
