# План: /analytics range YYYY-MM-DD YYYY-MM-DD

## Context

Система мониторинга (ADR-014) поддерживает фильтрацию `/analytics month YYYY-MM`, но нет фильтрации по произвольному диапазону дат. Пользователи хотят выгружать аналитику за конкретный период (например, последние 2 недели). Поле `date` уже хранится в формате YYYY-MM-DD — фильтрация через лексикографическое сравнение строк.

**Research:** `docs/research/2026-03-12-analytics-range-date-filter-implementation.md`

## Затронутые файлы

| Файл | Изменение |
|------|-----------|
| `infrastructure/request_tracker.py:223` | +`start_date`, `end_date` в `load_all_rows()` |
| `infrastructure/analytics.py:265` | Пробросить `start_date`/`end_date` в `generate_analytics_excel()` |
| `presentation/zulip_bot.py:486,583` | Подкоманда `range` в `_handle_analytics()` + help-текст |
| `tests/infrastructure/test_request_tracker.py` | +4 теста фильтрации по дате |
| `tests/infrastructure/test_analytics.py` | +1 тест проброса параметров |
| `tests/presentation/test_zulip_analytics.py` | +3 теста (range, invalid date, start>end) |

## Реализация (TDD, последовательно)

### Task 1: Тесты + реализация `load_all_rows()` — start_date/end_date

**Файл:** `infrastructure/request_tracker.py`

Сигнатура:
```python
def load_all_rows(
    month: str | None = None,
    user_id: str | None = None,
    start_date: str | None = None,   # NEW: "YYYY-MM-DD"
    end_date: str | None = None,     # NEW: "YYYY-MM-DD"
) -> list[dict[str, Any]]:
```

Фильтр — после существующего фильтра `user_id` (строка 274), перед `all_rows.append(row)`:
```python
row_date = row.get("date", "")
if start_date and row_date < start_date:
    continue
if end_date and row_date > end_date:
    continue
```

**Тесты** (`tests/infrastructure/test_request_tracker.py`, класс `TestLoadAllRows`):
- `test_filter_by_date_range` — 3 записи (dec-10, dec-15, dec-20), range 12-12..12-18 → 1 строка
- `test_filter_by_start_date_only` — start_date="2025-12-15" → 2 строки (15, 20)
- `test_filter_by_end_date_only` — end_date="2025-12-15" → 2 строки (10, 15)
- `test_filter_by_date_range_empty` — range вне данных → []

**Проверка:** `pytest tests/infrastructure/test_request_tracker.py -v`

---

### Task 2: Тесты + реализация `generate_analytics_excel()` — пробросить

**Файл:** `infrastructure/analytics.py`

Сигнатура:
```python
def generate_analytics_excel(
    month: str | None = None,
    user_id: str | None = None,
    start_date: str | None = None,   # NEW
    end_date: str | None = None,     # NEW
    output_filename: str | None = None,
) -> str:
```

Вызов (строка 289):
```python
rows = load_all_rows(month=month, user_id=user_id,
                     start_date=start_date, end_date=end_date)
```

Filename (строки 296-301): добавить `start_date`/`end_date` в parts:
```python
if start_date:
    parts.append(f"from_{start_date}")
if end_date:
    parts.append(f"to_{end_date}")
```

**Тест** (`tests/infrastructure/test_analytics.py`, новый класс `TestGenerateAnalyticsExcelDateRange`):
- `test_passes_date_range_to_load_all_rows` — mock `load_all_rows`, проверить kwargs

**Проверка:** `pytest tests/infrastructure/test_analytics.py -v`

---

### Task 3: Тесты + реализация `_handle_analytics()` — подкоманда range

**Файл:** `presentation/zulip_bot.py`

В `_handle_analytics()` (после строки 513, elif detail):
```python
start_date = None
end_date = None

# В блоке парсинга (строки 505-513):
elif subcmd == "range":
    if len(parts) >= 4:
        raw_start, raw_end = parts[2], parts[3]
        # Валидация формата
        try:
            datetime.strptime(raw_start, "%Y-%m-%d")
            datetime.strptime(raw_end, "%Y-%m-%d")
        except ValueError:
            self.send_message(sender_email,
                "❌ Неверный формат даты. Используйте: `/analytics range YYYY-MM-DD YYYY-MM-DD`")
            return
        if raw_start > raw_end:
            self.send_message(sender_email,
                "❌ Начальная дата больше конечной.")
            return
        start_date, end_date = raw_start, raw_end
    else:
        self.send_message(sender_email,
            "❌ Укажите обе даты: `/analytics range YYYY-MM-DD YYYY-MM-DD`")
        return
```

Вызов `generate_analytics_excel` (строка 523):
```python
path = generate_analytics_excel(month=month, user_id=user_id,
                                start_date=start_date, end_date=end_date)
```

Описание (строки 524-528):
```python
if start_date and end_date:
    desc_parts.append(f"Период: {start_date} — {end_date}")
```

Help-текст (строка 589): добавить строку:
```
- `/analytics range YYYY-MM-DD YYYY-MM-DD` - аналитика за период
```

**Тесты** (`tests/presentation/test_zulip_analytics.py`):
- `TestHandleAnalyticsRangeFilter.test_handle_analytics_range_filter` — "/analytics range 2025-12-01 2025-12-31" → mock проверяет start_date/end_date
- `TestHandleAnalyticsRangeInvalidDate.test_handle_analytics_range_invalid_date` — невалидная дата → send_message с ошибкой
- `TestHandleAnalyticsRangeStartAfterEnd.test_handle_analytics_range_start_after_end` — "2025-12-31 2025-12-01" → ошибка

**Проверка:** `pytest tests/presentation/test_zulip_analytics.py -v`

---

### Task 4: Верификация и постобработка

1. `pytest tests/ -v` — все unit-тесты зелёные
2. Запись в `devlog/changelog.json`

## Решения по потенциальным проблемам

| Проблема | Решение |
|----------|---------|
| `month` + `start_date/end_date` одновременно | Composable — оба фильтра применяются. Документировать в docstring |
| Оптимизация директорий для date range | НЕ делать в MVP (мало данных). Отдельная задача при необходимости |
| Невалидный формат даты от пользователя | `datetime.strptime` в `_handle_analytics`, ошибка пользователю |
| `start_date > end_date` | Ошибка пользователю в Zulip. В `load_all_rows` — молча пустой список |
| ADR | Не нужен — расширение API без изменения архитектуры |

## Масштаб

~40-60 строк кода, ~8 новых тестов, 6 файлов
