# Phase 1: Skip-флаги в существующем коде для batch mode

## Context

Для batch-тестирования (прогон списка вопросов) нужно пропускать генерацию файлов (chart/excel/pdf) и merge dataframes — экономия времени и диска. Также нужно возвращать timings из `process_question()` (сейчас только логируются). Это Phase 1 из [batch-mode-design.md](docs/research/2026-02-27-batch-mode-design.md).

Все изменения backward-compatible: новые параметры с defaults сохраняют текущее поведение.

## Затронутые файлы

| Файл | Изменение |
|------|-----------|
| `application/subquestion.py` | + `generate_charts: bool = True` |
| `application/reports.py` | + `generate_charts/generate_excel/generate_pdf: bool = True` |
| `application/agent.py` | + `skip_files: bool = False`, пропуск шага 4, timings в return, forward флагов |
| `tests/application/test_skip_files.py` | Новый файл с тестами |

**Без изменений:** presentation/cli.py, presentation/zulip_bot.py, core/*, infrastructure/* — все вызывают с defaults.

## Задачи

### Task 1: `subquestion.py` — параметр `generate_charts`

**Files:** `application/subquestion.py`
**Depends on:** none

Изменения:
1. Добавить параметр `generate_charts: bool = True` в сигнатуру `process_single_subquestion()` (строка 23)
2. Обернуть блок chart generation (строки 174-188) в `if generate_charts:`
3. Если `not generate_charts` — пропускаем PerfTimer("chart_gen") целиком, `chart_path` остаётся `None`

**Done when:** `generate_charts=False` → `generate_chart()` не вызывается, result["chart_path"] = None.

### Task 2: `reports.py` — параметры skip для шагов 5, 7, 8

**Files:** `application/reports.py`
**Depends on:** none (параллельно с Task 1)

Изменения в `generate_reports()` (строка 213):
1. Добавить параметры: `generate_charts: bool = True`, `generate_excel: bool = True`, `generate_pdf: bool = True`
2. Шаг 5 (строки 254-272): обернуть в `if generate_charts:` — иначе `final_chart_path = None`
3. Шаг 7 (строки 327-335): обернуть в `if generate_excel:` — иначе `excel_filename = None`
4. Шаг 8 PDF (строки 351-373): обернуть в `if generate_pdf:` — иначе пропуск pdf_path

**Done when:** при `generate_charts/excel/pdf=False` соответствующие функции не вызываются.

### Task 3: `agent.py` — `skip_files` + timings в return

**Files:** `application/agent.py`
**Depends on:** Task 1, Task 2

Изменения:

**3a. Сигнатура `process_question`** (строка 286):
```python
def process_question(self, question: str, skip_files: bool = False) -> dict[str, Any]:
```

**3b. Forward `generate_charts` в subquestion pipeline:**
- `process_single_subquestion` wrapper (строка 93): добавить `generate_charts: bool = True` param, прокинуть в `_process_single_subquestion()`
- `_process_subquestions` (строка 109): добавить `generate_charts: bool = True` param, прокинуть в `self.process_single_subquestion()`
- В `process_question` (строка 358): вызов `self._process_subquestions(subquestions, generate_charts=not skip_files)`

**3c. Пропуск шага 4 (merge) при skip_files:**
Строка 367-371: обернуть в `if not skip_files:` / `else: final_df, python_code = None, None`

**3d. Forward флагов в `_generate_reports`:**
- `_generate_reports` (строка 237): добавить `generate_charts/generate_excel/generate_pdf` params, прокинуть в `generate_reports()`
- В `process_question` (строка 375): вызов с `generate_charts=not skip_files, generate_excel=not skip_files, generate_pdf=not skip_files`

**3e. Timings в return dict:**
Изменить `process_question` — захватить результат `_generate_reports` в переменную, добавить timings/detail_timings, вернуть:
```python
with PerfTimer("5_8_reports", timings):
    result = self._generate_reports(...)
result["timings"] = timings
result["detail_timings"] = detail_timings
return result
```
Для раннего return (irrelevant question, строка 331-337) — тоже добавить:
```python
return {
    ...,
    "timings": timings,
    "detail_timings": detail_timings,
}
```

### Task 4: Тесты skip_files

**Files:** `tests/application/test_skip_files.py` (новый файл)
**Depends on:** Task 3

Тесты (по паттерну test_agent_methods.py — `@patch` + `assert_not_called`):

1. `test_skip_files_does_not_generate_chart` — patch `application.reports.generate_chart`, `assert_not_called`
2. `test_skip_files_does_not_generate_excel` — patch `application.reports.save_dataframes_to_excel`, `assert_not_called`
3. `test_skip_files_does_not_generate_pdf` — patch `application.reports.create_pdf_document`, `assert_not_called`
4. `test_skip_files_skips_merge` — patch `application.agent.AIAgent._merge_dataframes`, `assert_not_called`
5. `test_skip_files_returns_timings` — `assert "timings" in result` and `assert "detail_timings" in result`
6. `test_skip_files_false_generates_chart` — default behavior, `generate_chart.assert_called`
7. `test_skip_files_subquestion_chart_not_called` — patch `application.subquestion.generate_chart`, `assert_not_called` при `generate_charts=False`

### Task 5: Регрессия + devlog

**Files:** devlog/changelog.json
**Depends on:** Task 4

1. `pytest tests/ -v` — все тесты зелёные (608+7 новых)
2. Добавить запись в devlog/changelog.json

## Риски

| Сценарий | Вероятность | Импакт | Действие |
|----------|-------------|--------|----------|
| Регрессия: skip_files=False меняет поведение | Низкая | Высокий | Defaults=True/False, полный pytest |
| Timings в return ломает потребителей | Низкая | Средний | Только добавляем ключи, не меняем старые |
| process_question size > 105 LOC после изменений | Средняя | Низкий | Если превышает — вынести timings injection в helper |

## Масштаб

- 3 файла модификация, 1 файл создание, 1 файл devlog
- ~7 новых тестов
- Tasks 1 и 2 параллельны, Task 3 зависит от обоих
