# Plan: Обновить description FX-полей (9 полей)

## Context

FX-поля в metadata.py содержат запрет «Запрещено использовать это поле для валютных платежей», но без объяснения почему и без указания альтернативы. LLM-модель может игнорировать такой запрет или не понимать, какое поле использовать вместо FX. Нужно уточнить: FX = конверсии/обмен валюты, а для валютных платежей — VED_VOL.

## Изменения

**Файл:** `infrastructure/metadata.py`

### Паттерн замены

**Русский (description):**
- Было: `Запрещено использовать это поле для валютных платежей`
- Стало: `Запрещено использовать для валютных платежей (это конверсии/обмен валюты, для валютных платежей используй VED_VOL)`

**Английский (description_en):**
- Было: `Forbiden to use this field for foreign currency payments`
- Стало: `Do not use for foreign currency payments (this is currency conversion/exchange; for foreign currency payments use VED_VOL)`

### Затронутые поля (8 полей с существующим запретом)

| # | Поле | Строка (description) |
|---|------|---------------------|
| 1 | FX_VOLUME_RUB | 171 |
| 2 | FX_CNT | 182 |
| 3 | FX_EUR_MARGIN_RUB | 193 |
| 4 | FX_EUR_VOLUME_RUB | 204 |
| 5 | FX_EUR_CNT | 215 |
| 6 | FX_CNY_MARGIN_RUB | 226 |
| 7 | FX_CNY_VOLUME_RUB | 237 |
| 8 | FX_CNY_CNT | 248 |

### Новое поле (добавить запрет)

| # | Поле | Строка (description) |
|---|------|---------------------|
| 9 | FX_MARGIN_RUB | 293 — сейчас нет запрета, добавить |

Для FX_MARGIN_RUB: дописать в конец description/description_en новый запрет (после «Является частью PNL_SUM.»).

## Реализация

Одна задача — 9 Edit-вызовов в metadata.py:
- 8 полей: `replace_all=false`, заменить старый паттерн запрета на новый (ru + en)
- 1 поле (FX_MARGIN_RUB): дописать запрет в конец description и description_en

## Верификация

1. `pytest tests/infrastructure/ -v` — убедиться что мета-тесты проходят
2. Визуальная проверка: `grep "VED_VOL" infrastructure/metadata.py` — 9 полей + сам VED_VOL = 10+ вхождений
