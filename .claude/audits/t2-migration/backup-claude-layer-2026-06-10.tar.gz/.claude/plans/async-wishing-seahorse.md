# Актуализация документации проекта (sync с кодом)

## Context

Пользователь запросил sync основной разработческой документации с реальным кодом — «истина — код». Я провёл сверку шести ключевых документов (`README.md`, `CLAUDE.md`, `docs/architecture.md`, `docs/configuration.md`, `docs/setup.md`, `docs/new-feature-guide.md`) с актуальной кодовой базой через Explore-агентов, прямое чтение файлов и Plan-агента-валидатора.

Результат — 7 расхождений с разной критичностью. Самое опасное (P0): пример проверки LLM API в `setup.md` использует несуществующий метод `LLMClient.call_llm(messages=...)` — разработчик, скопировавший код, упрётся в `AttributeError`. Остальные — устаревшие числа, неупомянутая служебная env-переменная, отсутствующий ADR-якорь, устаревший статус инициативы.

Ожидаемый результат: документация точно отражает код, без вводящих в заблуждение фрагментов; добавлен короткий блок про служебный override `SQL_PROMPT_PATH`, используемый инициативой `sql-prompt-quality`.

## Подтверждённые расхождения (после верификации кода)

| # | Prio | Файл | Расхождение | Подтверждение из кода |
|---|------|------|-------------|------------------------|
| A | **P0** | `docs/setup.md:112-124` | Пример LLM API использует `LLMClient.call_llm(messages=...)` — нерабочий | `infrastructure/llm_client.py`: `call_llm` — модульная функция, принимает `prompt: str` (не `messages`); параметр зовётся `operation_name`, а не `operation` |
| C | P1 | `docs/configuration.md:17` | «~65 параметров» устарело | `grep -cE "^\s+\w+:\s+(int\|float\|str\|bool\|list)" infrastructure/settings.py` ≈ 89 |
| D | P1 | `docs/configuration.md` | Не упомянута env `SQL_PROMPT_PATH` | `core/sql/generator.py:25,39` (read) + `presentation/batch_cli.py` (write через `--sql-prompt-path`) |
| E | P1 | `docs/architecture.md:293` | У `df_merger.py` нет ADR-якоря (chart_builder помечен ADR-017, df_merger — нет) | `docs/decisions/ADR-018-deterministic-df-merger.md` статус Принято |
| F | P1 | `CLAUDE.md:119` | «sql-prompt-quality (стабилизация v1, итеративное A/B)» — не отражает promotion | `devlog/changelog.json` #124 (2026-05-04): Iter 3.1 → новый baseline |
| G | P1 | `README.md:97` | «~1100 тестов» устарело | `pytest --collect-only -q` → 1264/1291 collected (27 deselected) |
| B | P2 | `docs/setup.md:250` | Запутанная формулировка про DEFAULT_MODEL | `infrastructure/llm_client.py`: `DEFAULT_MODEL = _get_settings().sql_model` |

## Отвергнутые расхождения (ложные после верификации)

- **Путь к промпту** в `architecture.md:229` (`core/sql/prompts/v1/sql_generation.txt`) — **корректен**: `ls core/sql/prompts/` даёт только подпапку `v1/`; все iter-файлы и baseline лежат внутри `v1/`. Правок не требуется.
- **`agent.py` как «тонкий оркестратор»** в `CLAUDE.md:24-25` — частично спорно (метод `_merge_dataframes` ~100 LOC), но это вопрос архитектуры, а не документации. Не правим.

## Out of scope

- **Дубль ADR-014** (`ADR-014-client-product-migration.md` и `ADR-014-monitoring.md` в `docs/decisions/`) и **пропуск ADR-021** (заменён ADR-022, файл в `docs/archive/`) — реальные несоответствия в нумерации, но требуют отдельной задачи: переименование/консолидация файлов ADR. Формулировка `(ADR-001..ADR-022)` в README/CLAUDE остаётся как диапазон — не вводит в заблуждение.
- `docs/zulip-setup.md`, `docs/output-files.md`, `dev/*.md` — отдельный scope.
- `docs/initiatives/*`, `docs/decisions/*`, `docs/thinking/*`, `docs/research/*`, `.claude/rules/*` — самообновляющиеся / исторические.

## Конкретные правки

### Правка A (P0) — `docs/setup.md`, строки 112-124

**Old:**
```python
# Проверка LLM API
from infrastructure.llm_client import LLMClient
from infrastructure.settings import get_settings

s = get_settings()
LLMClient.initialize(api_key=s.api_key, base_url=s.api_url)
response = LLMClient.call_llm(
    messages=[{"role": "user", "content": "Тест"}],
    max_tokens=10
)
print(f"LLM API: OK, ответ: {response}")
```

**New:**
```python
# Проверка LLM API
from infrastructure.llm_client import LLMClient, call_llm
from infrastructure.settings import get_settings

s = get_settings()
LLMClient.initialize(api_key=s.api_key, base_url=s.api_url)
response = call_llm(
    "Тест",
    model=s.sql_model,
    max_tokens=10,
    operation_name="smoke_test",
)
print(f"LLM API: OK, ответ: {response}")
```

### Правка B (P2) — `docs/setup.md`, строка 250

**Old:**
```
- Дефолтная модель (DEFAULT_MODEL из `infrastructure/llm_client.py`) берётся из `infrastructure/settings.py` — убедитесь, что `AI_ANALYST_SQL_MODEL` совпадает с Ollama-моделью
```

**New:**
```
- `DEFAULT_MODEL` в `infrastructure/llm_client.py` инициализируется значением `settings.sql_model` (т.е. `AI_ANALYST_SQL_MODEL`). Для Ollama убедитесь, что `AI_ANALYST_SQL_MODEL` совпадает с именем локальной модели; для разных моделей под SQL и текстовые ответы используйте `AI_ANALYST_RESPONSE_MODEL`.
```

### Правка C (P1) — `docs/configuration.md`, строка 17

**Old:**
```
Проект использует модуль `settings.py` на базе pydantic-settings v2 как единую точку конфигурации. Все ~65 параметров (temperature, max_tokens, лимиты, размеры графиков и т.д.) собраны в типизированные модели с валидацией. .env файл читается нативно через python-dotenv.
```

**New:**
```
Проект использует модуль `settings.py` на базе pydantic-settings v2 как единую точку конфигурации. Все параметры (≈90: temperature, max_tokens, лимиты, размеры графиков, пул соединений, бот, логирование) собраны в типизированные модели с валидацией. .env файл читается нативно через python-dotenv.
```

### Правка D (P1) — `docs/configuration.md`, вставка перед «### Параметры по группам» (после строки 47)

**Old (anchor):**
```
Подробнее: [ADR-007](decisions/ADR-007-centralized-settings.md), [ADR-008](decisions/ADR-008-dotenv-config.md)

### Параметры по группам
```

**New:**
```
Подробнее: [ADR-007](decisions/ADR-007-centralized-settings.md), [ADR-008](decisions/ADR-008-dotenv-config.md)

### Служебная env-переменная: SQL_PROMPT_PATH

`SQL_PROMPT_PATH` (без префикса `AI_ANALYST_`) — путь к альтернативному файлу SQL-промпта для A/B-валидации. Используется инициативой `sql-prompt-quality`.

- Читается в `core/sql/generator.py` (`_load_prompt_template`); если переменная задана и указывает на существующий файл — используется он, иначе baseline `core/sql/prompts/v1/sql_generation.txt`.
- Устанавливается автоматически из `presentation/batch_cli.py` при флаге `--sql-prompt-path <path>`.
- Не управляется через pydantic-settings: это runtime-override для batch-валидации, не часть прод-конфигурации.

### Параметры по группам
```

### Правка E (P1) — `docs/architecture.md`, строка 293

**Old:**
```
### core/output/df_merger.py — Детерминированное объединение DataFrames
Объединяет DataFrame'ы без LLM
```

**New:**
```
### core/output/df_merger.py — Детерминированное объединение DataFrames (ADR-018)
Объединяет DataFrame'ы без LLM
```

### Правка F (P1) — `CLAUDE.md`, строка 119

**Old:**
```
Сейчас активно: `production-v2` (MVP → продовая архитектура), `sql-prompt-quality` (стабилизация v1 SQL-промпта, итеративное A/B)
```

**New:**
```
Сейчас активно: `production-v2` (MVP → продовая архитектура), `sql-prompt-quality` (Iter 3.1 promoted-to-baseline 2026-05-04, продолжается стабилизация v1 SQL-промпта)
```

### Правка G (P1) — `README.md`, строка 97

**Old:**
```
pytest tests/ -v            # ~1100 тестов (27 integration deselected по умолчанию)
```

**New:**
```
pytest tests/ -v            # ~1260 тестов (27 integration deselected по умолчанию; маркеры: integration, slow, live)
```

## Critical Files

- `/home/nikita/PROJECTS/AI_analyst_for_work/AI_analyst_migration/docs/setup.md` (правки A, B)
- `/home/nikita/PROJECTS/AI_analyst_for_work/AI_analyst_migration/docs/configuration.md` (правки C, D)
- `/home/nikita/PROJECTS/AI_analyst_for_work/AI_analyst_migration/docs/architecture.md` (правка E)
- `/home/nikita/PROJECTS/AI_analyst_for_work/AI_analyst_migration/CLAUDE.md` (правка F)
- `/home/nikita/PROJECTS/AI_analyst_for_work/AI_analyst_migration/README.md` (правка G)
- `/home/nikita/PROJECTS/AI_analyst_for_work/AI_analyst_migration/docs/new-feature-guide.md` — без правок, верифицирован против кода

## Verification

Read-only команды для проверки после применения правок:

1. **Пример из setup.md импортируется:**
   ```bash
   .venv/bin/python -c "from infrastructure.llm_client import LLMClient, call_llm; import inspect; print(inspect.signature(call_llm))"
   ```
   Должно вернуть сигнатуру с `prompt: str` и `operation_name=...`.

2. **`SQL_PROMPT_PATH` упомянут в configuration.md:**
   ```bash
   grep -n "SQL_PROMPT_PATH" docs/configuration.md core/sql/generator.py presentation/batch_cli.py
   ```
   Должно вернуть совпадения во всех трёх файлах.

3. **ADR-018 упомянут рядом с df_merger:**
   ```bash
   grep -n "df_merger.*ADR-018\|ADR-018.*df_merger" docs/architecture.md
   ```

4. **Точное число параметров settings.py:**
   ```bash
   grep -cE "^\s+\w+:\s+(int|float|str|bool|list|tuple|Optional|Path)" infrastructure/settings.py
   ```
   Должно вернуть число близкое к 89; «≈90» в configuration.md устойчиво к мелкому дрейфу.

5. **Реальное число тестов:**
   ```bash
   .venv/bin/python -m pytest --collect-only -q 2>/dev/null | tail -1
   ```
   Должно вернуть `~1264 tests collected (27 deselected)`. Цифра «~1260» в README терпит дрейф ±10.

6. **Статус ADR-018:**
   ```bash
   grep -A1 "^## Статус" docs/decisions/ADR-018-deterministic-df-merger.md
   ```
   Должен быть «Принято».

7. **Архив с ложным расхождением (промпты):**
   ```bash
   ls core/sql/prompts/
   ```
   Должно вернуть только `v1` — подтверждает корректность пути в architecture.md.

8. **End-to-end smoke (опционально, требует Oracle + LLM):**
   ```bash
   python dev/test-connection.py
   ```
   Если в окружении доступен dev-стенд — пример из setup.md можно прогнать вручную.

## Применение

Все правки точечные, без структурных изменений. Применяются через `Edit` (старый текст → новый) последовательно по файлам. После каждой группы (правок одного файла) — прочитать файл целиком чтобы убедиться, что соседние строки не сместились.

После применения:
- `git diff --stat` — должен показать ~5-6 изменённых файлов с минимальным дельта.
- Запись в `devlog/changelog.json` (`type: docs`, scope: 5 файлов, related: ADR-018, ADR-022, devlog #124).
