# Plan: Runtime SQL Error Retry в subquestion pipeline

## Контекст

Текущий 5-шаговый pipeline в `application/subquestion.py` обрабатывает SQL через validate → execute последовательно без обратной связи. EXPLAIN PLAN (Шаг 2) ловит синтаксические и семантические ошибки, но runtime-ошибки на данных (ORA-01722 type conversion, ORA-01476 division by zero, ORA-01843 date format) проваливаются в тупик — пользователь получает `❌ Ошибка при выполнении SQL` без попытки исправления.

При этом `fix_sql_with_llm()` в `core/sql/validator.py` уже существует, принимает произвольный `error_message`, и хорошо справляется с конкретными Oracle-ошибками. Нужно только вызвать его из нового места.

## Изменения

### Task 1: Добавить `sql_exec_fix_max_attempts` в settings

**Файл:** `infrastructure/settings.py`

Добавить в `LLMSettings` (после `sql_fix_max_attempts`, строка 45):
```python
# subquestion: retry при runtime-ошибках выполнения SQL
sql_exec_fix_max_attempts: int = Field(default=1, ge=0, le=3)
```

**Тест:** `tests/infrastructure/test_settings.py` — проверить дефолт и диапазон.

### Task 2: Добавить retry-loop в Шаг 3 subquestion.py

**Файл:** `application/subquestion.py`

**Текущий код (строки 180-206):** try → execute_query → except → return error.

**Новый код:** обернуть в `for exec_attempt in range(max_exec_retries + 1)`:

```python
# Шаг 3: Выполнение SQL запроса (с retry при runtime-ошибках)
s = get_settings()
max_exec_retries = s.llm.sql_exec_fix_max_attempts
_emit("[Подвопрос] 🗄️  Шаг 3/5: Выполнение SQL запроса...", ProgressEventType.SUBSTEP)
with PerfTimer("db_execute", sub_timings):
    for exec_attempt in range(max_exec_retries + 1):
        try:
            # connection check...
            df = db_connector.execute_query(sql)
            result["df"] = df
            # empty check...
            break  # успех — выходим из retry loop

        except Exception as e:
            if exec_attempt < max_exec_retries:
                # Попытка исправить SQL на основе runtime-ошибки
                error_msg = str(e)
                logger.warning("Runtime SQL error (attempt %d/%d): %s",
                              exec_attempt + 1, max_exec_retries, error_msg)
                _emit(f"[Подвопрос] ⚠️ Ошибка выполнения, попытка исправления...", ...)
                try:
                    fixed_sql = fix_sql_with_llm(sql, error_msg, subquestion, model=sql_model)
                    fixed_sql, is_valid = validate_and_fix_sql(fixed_sql, subquestion,
                                                               db_executor=db_connector, model=sql_model)
                    if is_valid:
                        sql = fixed_sql
                        result["sql"] = sql
                        continue  # retry execute
                except Exception as fix_err:
                    logger.warning("Fix attempt failed: %s", fix_err)
                # fix не удался — падаем как обычно

            # Все retry исчерпаны или fix не удался
            error_msg = f"Ошибка при выполнении SQL: {str(e)}"
            logger.error(error_msg, exc_info=True)
            _emit(f"[Подвопрос] ❌ {error_msg}", ProgressEventType.STATUS)
            result["answer"] = f"❌ {error_msg}"
            result["timings"] = sub_timings
            return result
```

**Добавить импорт:** `from core.sql.validator import fix_sql_with_llm` (validate_and_fix_sql уже импортирован).

### Task 3: Тесты

**Файл:** `tests/application/test_subquestion.py`

3 новых теста:

1. **`test_execution_runtime_error_recovery`** — execute_query падает с ORA-01722, fix_sql_with_llm возвращает исправленный SQL, retry execute успешен → result["answer"] содержит ответ, не ошибку.

2. **`test_execution_runtime_error_exhausted`** — execute_query падает на обоих попытках (sql_exec_fix_max_attempts=1) → result["answer"] содержит ошибку (поведение как сейчас).

3. **`test_execution_runtime_error_fix_fails`** — execute_query падает, fix_sql_with_llm тоже выбрасывает исключение → result["answer"] содержит оригинальную ошибку.

### Task 4: Devlog + документация

- Запись в `devlog/changelog.json`
- Обновить `docs/configuration.md` — добавить `sql_exec_fix_max_attempts`

## Что НЕ меняется

- `core/sql/validator.py` — fix_sql_with_llm() и validate_and_fix_sql() без изменений
- `core/sql/prompts/v1/sql_fix.txt` — промпт уже обрабатывает runtime ORA-ошибки
- Точки входа (cli.py, zulip_bot.py) — не затронуты

## Влияние

- **Happy path:** zero overhead — retry loop не входит в ветку catch
- **Failure path + recovery:** +5-10с (1 LLM call + 1 EXPLAIN PLAN + 1 execute)
- **Failure path + exhausted:** незначительный overhead от try/except, поведение как сейчас

## Риски

| Сценарий | Вероятность | Воздействие | Действие |
|----------|-------------|-------------|----------|
| LLM fix создаёт бесконечный цикл ошибок | low | medium | max_exec_retries ограничен 0-3, дефолт=1 |
| Timeout при retry удваивает время ответа | medium | low | sql_exec_fix_max_attempts=0 отключает retry |
| fix_sql_with_llm выбрасывает исключение | low | low | Обёрнуто в try/except, fallback к текущему поведению |

## Верификация

1. `pytest tests/infrastructure/test_settings.py -v` — новое поле settings
2. `pytest tests/application/test_subquestion.py -v` — все тесты (старые + новые)
3. `pytest tests/ -v` — полный unit-suite, регрессия
4. `ruff check` — линтер
5. Live-тест: `python run_agent.py` → вопрос, проверить что happy path не сломан
