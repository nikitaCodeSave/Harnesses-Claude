# План: сохранение контекста в цикле fix SQL validator

## Контекст

Рекурсивный цикл исправления SQL в `core/sql/validator.py` теряет информацию между итерациями: LLM на каждой попытке видит только текущий SQL и текущую ошибку Oracle, но не видит исходный SQL, историю предыдущих попыток и ошибок. Это приводит к "drift" — LLM может ходить по кругу (fix error_A → create error_B → fix error_B → recreate error_A) или вносить новые ошибки, не зная контекста.

**Цель:** передавать в LLM исходный SQL и накопленную историю попыток/ошибок для более качественного исправления.

## Затронутые файлы

| Файл | Изменение |
|------|-----------|
| `core/sql/validator.py` | Рефакторинг рекурсии → цикл, новые параметры fix_sql_with_llm, секция истории в промпте |
| `tests/core/sql/test_validator.py` | 5-6 новых тестов + адаптация существующих |
| `devlog/changelog.json` | Запись |

**Не затронуты:** `application/subquestion.py` (public API `validate_and_fix_sql` без изменений), `infrastructure/settings.py`.

## Ключевые решения

### 1. Рекурсия → цикл `for attempt in range(max_attempts)`

Цикл естественно накапливает состояние (history, original_sql) без передачи через аргументы рекурсии. Три ветки (syntax check, EXPLAIN PLAN, legacy callable) сохраняются, но fix-логика унифицируется.

### 2. История попыток: `list[dict]`

```python
fix_history: list[dict] = []
# Каждая запись: {"attempt": int, "sql": str, "error": str, "structure_issue": str | None}
```

Накапливается в цикле, передаётся в `fix_sql_with_llm`.

### 3. Новая сигнатура `fix_sql_with_llm`

```python
def fix_sql_with_llm(
    sql: str,
    error_message: str,
    original_question: str,
    model: str = DEFAULT_MODEL,
    original_sql: str | None = None,      # НОВЫЙ: исходный SQL до всех исправлений
    fix_history: list[dict] | None = None, # НОВЫЙ: история попыток
) -> str:
```

Мёртвый параметр `max_attempts` удаляется.

### 4. Модификация промпта

Две новые секции (условные — добавляются только когда `original_sql != sql` или `fix_history` непустой):

**Секция "Исходный SQL"** — в конце промпта, заменяет текущий блок "Исходный SQL (содержит ошибку):" раздвоением:
```
НАСТОЯЩИЙ ИСХОДНЫЙ SQL (до всех попыток исправления):
{original_sql}

ТЕКУЩИЙ SQL (после предыдущих попыток, содержит ошибку):
{sql}
```

**Секция "История попыток"** — перед "7. ФОРМАТ ОТВЕТА":
```
ИСТОРИЯ ПРЕДЫДУЩИХ ПОПЫТОК ИСПРАВЛЕНИЯ
Попытка 1: SQL: <truncated>... Ошибка: ... [Проблема структуры: ...]
НЕ повторяй ошибки из предыдущих попыток!
```

**Контроль размера (каскадный fallback):** helper `_format_fix_history(history, sql_max_chars=None)` передаёт полный SQL и полную ошибку без обрезки. Если собранный промпт > `sql_max_prompt_length`:
1. Уменьшить примеры SQL с 2 до 1 (экономия ~500-1000 символов)
2. Обрезать SQL в истории до 500 символов/запись (хвост SQL — WHERE/GROUP BY — сохраняется в ошибке Oracle)
3. Дропнуть историю целиком, оставить только `original_sql`
4. Fallback на короткий промпт (строки 697-716) + `original_sql` + история (без примеров)

Типичный случай (промпт ~8000 + история ~3000 = 11000) — укладывается в лимит 15000 без обрезки. Каскад нужен только для edge cases с длинными запросами.

### 5. Structure check — против исходного SQL

`check_sql_structure_preserved(original_sql, fixed_sql)` вместо текущего `check_sql_structure_preserved(previous_iteration_sql, fixed_sql)`. При нарушении — запись в `fix_history[-1]["structure_issue"]` вместо немедленного второго LLM-вызова. Это убирает "двойной LLM-вызов" за одну итерацию.

## Задачи (последовательные)

### Task 1: Написать тесты (TDD — red phase)
**Files:** `tests/core/sql/test_validator.py`
**Новые тесты:**
- `test_fix_passes_original_sql_and_history_to_llm` — при 2+ итерациях промпт содержит исходный SQL и историю
- `test_fix_history_includes_structure_issues` — при нарушении структуры, следующий промпт содержит информацию о проблеме
- `test_fix_no_double_llm_call_on_structure_violation` — при нарушении структуры НЕТ второго LLM-вызова в той же итерации
- `test_fix_sql_with_llm_accepts_history_params` — fix_sql_with_llm принимает `original_sql` и `fix_history`
- `test_format_fix_history_truncation` — helper _format_fix_history обрезает длинные SQL/ошибки
**Done when:** тесты написаны и падают (red)

### Task 2: Добавить `_format_fix_history` helper
**Files:** `core/sql/validator.py`
**Логика:** по умолчанию передаёт полный SQL и полную ошибку; при передаче `sql_max_chars` — обрезает SQL до указанного лимита
**Done when:** helper работает, тест `test_format_fix_history_truncation` проходит

### Task 3: Модифицировать `fix_sql_with_llm`
**Files:** `core/sql/validator.py`
**Изменения:** новая сигнатура (убрать `max_attempts`, добавить `original_sql` + `fix_history`), условные секции в промпте
**Done when:** тест `test_fix_sql_with_llm_accepts_history_params` проходит

### Task 4: Рефакторинг `validate_and_fix_sql` — рекурсия → цикл
**Files:** `core/sql/validator.py`
**Изменения:** заменить рекурсию на `for`-цикл, передавать `original_sql` и `fix_history` в `fix_sql_with_llm`, structure check против `original_sql`
**Done when:** все новые тесты проходят (green), существующие 8 тестов проходят

### Task 5: Верификация и постобработка
- `pytest tests/core/sql/test_validator.py -v` — все тесты зелёные
- `pytest tests/ -v` — регрессий нет
- Запись в `devlog/changelog.json`

## Риски

| Сценарий | Вероятность | Действие |
|----------|-------------|----------|
| Промпт превышает sql_max_prompt_length с историей | low | Truncation strategy с fallback: уменьшить бюджет → дропнуть историю → короткий промпт |
| LLM меняет поведение из-за дополнительного контекста | low (желаемый эффект) | Live-тест через `python run_agent.py` |
| Существующие тесты ломаются из-за изменения сигнатуры | medium | fix_sql_with_llm вызывается только из validate_and_fix_sql (тесты мокают call_llm, не fix_sql_with_llm) |

## Масштаб

- ~150 строк изменений в `validator.py`
- ~80 строк новых тестов
- Public API (`validate_and_fix_sql`) — без изменений
- Один вызывающий модуль (`subquestion.py`) — без изменений

## Дальнейшие шаги

После утверждения: `/implement` для выполнения по задачам с TDD workflow.
