# ADR-014: Мониторинг использования бота — План реализации

## Context

Команде аналитики нужны данные для ревью качества SQL/ответов, бизнес-метрик (запросы, пользователи, пики) и выгрузок в Excel. ADR-014 описывает плоскую модель данных (строка = подвопрос), хранение в JSON-файлах (`data/monitoring/YYYY/MM/`), и Excel-отчёты через команду `/analytics` в Zulip.

**Прототипы уже готовы** в `docs/research/monitoring/`:
- `request_tracker.py` (~308 LOC) — build_request_rows, save, load, track_request
- `analytics.py` (~422 LOC) — generate_analytics_excel (6 листов), generate_detail_excel

Задача: перенести прототипы в production-пакеты и интегрировать в 3 точки входа.

## Research Summary

### Точки интеграции (проверено по коду)

1. **`application/agent.py:289`** — `process_question(question, skip_files=False)` — основная точка трекинга
   - `self.request_id` доступен (строка 76)
   - Нужно добавить `user_id`/`source` атрибуты
   - Два return-пути: irrelevant (строка 327) и success/partial (строка 392)

2. **`presentation/zulip_bot.py:351`** — `process_question(sender_email, question)`
   - `sender_email` доступен (строка 506)
   - Команды обрабатываются в `handle_message()` (строки 514-542: /help, /status)
   - Агент создаётся на строке 388

3. **`presentation/batch_cli.py:107`** — агент создаётся без user_id
   - Нужен `--user-id` аргумент

4. **`infrastructure/settings.py:176`** — flat fields pattern, нужен `monitoring_dir`

### Зависимости между юнитами

```
request_tracker.py ← analytics.py (import)
request_tracker.py ← agent.py (import track_request)
analytics.py ← zulip_bot.py (import generate_analytics_excel)
```

Интеграционные юниты зависят от foundation. Для worktree-изоляции каждый интеграционный агент также создаёт request_tracker.py + settings change (идентично). Merge strategy: foundation первой, затем интеграция (конфликты на новых файлах — тривиальные).

## Work Units

### Unit 1: Foundation — request_tracker + analytics + settings + tests
**Файлы (новые):**
- `infrastructure/request_tracker.py` — из прототипа, заменить `MONITORING_DIR` на `get_settings().monitoring_dir`
- `infrastructure/analytics.py` — из прототипа без изменений (импорты уже правильные)
- `tests/infrastructure/test_request_tracker.py` — 14 тестов (build_rows, save, load, track, filters)
- `tests/infrastructure/test_analytics.py` — 12 тестов (sheets, Excel generation, empty data)

**Файлы (изменения):**
- `infrastructure/settings.py` — добавить `monitoring_dir: str = "data/monitoring"` после строки 191
- `.env.example` — добавить `# AI_ANALYST_MONITORING_DIR=data/monitoring`

### Unit 2: Agent integration — user_id, source, track_request
**Файлы (изменения):**
- `application/agent.py`:
  - Добавить `self.user_id = ""` и `self.source = "console"` в `__init__` (после строки 78)
  - Добавить вызов `track_request()` перед return в irrelevant-case (строка 326)
  - Добавить вызов `track_request()` перед return result (строка 392)
  - Импорт `track_request` — локальный внутри `process_question()` (мягкая зависимость)

**Файлы (новые):**
- `tests/application/test_agent_monitoring.py` — 4 теста (track on success, on irrelevant, swallow errors, defaults)

**Prerequisite в worktree:** также создать `infrastructure/request_tracker.py` и изменение settings.py

### Unit 3: Zulip integration — user_id + /analytics command
**Файлы (изменения):**
- `presentation/zulip_bot.py`:
  - В `process_question()` после строки 399: `agent.user_id = sender_email; agent.source = "zulip"`
  - В `handle_message()` после строки 542: обработка `/analytics` команд
  - Новый метод `_handle_analytics(sender_email, content)` — парсинг подкоманд (bare, month, user, detail)
  - Обновить help_text (строки 515-535) — добавить `/analytics`

**Файлы (новые):**
- `tests/presentation/test_zulip_analytics.py` — 6 тестов (full, month, user, detail, not found, error)

**Prerequisite в worktree:** также создать `infrastructure/request_tracker.py`, `infrastructure/analytics.py`, изменение settings.py

### Unit 4: Docs + ADR + devlog
**Файлы (изменения/новые):**
- `docs/decisions/ADR-014-monitoring.md` — копия из research, статус → "Принято"
- `CLAUDE.md` — добавить request_tracker.py и analytics.py в структуру
- `docs/architecture.md` — добавить мониторинг как шаг 9
- `docs/configuration.md` — добавить monitoring_dir
- `devlog/changelog.json` — новая запись

## Conventions (для воркеров)

- **Импорты:** stdlib → third-party → local. Локальные: `from infrastructure.request_tracker import track_request`
- **Логирование:** `logger = logging.getLogger(__name__)`, НЕ print()
- **Тесты:** pytest, `tmp_path` для файлов, `monkeypatch` для settings, NO `__init__.py` в тестовых директориях
- **Settings:** `get_settings().monitoring_dir` вместо хардкода
- **Язык:** код на английском, docstrings на русском (Google-style), комментарии на русском
- **Безопасность:** `track_request()` обёрнут в try/except — не ронит пайплайн

## E2E Test Recipe

**Unit tests (все юниты):**
```bash
source .venv/bin/activate && pytest tests/ -v
```

**Skip e2e** — мониторинг не влияет на основной pipeline, live-тест требует Oracle+Ollama. Unit tests с моками достаточны для верификации интеграции.

## Merge Strategy

1. Merge Unit 1 (foundation) и Unit 4 (docs) первыми — независимы
2. Merge Units 2-3 после Unit 1 — тривиальные конфликты на новых файлах (идентичное содержимое)
