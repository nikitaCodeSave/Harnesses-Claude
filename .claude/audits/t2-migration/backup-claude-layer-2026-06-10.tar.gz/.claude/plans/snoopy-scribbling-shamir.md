# Plan: Набор Skills для AI-first документации Python-проектов

## Context

Нужен набор Claude Code Skills, который обходит любой Python-проект и создаёт/аудирует AI-first документацию: CLAUDE.md, .claude/rules/, docs/. Скиллы должны быть универсальными (не привязаны к конкретному проекту), размещаться в `~/.claude/skills/` и компоноваться в pipeline.

Основано на: официальной документации Claude Code Skills (code.claude.com/docs/en/skills), 32-page Anthropic playbook "The Complete Guide to Building Skills for Claude" (Jan 2026), исследовании compass_artifact, и паттернах из anthropics/skills репозитория.

---

## Архитектура: 3 скилла

| # | Имя | Роль | Категория (Anthropic) |
|---|-----|------|-----------------------|
| 1 | `doc-bootstrap` | Создание CLAUDE.md + .claude/rules/ с нуля | Workflow Automation |
| 2 | `doc-audit` | Аудит качества AI-текстовых файлов | Workflow Automation |
| 3 | `doc-generate` | Создание/обновление docs/ структуры | Document & Asset Creation |

**Размещение:** `~/.claude/skills/` (глобальные, для любого Python-проекта)

**Pipeline:**
- Новый проект: `doc-bootstrap` → `doc-generate` → (через 2 недели) `doc-audit`
- Существующий: `doc-audit` → правки / `doc-bootstrap` → `doc-generate [scope]`
- После изменений: `doc-audit claude-md` → `doc-generate [scope]`

---

## Скилл 1: doc-bootstrap

**Цель:** Обойти незнакомый Python-проект и создать CLAUDE.md + .claude/rules/ с нуля.

### Файловая структура
```
~/.claude/skills/doc-bootstrap/
├── SKILL.md                          # ~150 строк, основной workflow
└── references/
    ├── claude-md-template.md         # Эталонная структура CLAUDE.md с комментариями
    └── rules-catalog.md              # Каталог типовых rules с триггерами "когда создавать"
```

### Frontmatter
```yaml
---
name: doc-bootstrap
description: >-
  Создать CLAUDE.md и .claude/rules/ с нуля для Python-проекта.
  Обходит структуру, стек, зависимости, точки входа, тесты.
  Use when user says "bootstrap docs", "create CLAUDE.md",
  "set up AI docs", "initialize project for Claude Code",
  or opens a new Python project without CLAUDE.md.
disable-model-invocation: true
allowed-tools: Read, Write, Glob, Grep, Bash(ls *), Bash(wc *), Bash(git *), Bash(find *), Bash(head *), Bash(cat *), Bash(python *)
argument-hint: "[path-to-project or current directory]"
---
```

### Фазы SKILL.md

**Фаза 0: Предусловия** (шлюз)
- Проверить: есть ли CLAUDE.md? Если да → СТОП, предложить `/doc-audit`
- Проверить: это Python-проект? (*.py, pyproject.toml/setup.py/requirements.txt)
- Проверить: git repo? (предупреждение, не блокер)

**Фаза 1: Discovery** (read-only)
1. Файловое дерево: `Glob("**/*.py")`, подсчет файлов и LOC
2. Стек: парсинг pyproject.toml/requirements.txt → framework, key deps
3. Точки входа: grep `if __name__`, `[project.scripts]`, Makefile
4. Конфигурация: grep `.env`, `os.environ`, `BaseSettings`, `argparse`
5. Тесты: glob `tests/**/*.py`, определить framework (pytest/unittest)
6. Структура: flat vs src/ layout, пакеты vs скрипты, слои

→ Показать пользователю таблицу ProjectMap, получить подтверждение (**STOP**)

**Фаза 2: Генерация CLAUDE.md**
- Заполнить по шаблону из `references/claude-md-template.md`
- Секции: описание, стек, структура, точки входа, команды, статус тестов
- Целевой размер: **60-120 строк** (brevity beats completeness)

**Фаза 3: Генерация .claude/rules/**
- `code-style.md` — ВСЕГДА (на основе обнаруженных конвенций)
- `testing.md` — если есть тесты
- `development-workflow.md` — ВСЕГДА (минимальный)
- Доменные — только при обнаружении паттернов (DB, LLM, API)
- Каждый rule: **30-60 строк** max

**Фаза 4: Валидация**
- Проверить все пути в CLAUDE.md существуют (Glob)
- Проверить команды запуска (dry-run если безопасно)
- Исправить и повторить до чистого прохода

**Фаза 5: Отчёт**
- Таблица созданных файлов + рекомендации → `/doc-generate`, `/doc-audit`

### references/claude-md-template.md (~60 строк)
Скелет с плейсхолдерами и комментариями:
```
# {project_name}
{description — 1-2 предложения}
## Стек
## Структура проекта
## Точки входа
## Команды
## Правила для Claude Code
```

### references/rules-catalog.md (~80 строк)
Таблица: имя rule → когда создавать → обязательные секции → размер

---

## Скилл 2: doc-audit

**Цель:** Оценить существующие AI-текстовые файлы на качество и актуальность. **Read-only — не редактирует.**

### Файловая структура
```
~/.claude/skills/doc-audit/
├── SKILL.md                          # ~120 строк
└── references/
    ├── scoring-rubric.md             # Критерии A-F по 6 измерениям
    └── common-antipatterns.md        # Типичные ошибки в AI-документации
```

### Frontmatter
```yaml
---
name: doc-audit
description: >-
  Аудит качества CLAUDE.md, rules, skills на актуальность и drift.
  Проверяет 6 критериев, даёт оценки A-F, показывает проблемы.
  Use when user says "audit docs", "check CLAUDE.md quality",
  "is my documentation up to date", "doc drift", or
  after significant code changes to verify docs are current.
disable-model-invocation: true
context: fork
agent: Explore
argument-hint: "[scope: all|claude-md|rules|skills]"
---
```

### Фазы SKILL.md

**Фаза 1: Сбор артефактов**
- CLAUDE.md (корень, вложенные)
- .claude/rules/*.md, .claude/skills/*/SKILL.md
- .cursor/rules/ (если есть)

**Фаза 2: Оценка по 6 критериям** (из scoring-rubric.md)

| Критерий | Вес | Что проверяется |
|----------|-----|-----------------|
| Accuracy | 25% | Пути существуют, числа актуальны, команды работают |
| Completeness | 20% | Все модули упомянуты, точки входа задокументированы |
| Freshness | 20% | git log: docs vs code timing, drift detection |
| Conciseness | 15% | CLAUDE.md < 150 строк, нет дублирования |
| Actionability | 10% | Команды копируемые, инструкции конкретные |
| Consistency | 10% | Нет противоречий между файлами |

Проверки:
- Accuracy: Grep пути в CLAUDE.md → Glob проверка существования
- Freshness: `git log -1 --format=%ci` для docs vs code
- Consistency: сравнение дерева в CLAUDE.md с реальным `ls`

**Фаза 3: Отчёт**
```
## Аудит AI-документации
### Общая оценка: [B+]
| Файл | Accuracy | Completeness | Freshness | ... | Общая |
### Критичные проблемы (пути не существуют, числа устарели)
### Drift (устаревшая информация)
### Дубликаты
### Пробелы
### Рекомендации
```

### references/scoring-rubric.md (~80 строк)
Детальная рубрика: для каждого критерия — что такое A, C, F + конкретные проверочные команды

### references/common-antipatterns.md (~50 строк)
Типичные ошибки: prose вместо instructions, hardcoded numbers, path drift, CLAUDE.md > 200 строк, дублирование между файлами

---

## Скилл 3: doc-generate

**Цель:** Создать или обновить docs/ структуру (architecture.md, setup.md, configuration.md).

### Файловая структура
```
~/.claude/skills/doc-generate/
├── SKILL.md                          # ~150 строк
└── references/
    ├── docs-catalog.md               # Каталог типовых docs/ + условия создания
    └── architecture-guide.md         # Как писать architecture.md
```

### Frontmatter
```yaml
---
name: doc-generate
description: >-
  Создать или обновить docs/ структуру Python-проекта: architecture.md,
  setup.md, configuration.md. Анализирует код и строит документацию
  полезную людям и AI-агентам.
  Use when user says "generate docs", "create architecture docs",
  "document this project", "write setup guide",
  or "update documentation".
disable-model-invocation: true
allowed-tools: Read, Write, Edit, Grep, Glob, Bash(ls *), Bash(wc *), Bash(git *), Bash(find *), Bash(head *)
argument-hint: "[scope: full|architecture|setup|configuration]"
---
```

### Фазы SKILL.md

**Фаза 0: Определение режима**
- Create (docs/ не существует) → полная генерация
- Update (docs/ существует) → инкрементальное обновление по git diff

**Фаза 1: Discovery** (аналогично doc-bootstrap, но глубже)
- Архитектура: слои, зависимости, пайплайн/flow
- Конфигурация: все параметры с дефолтами и env-переменными
- API (если есть): endpoints, schemas

**Фаза 2: Определение docs/ каталога**

| Документ | Когда создавать | Содержимое |
|----------|----------------|------------|
| architecture.md | ВСЕГДА (>3 модулей) | Компоненты, зависимости, flow |
| setup.md | ВСЕГДА | Установка, запуск, dev-окружение |
| configuration.md | Если settings >5 параметров | Таблица параметров, env vars |

→ Показать план пользователю (**STOP**)

**Фаза 3: Генерация/обновление**
- Для каждого документа: прочитать код → заполнить по шаблону
- Update: Edit минимально, не переписывать

**Фаза 4: Кросс-валидация**
- docs/architecture.md ↔ CLAUDE.md (если есть)
- docs/configuration.md ↔ settings.py / .env.example

**Фаза 5: Отчёт**

### references/docs-catalog.md (~60 строк)
Каталог типовых docs/ с условиями создания и обязательными секциями

### references/architecture-guide.md (~70 строк)
Как писать architecture.md: секции, форматы диаграмм (ASCII, mermaid), примеры

---

## Ключевые принципы из официальных источников

### Из Anthropic Playbook (32-page guide)
1. **Description = `[What it does] + [When to use it] + [Key capabilities]`**
2. **Имя: kebab-case, без пробелов/подчёркиваний, совпадает с папкой**
3. **Нет README.md внутри скилла** — всё в SKILL.md или references/
4. **Progressive disclosure**: SKILL.md < 500 строк, детали в references/
5. **Be specific and actionable** (Good: конкретная команда; Bad: "validate the data")
6. **Description < 1024 символов**, без XML тегов
7. **Include trigger phrases** в description: "Use when user says ..."

### Из code.claude.com/docs/en/skills
8. **`$ARGUMENTS`** — подстановка аргументов пользователя
9. **`${CLAUDE_SKILL_DIR}`** — путь к директории скилла (для scripts/)
10. **`!`command``** — bash injection для динамического контекста
11. **`context: fork`** — изоляция для read-only скиллов (doc-audit)
12. **`disable-model-invocation: true`** — только ручной вызов

### Из engineering blog
13. **Evaluation-first**: определить gaps → написать skill → тестировать
14. **Code-as-documentation**: скрипты одновременно и выполняются и служат reference
15. **Iterative refinement**: мониторить реальное использование, корректировать

---

## Порядок реализации

### Итерация 1: doc-bootstrap (самодостаточный, базовый)
1. Создать `~/.claude/skills/doc-bootstrap/SKILL.md`
2. Создать `references/claude-md-template.md`
3. Создать `references/rules-catalog.md`
4. Тестировать на 2-3 проектах через skill-creator workflow

### Итерация 2: doc-audit (проверяет output от bootstrap)
1. Создать `~/.claude/skills/doc-audit/SKILL.md`
2. Создать `references/scoring-rubric.md`
3. Создать `references/common-antipatterns.md`
4. Тестировать: запустить на проекте с хорошей документацией + на проекте без

### Итерация 3: doc-generate (самый сложный)
1. Создать `~/.claude/skills/doc-generate/SKILL.md`
2. Создать `references/docs-catalog.md`
3. Создать `references/architecture-guide.md`
4. Тестировать: Create + Update режимы

### Для каждого скилла (через /skill-creator)
1. Draft SKILL.md
2. Создать 2-3 test prompts
3. Запустить with-skill vs baseline
4. Review через eval-viewer
5. Improve loop
6. Description optimization (run_loop.py)

---

## Верификация

### Тестовые проекты
1. **AI Analyst** (этот проект) — богатая документация, можно проверить audit
2. **Новый Python-проект** (создать minimal) — проверить bootstrap с нуля
3. **Проект без документации** — проверить полный pipeline bootstrap → generate

### Acceptance criteria
- `doc-bootstrap`: создаёт CLAUDE.md 60-120 строк + 2-4 rules файла
- `doc-audit`: выдаёт отчёт с оценками A-F, находит реальные проблемы
- `doc-generate`: создаёт architecture.md + setup.md, корректно работает Update
- Pipeline: bootstrap → generate → audit даёт оценку B+ или выше

### Проверочные команды
```bash
# Тест bootstrap на новом проекте
cd /tmp/test-project && /doc-bootstrap

# Тест audit на существующем
cd ~/PROJECTS/AI_analyst_for_work/AI_analyst_migration && /doc-audit all

# Тест generate
cd /tmp/test-project && /doc-generate full
```

---

## Источники
- [Extend Claude with skills](https://code.claude.com/docs/en/skills) — официальная документация
- [The Complete Guide to Building Skills for Claude](https://resources.anthropic.com/hubfs/The-Complete-Guide-to-Building-Skill-for-Claude.pdf) — 32-page Anthropic playbook (Jan 2026)
- [anthropics/skills](https://github.com/anthropics/skills/) — официальный репозиторий примеров
- [Equipping agents with Agent Skills](https://claude.com/blog/equipping-agents-for-the-real-world-with-agent-skills) — engineering blog
- [Claude Agent Skills: Deep Dive](https://leehanchung.github.io/blogs/2025/10/26/claude-skills-deep-dive/) — техническая аналитика
