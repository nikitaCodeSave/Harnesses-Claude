# Deep Project Review: Code Quality + Pipeline Correctness

## Context

This review audits the AI Analyst codebase across two axes: **code quality** (style adherence, error handling consistency, test coverage) and **pipeline correctness** (data flow integrity through the 8-step pipeline, error propagation, edge cases). The codebase is mature (~55 source files, ~290 unit tests, ~27 integration tests) with clear architecture (ADR-driven), but several patterns have drifted or accumulated inconsistencies.

---

## 1. Code Quality Findings

### 1.1 Bug: `run_console` prints raw dict instead of message

**File:** `application/agent.py:466-471`

```python
answer = self.process_question(question)  # returns dict
print(answer)  # prints {'status': 'success', 'message': '...', ...}
```

`process_question()` returns a `dict` with keys `status`, `message`, `pdf_path`, etc. But `run_console` prints the entire dict. Should print `answer["message"]` or format it.

**Severity:** Medium (user-facing bug in console mode)

### 1.2 Generic `raise Exception(...)` instead of domain exceptions

7 locations raise bare `Exception` where domain-specific types exist or should be created:

| File | Line | Context |
|------|------|---------|
| `core/sql/generator.py` | 94, 100 | Field search failures |
| `infrastructure/db_connector.py` | 130, 150 | DB connection/execution errors |
| `core/output/code_validator.py` | 186, 191 | Code execution validation |
| `presentation/zulip_bot.py` | 164 | Zulip connection error |

Note: `infrastructure/llm_client.py:213` already addressed this (uses `LLMCallError` elsewhere but has one remaining `Exception`).

**Severity:** Low (callers use `except Exception` anyway, but it prevents fine-grained error handling)

### 1.3 Bare `except Exception:` with silent swallow

6 locations catch `Exception` without logging or re-raising:

- `core/output/chart_builder.py:666` — catch-all returns None (documented pattern, OK)
- `core/output/df_merger.py:281` — same pattern, logs with `exc_info=True` (OK)
- `infrastructure/progress.py:71` — emit failure silently swallowed (should log at debug)
- `presentation/zulip_bot.py:102, 363, 464` — various silent catches
- `application/agent.py:315` — `_track_request` logs with `exc_info=True` (OK)

**Severity:** Low (most are intentional graceful degradation, well-documented in ADR-017 pattern)

### 1.4 Unused backward-compat re-export

`application/agent.py:20`:
```python
from application.reports import save_dataframes_to_excel  # noqa: F401 — backward compat re-export
```

No external code imports `save_dataframes_to_excel` from `application.agent`. This re-export can be removed.

**Severity:** Trivial

### 1.5 Step numbering mismatch in progress messages

`application/reports.py` uses user-facing step numbers (3, 4) that differ from pipeline step numbers (5, 6, 7, 8). Log messages reference pipeline numbers (6, 7, 8) but `_emit` messages use user-facing numbers. This dual numbering is confusing in logs when correlating with the architecture docs.

**Severity:** Low (cosmetic, but confusing for debugging)

### 1.6 No `print()` in core/infrastructure modules

Verified: zero `print()` calls in `core/` and `infrastructure/` packages. Style rule is followed.

### 1.7 No TODO/FIXME/HACK markers in production code

Verified: zero occurrences. Codebase is clean.

---

## 2. Pipeline Correctness Findings

### 2.1 Pipeline flow diagram

```
User Question
     │
     ▼
┌─────────────────────┐
│ 1. relevance_checker │──── irrelevant ──→ return error
└────────┬────────────┘
         ▼
���─────────────────────┐
│ 2. question_analyzer │──── exception ──→ fallback: [original question]
└────────┬────────────┘
         ▼
┌─────────────────────────────────────────────┐
│ 3. For each subquestion:                     │
│   3a. sql_generator  (retry on INSUFFICIENT) │
│   3b. sql_validator  (LIKE fix + EXPLAIN)    │
│   3c. db_connector   (retry + LLM SQL fix)   │
│   3d. chart_builder → chart_generator (LLM)  │
│   3e. response_generator                     │
└────────┬────────────────────────────────────┘
         ▼
┌─────────────────────────────────────────────┐
│ 4. df_merger (deterministic)                 │
│    └─→ LLM fallback: code_generator →       │
│        code_validator → execute_python_code  │
└────────┬────────────────────────────────────┘
         ▼
┌──────────────────┐
│ 5. final chart   │ (chart_builder → chart_generator)
│ 6. final response│ (generate_response or generate_final_response)
│ 7. Excel export  │
│ 8. PDF report    │
└────────┬─────────┘
         ▼
┌─────────────────┐
│ 9. request_tracker │ (non-fatal)
└─────────────────┘
```

### 2.2 Temporal context query runs without error guard for missing table

**File:** `application/subquestion.py:65-73`

```python
if db_connector.connection:
    max_date_df = db_connector.execute_query(
        "SELECT TO_CHAR(MAX(MONTH_DT), 'YYYY-MM-DD') AS MAX_DT FROM client_product"
    )
```

This hardcodes `client_product` table name. If metadata ever changes the table name, this query breaks silently (caught by bare `except`). Should use `get_table_metadata()["table_name"]`.

**Severity:** Low (table name is stable, but violates DRY)

### 2.3 `settings` variable `s` leaks from step 2 into step 3

**File:** `application/subquestion.py:151,181`

Step 2 does `s = get_settings()` inside the `with PerfTimer` block. Step 3 (line 181) uses `s.llm.sql_exec_fix_max_attempts` — this works because Python scoping, but the variable was defined inside an earlier code block. If step 2 were refactored to early-return before `s` assignment, step 3 would crash.

**Severity:** Low (works today, fragile)

### 2.4 SQL retry in step 3 re-validates but doesn't retry EXPLAIN PLAN on fixed SQL

**File:** `application/subquestion.py:217-228`

When `execute_query` fails, the code calls `fix_sql_with_llm()` then `validate_and_fix_sql()` on the fixed SQL. This is correct — `validate_and_fix_sql` includes EXPLAIN PLAN. No issue here.

### 2.5 `process_question` returns inconsistent status values

`process_question()` returns `status` field with values:
- `"error"` — from relevance check failure (line 357)
- `"success"` or `"no_data"` — from `generate_reports` (line 378)
- `"partial"` — from `generate_reports` exception handler (line 406)

But the docstring (line 330) says: `'success' или 'partial' или 'error'`. The `"no_data"` status is undocumented.

**Severity:** Low (consumers likely check `status != "success"`)

### 2.6 `_merge_dataframes` with single valid DataFrame skips merge correctly

When exactly 1 subquestion has a non-empty DataFrame, `auto_merge_dataframes` returns a copy of it. This is correct.

### 2.7 Chart generation: deterministic → LLM fallback is consistent

Both subquestion-level (`subquestion.py:247-262`) and final-level (`reports.py:244-264`) follow the same pattern: `build_chart()` → if None → `generate_chart()`. Pattern is consistent. No issue.

### 2.8 `generate_final_response` vs `generate_response` branching

**File:** `application/reports.py:298-322`

Three branches:
1. All subquestions failed → deterministic error message (no LLM call)
2. `final_df` exists and non-empty → `generate_response()` with SQL summary
3. No `final_df` → `generate_final_response()` (summarizes sub-answers via LLM)

Branch 3 is used when merge fails (returns None) or `skip_files=True`. This is correct — it falls back to LLM summarization of individual answers.

### 2.9 `skip_files` mode correctly skips chart/excel/pdf but still generates final response

**File:** `application/agent.py:397-418`

When `skip_files=True`:
- `final_df = None` (merge skipped)
- `generate_charts=False`, `generate_excel=False`, `generate_pdf=False`
- But `generate_reports` still calls `generate_final_response()` (branch 3 above)

This is correct for batch mode — you get the text answer without file artifacts.

### 2.10 Connection lifecycle: pool vs direct

**File:** `infrastructure/db_connector.py:38-76`

Pool mode uses `acquire()`/`release()`, direct mode uses `connect()`/`close()`. The `disconnect()` method handles both correctly. Context manager (`__enter__`/`__exit__`) also works.

However: in `subquestion.py:65`, the code checks `db_connector.connection` before querying MAX date. If using pool mode and `connection` hasn't been acquired yet, this temporal query is silently skipped. The connection is only established on first `execute_query` call (or manual `connect()`). In practice, the connection is established in the subquestion loop before this point via `process_question()` → but there's no explicit connect before the temporal query.

**Severity:** Medium (in pool mode, first subquestion may miss temporal context if connection not pre-acquired)

---

## 3. Test Coverage Assessment

### 3.1 Well-covered modules
- `infrastructure/utils.py` — 35 tests, thorough
- `core/sql/extraction.py`, `core/sql/keywords.py`, `core/sql/field_search.py` — good coverage
- `core/output/df_merger.py` — includes sync guard for KNOWN_KEYS
- `application/subquestion.py` — happy path, failure modes, edge cases
- `core/output/code_validator.py` — sandbox, import stripping

### 3.2 Missing: `core/output/response_generator.py` unit tests

File `tests/core/output/test_response_generator.py` exists but wasn't verifiable due to missing dependencies. This is a critical module (NL response generation) — should have tests for:
- `_deduplicate_df_columns`
- `_resolve_alias_to_base_field`
- `dataframe_to_text` truncation
- `is_date_column` detection

### 3.3 Missing: `core/analysis/question_analyzer.py` — `<think>` tag stripping

The `analyze_question()` function strips `<think>` tags before JSON extraction. No dedicated test for this logic — it's a critical parsing step since the LLM model uses reasoning tokens.

### 3.4 Missing: `application/reports.py` — deterministic error response when all subquestions fail

The branch at `reports.py:298-308` (successful_results == 0) generates a deterministic response. No test covers this path.

---

## 4. Recommended Actions (Priority Order)

### P1 — Bugs to fix
1. **`run_console` prints raw dict** → print `answer.get("message", str(answer))` at `agent.py:471`

### P2 — Pipeline correctness
2. **Temporal context table name** → use `get_table_metadata()["table_name"]` in `subquestion.py:67`
3. **Document `"no_data"` status** → add to `process_question` docstring
4. **Move `s = get_settings()` to top of function** in `subquestion.py` to avoid scope fragility

### P3 — Test coverage gaps
5. **Add test**: `test_analyze_question_strips_think_tags` in `tests/core/analysis/test_question_analyzer.py`
6. **Add test**: `test_generate_reports_all_failed_subquestions` in `tests/application/test_reports.py`
7. **Verify existing**: `test_response_generator.py` covers `_deduplicate_df_columns` and `is_date_column`

### P4 — Cleanup
8. **Remove unused re-export** `save_dataframes_to_excel` from `agent.py`
9. **Add debug logging** to `infrastructure/progress.py:71` silent exception

---

## 5. Verification

After implementing P1-P2 fixes:
```bash
# Unit tests
pytest tests/ -v

# Verify run_console output (manual)
python run_agent.py
# → Should print formatted message, not dict

# Integration (if dev env available)
pytest -m "integration and not slow"
```