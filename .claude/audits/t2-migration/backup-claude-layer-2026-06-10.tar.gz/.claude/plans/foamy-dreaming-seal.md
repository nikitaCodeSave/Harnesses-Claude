# Fix: validate_subquery_alias_mismatch заменяет alias definitions

## Context

`_replace_column_refs()` в `core/sql/validator.py:243` слепо заменяет все вхождения базовой колонки regex'ом `\bCA_LCY_SUM\b`, включая **alias definitions** после `AS`. Это портит имена выходных колонок SQL.

**Пример бага (Q2 из e2e):**
```sql
-- До валидатора:
AVG(daily_sum) AS CA_LCY_SUM   -- CA_LCY_SUM = имя выходной колонки

-- После валидатора:
AVG(daily_sum) AS daily_sum     -- СЛОМАНО: выходная колонка переименована
```

**Масштаб проблемы:** ВСЕ alias definitions во внешних запросах заменяются. Тест `test_basic_mismatch_fixed` уже ломает `AS pnl_sum` → `AS daily_pnl_sum` — тест проходит только потому что не проверяет alias definitions.

## Файлы

- `core/sql/validator.py` — fix в `_replace_column_refs()` (строки 278-293)
- `tests/core/sql/test_validator.py` — новые тесты + усиление существующих

## Изменение

### 1. `_replace_column_refs()` — пропуск alias definitions

В цикле замен (строка 280-293) добавить проверку: если совпадению предшествует `AS ` — пропустить.

```python
# Строка ~280, внутри цикла for m in pattern.finditer(masked):
if subquery_depth[m.start()] != 0:
    continue
# NEW: пропускаем alias definitions (AS column_name)
before = masked[:m.start()]
if re.search(r'\bAS\s+$', before, re.IGNORECASE):
    continue
```

Не нужен отдельный module-level regex — `re.search` с коротким паттерном на подстроке `before` достаточно быстр для SQL-строк.

### 2. Новые тесты

**test_alias_definition_not_replaced** — ключевой тест на баг:
```sql
SELECT AVG(daily_sum) AS CA_LCY_SUM
FROM (SELECT SUM(CA_LCY_SUM) AS daily_sum FROM client_product GROUP BY MONTH_DT) t
```
Ожидание: `AS CA_LCY_SUM` сохранено, `modified is False` (нет column references для замены).

**test_outer_alias_def_preserved_with_ref_replaced** — замена column ref без порчи alias def:
```sql
SELECT SUM(PNL_SUM) AS pnl, AVG(daily_sum) AS CA_LCY_SUM
FROM (SELECT SUM(CA_LCY_SUM) AS daily_sum, SUM(PNL_SUM) AS daily_pnl FROM ...) t
```
Ожидание: `SUM(PNL_SUM)` → `SUM(daily_pnl)`, но `AS CA_LCY_SUM` сохранено.

**test_q2_bug_outer_alias_preserved** — точный SQL из e2e Q2:
```sql
SELECT TO_CHAR(MONTH_DT, 'YYYY-MM') AS month,
       SUM(PNL_SUM) AS PNL_SUM,
       AVG(daily_sum) AS CA_LCY_SUM
FROM (SELECT MONTH_DT, SUM(CA_LCY_SUM) AS daily_sum FROM client_product ...) t
```
Ожидание: `AS CA_LCY_SUM` сохранено, `AS PNL_SUM` сохранено. PNL_SUM не в alias_map → не трогается.

### 3. Усиление существующих тестов

**test_basic_mismatch_fixed** (строка 1291) — добавить:
```python
assert "AS pnl_sum" in result_sql or "AS PNL_SUM" in result_upper
assert "AS fx_margin_rub" in result_sql or "AS FX_MARGIN_RUB" in result_upper
assert "AS ca_lcy_sum" in result_sql or "AS CA_LCY_SUM" in result_upper
```

**test_real_run4_query_fixed** (строка 1449) — добавить:
```python
assert "AS pnl_sum" in result_sql
assert "AS fx_margin_rub" in result_sql
assert "AS ca_lcy_sum" in result_sql
assert "AS dep_sum" in result_sql
```

## Верификация

1. TDD: сначала новые тесты → RED, потом fix → GREEN
2. `pytest tests/core/sql/test_validator.py::TestValidateSubqueryAliasMismatch -v`
3. `pytest tests/ -v` — полный прогон (1161 тест)
4. `python dev/e2e_alias_pipeline.py` — e2e на живой Oracle + Ollama, проверить что `AS CA_LCY_SUM` сохранено в validated SQL
