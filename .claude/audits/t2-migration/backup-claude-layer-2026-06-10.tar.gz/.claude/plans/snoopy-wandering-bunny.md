# План: обновление SQL generator промпта

## Context

Обновить `core/sql/prompts/v1/system.txt` на основе `dev/prompt.txt`. Новый промпт добавляет секцию "GROUP BY FIELDS IN FINAL OUTPUT" и улучшает форматирование, но содержит ошибки в именах полей-примеров, которые нужно исправить перед применением.

## Что берём из dev/prompt.txt

1. **НОВАЯ секция "GROUP BY FIELDS IN FINAL OUTPUT"** (строки 464-488) — hard constraint для outermost SELECT
2. **Компактное форматирование** — убраны лишние пустые строки
3. **Исправлен пробел** `INSUFFICIENT DATA    FALLBACK` → `INSUFFICIENT DATA FALLBACK`

## Что исправляем в dev/prompt.txt при переносе

### 1. Имена полей-примеров → реальные из metadata.py
Реальные VARCHAR2 колонки: `SEG`, `GROUP_NM`, `ORGANIZATION_NM`, `DESK`, `HUB`, `MANAGER_NAME`

| Строка dev/prompt.txt | Ошибочное значение | Правильное значение |
|---|---|---|
| 267 (секция 3.3) | `SEGMENT` | `SEG, HUB` |
| 395 (TEXT SEARCH, список полей) | `DESK, MANAGER, GROUP, SEGMENT` | `DESK, MANAGER_NAME, GROUP_NM, SEG` |
| 435 (multiple LIKE filters) | `GROUP_NM, SEGMENT_NM, MANAGER_NM` | `GROUP_NM, SEG, MANAGER_NAME` |

### 2. Typo: `CLOSE_DATW` → `CLOSE_DATE` (строка 355)

### 3. Separator + заголовок секции CURRENCY METADATA (строка 87)
Разделить на две строки (как во всех остальных секциях):
```
--------------------------------
📊 CURRENCY METADATA (in fields_description metadata)
--------------------------------
```

## План действий

1. Заменить содержимое `core/sql/prompts/v1/system.txt` текстом из `dev/prompt.txt`
2. Применить 5 точечных исправлений (таблица выше + typo + separator)
3. Прогнать тесты: `pytest tests/core/sql/ -v`

## Файлы для изменения
- `core/sql/prompts/v1/system.txt` — единственный файл

## Верификация
- `pytest tests/core/sql/ -v` — тесты SQL модуля
- Визуальная проверка: все `{table_name}`, `{fields_description}`, `{table_description}`, `{question}` плейсхолдеры на месте
