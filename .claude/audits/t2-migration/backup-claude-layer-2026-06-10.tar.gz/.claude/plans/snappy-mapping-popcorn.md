# Spec: Синхронизация pie-chart инструкций LLM с проверенным Подходом 1

## Context

В `chart_builder.py` (детерминированный путь) pie-чарты реализованы по Подходу 1: проценты на сегментах (`autopct=lambda pct: f"{pct:.1f}%"`), абсолютные значения в легенде справа. Это работает хорошо даже с маленькими сегментами (2-7%).

Промпт в `chart_generator.py` (LLM-fallback путь) содержит **несогласованные** инструкции:
- Строки 211, 217: `Labels: value + percentage (e.g., "150.5 M (23.4%)")` — подразумевает обе значения на сегменте
- Строка 280: `Pie charts: use autopct + add absolute values` — тоже подразумевает всё на сегменте

Нужно привести промпт LLM к Подходу 1, чтобы LLM-fallback генерировал такие же читаемые pie-чарты.

## Файл

`core/output/chart_generator.py` — только промпт внутри `generate_chart_code()`.

## Задачи

### Task 1: Обновить инструкции pie chart в промпте generate_chart_code

**Files:** `core/output/chart_generator.py`
**Depends on:** none

Заменить 3 места в промпте:

1. **Строки ~207-211** (секция STRUCTURE FROM SINGLE ROW → pie):
   - Было: `Labels: value + percentage (e.g., "150.5 M (23.4%)")`
   - Стало: инструкция использовать `autopct=lambda pct: f"{pct:.1f}%"` для процентов на сегментах, и `ax.legend()` с абсолютными значениями справа

2. **Строки ~213-217** (секция STRUCTURE / SHARES / DISTRIBUTION):
   - Было: `Labels: value + percentage (e.g., "150.5 M (23.4%)")`
   - Стало: аналогичная инструкция про проценты на сегментах + легенда с абсолютными значениями

3. **Строка ~280** (секция MANDATORY DATA LABELS):
   - Было: `Pie charts: use autopct + add absolute values.`
   - Стало: `Pie charts: autopct=lambda pct: f"{pct:.1f}%" on slices, absolute values in ax.legend() on the right.`

**Done when:** промпт содержит единообразные инструкции для pie charts по Подходу 1.

### Task 2: Обновить devlog

**Files:** `devlog/changelog.json`
**Depends on:** Task 1

Добавить запись о синхронизации промпта с chart_builder.

## Риски

| Сценарий | Вероятность | Воздействие | Действие |
|----------|-------------|-------------|----------|
| LLM игнорирует новые инструкции | low | LLM-fallback pie chart менее читаем | Промпт — рекомендация, LLM может адаптировать |
| Случайно сломан синтаксис промпта | low | chart_generator перестанет работать | `pytest tests/core/output/ -v` |

## Масштаб

- 1 файл для изменения кода (`chart_generator.py`, только текст промпта)
- 1 файл для devlog
- 0 новых тестов (текст промпта, логика не меняется)

## Верификация

1. `pytest tests/core/output/test_chart_generator.py -v` — существующие тесты проходят
2. Визуальная проверка промпта — 3 места обновлены единообразно
