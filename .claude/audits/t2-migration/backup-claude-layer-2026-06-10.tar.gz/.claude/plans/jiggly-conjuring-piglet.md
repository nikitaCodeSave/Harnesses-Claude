# План: улучшение описаний FX-полей в metadata.py

## Context

Вопросы про "валютные платежи" неправильно маршрутизируются на FX-поля вместо VED_VOL. Причина: TF-IDF индексирует полный текст описаний, и фраза "Запрещено использовать это поле для валютных платежей" в FX-полях парадоксально повышает их TF-IDF score для запросов о валютных платежах.

Ожидаемый результат: LLM получает FX и VED поля в контексте, но описания чётко разделяют конверсии (FX) от платежей (VED), с explicit redirect на VED_VOL.

## Анализ воздействия

| Модуль | Изменение | Риск |
|--------|-----------|------|
| `infrastructure/metadata.py` | Обновление description/description_en 9 FX-полей + VED_VOL | low — только текст описаний, структура не меняется |
| `core/sql/field_search.py` | Нет изменений кода — TF-IDF автоматически переиндексирует | none |
| 6 зависимых модулей | Нет — используют descriptions as-is для LLM промптов | none |

## Изменения

### Task 1: Обновить description FX-полей (9 полей)
**Files:** `infrastructure/metadata.py` (строки 169-256, 291-301)
**Depends on:** none

Текущий паттерн запрета:
```
Запрещено использовать это поле для валютных платежей
```

Новый паттерн (по предложению пользователя):
```
Запрещено использовать для валютных платежей (это конверсии/обмен валюты, для валютных платежей используй VED_VOL)
```

Английский эквивалент:
```
Do not use for foreign currency payments (this is currency conversion/exchange; for foreign currency payments use VED_VOL)
```

Затронутые поля (9 шт):
- FX_VOLUME_RUB (строка 171)
- FX_CNT (строка 182)
- FX_EUR_MARGIN_RUB (строка 193)
- FX_EUR_VOLUME_RUB (строка 204)
- FX_EUR_CNT (строка 215)
- FX_CNY_MARGIN_RUB (строка 226)
- FX_CNY_VOLUME_RUB (строка 237)
- FX_CNY_CNT (строка 248)
- FX_MARGIN_RUB (строка 293 — у него сейчас нет запрета про валютные платежи, но он FX-поле, добавить)

**Done when:** все 9 FX-полей содержат обновлённый запрет с redirect на VED_VOL.

### Task 2: Уточнить description VED_VOL
**Files:** `infrastructure/metadata.py` (строка 338)
**Depends on:** none

**Семантика VED_VOL:** это общий объём ВЭД — включает и валютные трансграничные платежи, и рублевые трансграничные платежи. Поле используется как для вопросов про "валютные платежи", так и для "ВЭД операции". Отдельного поля только для валютных платежей нет — VED_VOL ближайшее.

Текущее описание VED_VOL:
```
Сумма (объем) ВЭД операций клиента за отчетный месяц в рублевом эквиваленте: валютные трансграничные платежи (валютный ВЭД) и рублевые трансграничные платежи (рублевый ВЭД). Показатель включает общую сумму как входящих так и исходящих ВЭД платежей. Запрещено использовать для валютных платежей или только для рублевых трансграничных платежей, это общее поле.
```

Проблема: описание ЗАПРЕЩАЕТ использовать VED_VOL для валютных платежей — прямо противоречит redirect из FX-полей. Нужно убрать запрет и добавить positive guidance:
```
Сумма (объем) ВЭД операций клиента за отчетный месяц в рублевом эквиваленте: валютные трансграничные платежи (валютный ВЭД) и рублевые трансграничные платежи (рублевый ВЭД). Показатель включает общую сумму как входящих так и исходящих ВЭД платежей. Используй это поле для вопросов про валютные платежи и ВЭД операции — это общий объём ВЭД, включающий и валютные, и рублевые трансграничные платежи.
```

Английский:
```
Amount (volume) of VED operations for reporting month in ruble equivalent: foreign currency cross-border payments (currency VED) and ruble cross-border payments (ruble VED). Includes sum of incoming and outgoing VED payments. Use this field for questions about foreign currency payments and VED operations — this is total VED volume including both foreign currency and ruble cross-border payments.
```

Также исправить `operation_currency`: "EUR" → "MULTI" (поле покрывает все валюты + рубли).

**Done when:** VED_VOL description содержит positive guidance (используй для валютных платежей и ВЭД), operation_currency = "MULTI".

### Task 3: Тест на правильное ранжирование
**Files:** `tests/core/sql/test_field_search.py`
**Depends on:** Task 1, Task 2

Добавить тест: для вопроса "валютные платежи" VED_VOL должен ранжироваться выше FX_VOLUME_RUB.

**Done when:** тест проходит, подтверждает что VED_VOL > FX_VOLUME_RUB по TF-IDF score.

### Task 4: Devlog + проверка тестов
**Files:** `devlog/changelog.json`
**Depends on:** Task 1-3

1. `pytest tests/ -v` — все unit-тесты проходят
2. `pytest tests/infrastructure/test_metadata.py -v` — мета-тесты (phantom references) проходят
3. Запись в devlog

**Done when:** все тесты зелёные, devlog обновлён.

## Риски

| Сценарий | Вероятность | Действие |
|----------|-------------|----------|
| Phantom reference тест падает (VED_VOL ссылка в FX описаниях) | low — VED_VOL существует в metadata | Проверить test_field_descriptions_no_phantom_references |
| TF-IDF score VED_VOL не повышается достаточно | medium | Live-тест через run_agent.py с вопросом о валютных платежах |
| Другие вопросы про FX конверсии ломаются | low — основное описание FX не меняется | Проверить "FX операции" в тесте test_fx_question_finds_fx_fields |

## Масштаб

- 1 файл кода (metadata.py): ~10 строк description + 1 строка operation_currency
- 1 файл тестов: +1 тест
- 1 файл devlog
- Параллельность: Task 1 и Task 2 параллельны, Task 3 после них

## Верификация

1. `pytest tests/infrastructure/test_metadata.py tests/core/sql/test_field_search.py -v`
2. Live-тест: `python run_agent.py` → "Какой объем валютных платежей обслужил менеджер Иванов за октябрь 2024?" → SQL должен использовать VED_VOL, не FX_VOLUME_RUB
