# Plan: Архитектурная стандартизация прогресс-сообщений

## Context

**Проблема:** ZulipLogger решает приоритет flush через substring matching по тексту сообщений (`"[Шаг" in message`, `"✅" in message`). Это создаёт хрупкую связь presentation → application: изменение формата текста ломает flush-логику. Сообщения без "правильных" подстрок (6 шт в agent.py) доставляются с задержкой.

**Решение:** Ввести `ProgressMessage` dataclass с явным `priority: bool`. Flush-решение принимается по метаданным, не по тексту. Форматирование — через функции в `progress.py`.

---

## Архитектура: до и после

### До (текстовое сопряжение)
```
agent.py:  _emit("[Шаг 1] ⏳ Проверка...")     # str
  → ZulipLogger.emit(message: str)
    → if "[Шаг" in message or "✅" in message:  # substring matching
        flush()
```

### После (структурное сопряжение)
```
agent.py:  _emit(step(1, "Проверка...", STARTED))  # ProgressMessage
  → ZulipLogger.emit(msg: ProgressMessage)
    → if msg.priority:                              # metadata check
        flush()
    → buffer.write(str(msg))                        # text from __str__
```

---

## Дизайн: `application/progress.py`

```python
from dataclasses import dataclass

@dataclass(frozen=True, slots=True)
class ProgressMessage:
    """Структурированное прогресс-сообщение с приоритетом доставки."""
    text: str
    priority: bool = False   # True = немедленный flush в Zulip

    def __str__(self) -> str:
        return self.text

# Status-константы
STARTED = "⏳"
SUCCESS = "✅"
ERROR   = "❌"
WARNING = "⚠️"
SKIPPED = "⏭️"

def step(n: int, msg: str, status: str = "") -> ProgressMessage:
    """[Шаг {n}] {status} {msg} — всегда priority."""
    parts = [f"[Шаг {n}]"]
    if status:
        parts.append(status)
    parts.append(msg)
    return ProgressMessage(text=" ".join(parts), priority=True)

def substep(step_n: int, total: int, msg: str, status: str = "") -> ProgressMessage:
    """[Подвопрос] {status} Шаг {step_n}/{total}: {msg} — всегда priority."""
    parts = ["[Подвопрос]"]
    if status:
        parts.append(status)
    parts.append(f"Шаг {step_n}/{total}: {msg}")
    return ProgressMessage(text=" ".join(parts), priority=True)

def substep_detail(msg: str, status: str = "") -> ProgressMessage:
    """[Подвопрос] {status} {msg} — priority если есть status."""
    parts = ["[Подвопрос]"]
    if status:
        parts.append(status)
    parts.append(msg)
    return ProgressMessage(text=" ".join(parts), priority=bool(status))

def transition(i: int, total: int, subq_text: str) -> ProgressMessage:
    """[Подвопрос] ▶ Подвопрос {i}/{total}: {text} — всегда priority."""
    return ProgressMessage(
        text=f"[Подвопрос] ▶ Подвопрос {i}/{total}: {subq_text}",
        priority=True,
    )

def detail(msg: str) -> ProgressMessage:
    """Информационная строка без префикса — НЕ priority (буферизуется)."""
    return ProgressMessage(text=msg, priority=False)
```

**Ключевые решения:**
- `priority=True` для шагов, подшагов, переходов, статусов — немедленная доставка
- `priority=False` для detail-строк (список подвопросов, количество строк) — буферизация
- `__str__` позволяет `print(msg)` работать в CLI без изменений
- `frozen=True` — immutable, безопасно для передачи между потоками
- `slots=True` — минимальный memory footprint

---

## Изменения в ZulipLogger

```python
# presentation/zulip_bot.py

class ZulipLogger:
    def emit(self, message: ProgressMessage) -> None:
        if not message:
            return

        text = str(message)

        # Эхо в консоль
        _stdout = sys.__stdout__
        if _stdout is not None:
            _stdout.write(text + "\n")
            _stdout.flush()

        # Буферизация
        self.buffer.write(text + "\n")
        self.line_count += 1

        # Flush: метаданные вместо substring matching
        should_flush = (
            message.priority
            or (time.time() - self.last_sent_time >= self.min_interval)
            or (self.line_count >= self.max_lines)
        )
        if should_flush:
            self.flush()
```

**Что удаляется:**
- `_should_skip_line()` — не нужен (пустые строки не генерируются через progress functions)
- `STEP_PREFIX in message` — заменено на `message.priority`
- `SUBSTEP_PREFIX in message` — заменено на `message.priority`
- `"✅" in message`, `"❌" in message`, `"⚠️" in message` — заменено на `message.priority`
- Import `STEP_PREFIX, SUBSTEP_PREFIX` из `progress.py` — не нужен
- `self.lock` (неиспользуемый) — удалить

---

## Изменения в make_emit

```python
# infrastructure/utils.py
from application.progress import ProgressMessage

def make_emit(
    callback: Callable[[ProgressMessage], None] | None = None,
) -> Callable[[ProgressMessage], None]:
    """Создаёт emit-функцию: callback если задан, иначе print."""
    if callback is not None:
        return callback
    return lambda message: print(message, flush=True)  # __str__ handles formatting
```

---

## Задачи

### Task 1: `application/progress.py` — ProgressMessage + форматтеры
- **Файл:** `application/progress.py`
- **Что:** ProgressMessage dataclass, 5 status-констант, 5 функций (step, substep, substep_detail, transition, detail)
- **Удалить:** STEP_PREFIX, SUBSTEP_PREFIX (больше не экспортируются — не нужны для flush)
- **Done:** Функции возвращают ProgressMessage с корректным priority

### Task 2: Тесты для progress.py (TDD)
- **Файл:** `tests/application/test_progress.py` (новый)
- **Тесты (~15):**
  - `test_step_returns_progress_message`
  - `test_step_priority_always_true`
  - `test_step_format_with_status` / `test_step_format_without_status`
  - `test_substep_priority_always_true`
  - `test_substep_format`
  - `test_substep_detail_priority_true_with_status` / `test_substep_detail_priority_false_without_status`
  - `test_transition_priority_true`
  - `test_transition_format`
  - `test_detail_priority_false`
  - `test_progress_message_str` (str() возвращает text)
  - `test_progress_message_frozen` (immutable)
  - `test_all_statuses_are_nonempty_strings`
- **Зависит от:** Task 1
- **Done:** `pytest tests/application/test_progress.py -v` green

### Task 3: Миграция `agent.py` (14 → ~12 вызовов)
- **Файл:** `application/agent.py`
- **Import:** `from application.progress import step, transition, detail, STARTED, SUCCESS, ERROR, WARNING, SKIPPED, ProgressMessage`
- **Миграция:**

| Строка | До | После |
|--------|-----|-------|
| 325 | `"ОБРАБОТКА ВОПРОСА"` | **удалить** (избыточно) |
| 328 | `"[Шаг 1] Проверка релевантности..."` | `step(1, "Проверка релевантности вопроса...", STARTED)` |
| 333 | `f"[Шаг 1] {relevance_message}"` | `step(1, relevance_message, SUCCESS)` |
| 335 | `f"[Шаг 1] ❌ ОШИБКА..."` | `step(1, f"ОШИБКА в check_relevance: {e}", ERROR)` |
| 352 | `"\n[Шаг 2] Анализ..."` | `step(2, "Анализ вопроса и разбиение на подвопросы...", STARTED)` |
| 356 | `"\n[Шаг 2] ✅ Анализ завершен..."` | `step(2, f"Анализ завершен. Сгенерировано {len(subquestions)} подвопросов:", SUCCESS)` |
| 360 | `f"  {i}. {subq}"` | `detail(f"  {i}. {subq}")` |
| 362 | `f"[Шаг 2] ⚠️ Ошибка..."` | `step(2, f"Ошибка при анализе: {e}, используем исходный вопрос", WARNING)` |
| 126 | `f"▶ ПЕРЕХОД К ПОДВОПРОСУ..."` | `transition(i, len(subquestions), subq)` |
| 127 | `f"Подвопрос: {subq}"` | **удалить** (дублирует transition) |
| 133-138 | Summary-строки с emoji | `detail(f"  - SQL: {'сгенерирован' if ... else 'не сгенерирован'}")` и т.д. |
| 383 | `"⏭️ Merge пропущен"` | `step(2, "Merge DataFrames пропущен (skip_files)", SKIPPED)` |

- **Зависит от:** Task 1
- **Done:** Все _emit() принимают ProgressMessage

### Task 4: Миграция `subquestion.py` (19 вызовов)
- **Файл:** `application/subquestion.py`
- **Import:** `from application.progress import substep, substep_detail, STARTED, SUCCESS, ERROR, WARNING`
- **Паттерн замены:**
  - `"[Подвопрос] 📝 Шаг 1/5: ..."` → `substep(1, 5, "Генерация SQL запроса...", STARTED)`
  - `"[Подвопрос] ⚠️ ..."` → `substep_detail("...", WARNING)`
  - `"[Подвопрос] ❌ ..."` → `substep_detail("...", ERROR)`
  - `"\n[Подвопрос] ✅ Шаг 2/5 завершен..."` → `substep(2, 5, "SQL прошел валидацию", SUCCESS)`
  - Per-step emoji (📝🔍🗄️📊💬) → универсальные status-emoji
- **Зависит от:** Task 1
- **Done:** 0 хардкоженных `[Подвопрос]` в _emit() вызовах

### Task 5: Миграция `reports.py` (9 вызовов)
- **Файл:** `application/reports.py`
- **Import:** `from application.progress import step, STARTED, SUCCESS, ERROR, WARNING, SKIPPED`
- **Паттерн замены:**
  - `"[Шаг 3] ГЕНЕРАЦИЯ ИТОГОВОГО ГРАФИКА"` → `step(3, "Генерация итогового графика", STARTED)`
  - `"[Шаг 3] ⚠️ ..."` → `step(3, "...", WARNING)`
  - `"[Шаг 4] ГЕНЕРАЦИЯ ФИНАЛЬНОГО ОТВЕТА"` → `step(4, "Генерация финального ответа", STARTED)`
  - `"[Шаг 4] ✅ ..."` → `step(4, "...", SUCCESS)`
  - и т.д.
- **Зависит от:** Task 1
- **Done:** 0 хардкоженных `[Шаг` в _emit() вызовах

### Task 6: Обновить `make_emit()` и ZulipLogger
- **Файлы:** `infrastructure/utils.py`, `presentation/zulip_bot.py`
- **utils.py:**
  - Обновить type hint: `Callable[[ProgressMessage], None]`
  - Import ProgressMessage
- **zulip_bot.py:**
  - `emit(message: ProgressMessage)` — типизация
  - Flush: `message.priority` вместо substring matching
  - Удалить: `_should_skip_line()`, import STEP_PREFIX/SUBSTEP_PREFIX, `self.lock`
  - Удалить: 5 строк substring-триггеров (lines 134-138)
  - Эхо: `str(message)` для консольного вывода
- **Зависит от:** Task 1
- **Done:** ZulipLogger не содержит substring matching, flush по metadata

### Task 7: Обновить тесты
- **Файлы:**
  - `tests/presentation/test_zulip_logger.py` — обновить под новый API (emit принимает ProgressMessage, нет _should_skip_line)
  - `tests/application/test_callback.py` — обновить строки если нужно
  - `tests/infrastructure/test_utils.py` — обновить тест make_emit если есть
- **Новые тесты:**
  - `test_emit_flushes_on_priority_true` — priority=True → flush()
  - `test_emit_buffers_on_priority_false` — priority=False → no immediate flush
  - `test_emit_flushes_on_time_interval` — время прошло → flush
  - `test_emit_flushes_on_max_lines` — max_lines → flush
  - Мета-тесты: grep agent/subquestion/reports на `_emit("` (raw strings) → 0 matches
- **Зависит от:** Tasks 3-6
- **Done:** `pytest tests/ -v` all green

### Task 8: Devlog + верификация
- **Файл:** `devlog/changelog.json`
- **Что:** Запись в devlog, полный pytest, live-тест `python run_agent.py`
- **Зависит от:** Tasks 1-7
- **Done:** Devlog, all tests green, консольный вывод корректен

---

## Параллелизм

```
Task 1 (progress.py — ProgressMessage + API)
  ├── Task 2 (тесты progress.py)
  ├── Task 3 (agent.py)       ─┐
  ├── Task 4 (subquestion.py)  ─┤ параллельно (разные файлы)
  └── Task 5 (reports.py)     ─┘
        └── Task 6 (make_emit + ZulipLogger)
              └── Task 7 (тесты)
                    └── Task 8 (devlog + verify)
```

Tasks 3, 4, 5 — независимы, можно через Agent Teams.

---

## Риски

| Сценарий | Вероятность | Действие |
|----------|-------------|----------|
| Где-то осталась `_emit("raw string")` | Low | Мета-тесты grep ловят это |
| `print(ProgressMessage)` в CLI работает некорректно | Low | `__str__` возвращает text, покрыто тестом |
| Внешний код вызывает `zulip_logger.emit("string")` | Low | Grep по проекту — emit вызывается только через make_emit chain |
| Удаление `_should_skip_line` пропускает separators | Low | Separators больше не генерируются через _emit (удалены ранее) |

---

## Верификация

1. `pytest tests/ -v` — все unit-тесты green
2. `pytest tests/application/test_progress.py -v` — новые тесты green
3. `python run_agent.py` — live-тест, проверить формат в консоли
4. Grep: `_emit("` → 0 совпадений в agent.py/subquestion.py/reports.py (все через progress functions)
5. Grep: `STEP_PREFIX\|SUBSTEP_PREFIX` в zulip_bot.py → 0 (удалены)

---

## Масштаб

- **Файлов для изменения:** 5 (progress.py, agent.py, subquestion.py, reports.py, zulip_bot.py, utils.py)
- **Файлов для создания:** 1 (test_progress.py)
- **Файлов для обновления тестов:** 2-3 (test_zulip_logger.py, test_callback.py, test_utils.py)
- **Удаляется:** ~15 строк substring matching из ZulipLogger, _should_skip_line(), STEP_PREFIX/SUBSTEP_PREFIX exports
- **Тестов для написания:** ~20
