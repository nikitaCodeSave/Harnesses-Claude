# План: мелкие улучшения (cleanup + docs)

## Контекст

Спецификация из 4 пунктов по результатам аудита кодовой базы. После исследования:
- **#1 (EmitFn dead code) — НЕВАЛИДНА.** `EmitFn` активно используется: импортируется в `application/reports.py:23` и `application/subquestion.py:20`, применяется как type annotation в сигнатурах функций (reports.py:211, subquestion.py:33). Research-документ ошибся.
- **#2 — Закрыта** (уже исправлено).
- **#3 — Валидна.** print() в ZulipBot.run() (строки 497-503).
- **#4 — Валидна.** В docs/architecture.md нет раздела о ProgressEvent flow.

## Задачи

### Task 1: print() -> logger в ZulipBot.run()
- **Files:** `presentation/zulip_bot.py` (строки 497-503)
- **Depends on:** none
- **Что делать:** Заменить 6 print() на logger.info() в методе run(). Бот — точка входа, но в контейнере print и logger идут в разные потоки (stdout vs stderr). logger.info уже настроен через log_setup.
- **Done when:** startup banner выводится через logger.info, pytest проходит

### Task 2: Раздел "Механизм прогресс-уведомлений" в docs/architecture.md
- **Files:** `docs/architecture.md`
- **Depends on:** none
- **Что делать:** Добавить раздел после "Полный поток обработки запроса" (после строки 337). Описать:
  - Поток: AIAgent.on_progress (ProgressCallback) -> make_progress_emit() -> EmitFn -> вызовы в subquestion.py/reports.py
  - Типы событий (STEP, SUBSTEP, STATUS, INFO) и стратегии доставки
  - Потребители: ZulipLogger (буферизация + flush), console (print fallback)
  - Ссылка на ADR-020
- **Done when:** раздел добавлен, информация соответствует коду

### Task 3: Devlog + верификация
- **Files:** `devlog/changelog.json`
- **Depends on:** Task 1, Task 2
- **Что делать:** Запись в changelog, прогон pytest
- **Done when:** pytest проходит, devlog обновлён

## Отклонённые задачи

| # | Причина |
|---|---------|
| 1 | EmitFn НЕ dead code — используется в reports.py и subquestion.py |
| 2 | Уже закрыта |

## Риски

| Сценарий | Вероятность | Действие |
|----------|-------------|----------|
| logger не настроен к моменту run() | low | logger = getLogger(__name__) уже есть в модуле |

## Масштаб
- 2 файла к изменению + devlog
- 0 новых тестов (стилевой рефакторинг + docs)
- Параллельное выполнение: Task 1 и Task 2 независимы
