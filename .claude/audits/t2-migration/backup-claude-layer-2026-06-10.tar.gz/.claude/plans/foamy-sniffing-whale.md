# Аудит: nested aggregates + LIKE-constraint validation

## Контекст

После реализации `validate_nested_aggregates()` и live-тестирования — аудит полноты обеих детерминированных проверок в `core/sql/validator.py`. Цель: найти пробелы в edge cases, покрытии тестами, и закрыть их.

## Результат аудита

### LIKE-constraint validation — ЗАКРЫТА, действий не требуется

51 тест, все critical edge cases покрыты: depth-aware detection, CTE, UNION skip, NOT LIKE skip, SELECT *, metadata filtering, table aliases, HAVING/ORDER BY/FETCH FIRST. Пробелов нет.

### Nested aggregates — 1 реальный пробел

**Проблема:** regex `_NESTED_AGG_RE` не ловит DISTINCT между агрегатами:
```
AVG(DISTINCT SUM(x))   — НЕ детектируется (Oracle вернёт ORA-00937)
SUM(DISTINCT COUNT(x))  — НЕ детектируется
```

Текущий regex: `\b(SUM|COUNT|AVG|MAX|MIN)\s*\(\s*(SUM|COUNT|AVG|MAX|MIN)\s*\(`
Проблема: `\s*` не матчит `DISTINCT `.

## Затронутые файлы

| Файл | Изменение |
|------|-----------|
| `core/sql/validator.py` | 1 строка: regex `_NESTED_AGG_RE` + `(?:DISTINCT\s+)?` |
| `tests/core/sql/test_validator.py` | 1 тест: `test_nested_agg_with_distinct_detected` |

## Реализация

### 1. Фикс regex (validator.py, ~строка 173)

```python
# Было:
_NESTED_AGG_RE = re.compile(
    r"""\b(SUM|COUNT|AVG|MAX|MIN)\s*\(\s*(SUM|COUNT|AVG|MAX|MIN)\s*\(""",
    re.IGNORECASE,
)

# Стало:
_NESTED_AGG_RE = re.compile(
    r"""\b(SUM|COUNT|AVG|MAX|MIN)\s*\(\s*(?:DISTINCT\s+)?(SUM|COUNT|AVG|MAX|MIN)\s*\(""",
    re.IGNORECASE,
)
```

### 2. Тест (test_validator.py, класс TestValidateNestedAggregates)

```python
def test_nested_agg_with_distinct_detected(self):
    """AVG(DISTINCT SUM(x)) at depth=0 is detected."""
    sql = "SELECT AVG(DISTINCT SUM(PNL_SUM)) FROM client_product GROUP BY MONTH_DT"
    result = validate_nested_aggregates(sql)
    assert result is not None
```

## Верификация

1. `pytest tests/core/sql/test_validator.py::TestValidateNestedAggregates -v` — 9 тестов green
2. `pytest tests/ -v` — регрессий нет
