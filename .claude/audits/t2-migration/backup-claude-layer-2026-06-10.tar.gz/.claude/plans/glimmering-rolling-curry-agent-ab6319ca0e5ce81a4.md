# Research: spec-kit, claude-mem, Everyrow pipeline

This is a RESEARCH-ONLY document. No code changes.

---

## 1. GitHub Spec-Kit (github/spec-kit)

**Repo:** https://github.com/github/spec-kit | **Stars:** ~82,600 | **Created:** 2025-08-21

### What it is

Open-source CLI toolkit for Spec-Driven Development (SDD). Works with 25+ AI agents: Claude Code, GitHub Copilot, Gemini CLI, Cursor, Windsurf, etc. Install via `uv tool install specify-cli`.

### The 4-Phase Workflow

Each phase has a slash command. Phases are sequential -- output of each feeds the next.

**Phase 1: `/speckit.constitution`**
- Defines immutable project principles (coding standards, architecture constraints, security, testing policy).
- 9 "articles" that govern ALL subsequent generation. Example articles: "Every feature begins as standalone reusable library," "TDD is non-negotiable," "Integration-first testing with real databases."
- Acts as "architectural DNA" -- ensures consistency across time, models, and team members.
- Stored in `.specify/memory/constitution.md`. Survives project upgrades (but file itself gets overwritten -- back up before upgrade).

**Phase 2: `/speckit.specify`**
- Takes high-level prompt, generates full spec (PRD).
- Focus on WHAT and WHY, not HOW. User journeys, success criteria, experiences.
- Uncertainty markers: `[NEEDS CLARIFICATION]` tags prevent speculative assumptions.
- Anti-speculation clause: only requirements with concrete user stories advance.
- Output: `specs/spec.md`

**Phase 3: `/speckit.plan`**
- User provides tech stack direction; AI generates detailed implementation plan.
- Maps requirements to technical decisions with documented rationale.
- Respects constitution constraints.
- Output: `specs/plan.md`

**Phase 4: `/speckit.tasks`**
- Auto-generates task breakdown from plan.
- Reads: `plan.md`, `spec.md`, optionally `data-model.md`, `contracts/`, `research.md`.
- Supports pre/post hooks via `.specify/extensions.yml`.
- Output: `specs/tasks.md`

**Phase 5 (bonus): `/speckit.implement`**
- Executes all tasks sequentially.

Additional commands: `/speckit.clarify` (resolve ambiguities), `/speckit.analyze` (validate consistency across documents).

### Task Format and Dependencies

Tasks use a specific markdown checklist format:

```
- [ ] T001 [P] [US1] Create user authentication module src/auth/module.ts
```

Components:
- `- [ ]` -- checkbox (always unchecked initially)
- `T001` -- sequential task ID
- `[P]` -- **parallelization marker** (only if task touches different files and has no dependency on incomplete tasks)
- `[US1]` -- user story label (for story phases only)
- Description with exact file path

**Phase structure within tasks.md:**
1. **Setup** -- project initialization (no deps)
2. **Foundational** -- core infrastructure, CRITICAL blocker for everything else
3. **User Stories (P1, P2, P3...)** -- priority-ordered, each independently completable/testable
4. **Polish** -- cross-cutting improvements after stories complete
5. **Checkpoints** -- validation gates between phases

**Dependency model (current):**
- Phase-level: Setup -> Foundational -> User Stories -> Polish (sequential)
- Within stories: Tests (write first, fail) -> Models -> Services -> Endpoints
- `[P]` marker signals "can run in parallel" -- but NO explicit `depends_on` syntax yet

**Proposed enhancement (Issue #1934):**
Explicit inline dependency syntax:
```
- [ ] T002 Initialize project (depends on T001)
- [ ] T003 Configure linting (depends on T001)
```
Plus execution wave summary:
```
Wave 1: T001 (no deps)
Wave 2: T002, T003 (T001 done -> parallel)
Wave 3: T004, T005, T006 (T002 done -> parallel agents)
```
This is NOT yet merged -- currently only `[P]` marker exists.

### Three Maturity Levels of SDD

From the spec-driven.md philosophy document and external analysis:

**Level 1: Spec-First**
- Spec written for a specific task, used during AI-assisted development.
- After completion, spec may be discarded.
- Good for: greenfield projects, one-off features.
- Spec-kit targets this level primarily.

**Level 2: Spec-Anchored**
- Spec is a living document, maintained throughout feature lifecycle.
- Changes START with the spec; AI regenerates code accordingly.
- Bidirectional feedback: production metrics inform spec evolution.
- Good for: long-lived production systems.
- Spec-kit supports this via `/speckit.analyze` consistency validation.

**Level 3: Spec-as-Source**
- Spec is the ONLY artifact humans edit. Code is transient compiled output.
- "Code serves specifications" -- regeneration capability means changed requirements trigger systematic code updates.
- Only viable when generation tooling is mature and trusted.
- Currently aspirational -- no tool fully supports this yet.

### "Spec as Source of Truth" Pattern in Practice

Key mechanisms:
1. **Abstraction enforcement** -- templates forbid premature implementation details
2. **Hierarchical detail** -- complex info segregates to supporting files
3. **Constitutional gates** -- "Phase -1 gates" requiring justification for complexity exceptions
4. **Test-first ordering** -- specs mandate test creation before implementation
5. **Continuous refinement** -- consistency validation is ongoing, not one-time
6. **Regeneration capability** -- changed requirements -> systematic code updates (not manual rewrites)

### Ecosystem

- 30+ community extensions (docs, code, process, integration, visibility)
- 2 community presets (AIDE Migration, Pirate Speak)
- Hooks system: `hooks.before_tasks`, `hooks.after_tasks` in `extensions.yml`

---

## 2. claude-mem (thedotmack/claude-mem)

**Repo:** https://github.com/thedotmack/claude-mem | **Stars:** ~41,000 | **Created:** 2025-08-31

### What it is

Claude Code plugin that automatically captures everything Claude does during sessions, compresses with AI (Claude agent-sdk), and injects relevant context into future sessions. Persistent memory across sessions.

### Architecture

**6 Hook Scripts (5 lifecycle events):**
1. **Smart Install** (pre-hook) -- validates dependencies, manages caching
2. **SessionStart** -- initializes session, retrieves relevant past context
3. **UserPromptSubmit** -- prepares context before Claude processes user input
4. **PostToolUse** -- captures tool execution observations and metadata
5. **Stop** -- manages session pause/interruption
6. **SessionEnd** -- finalizes session, triggers compression

**Worker Service:**
- Bun-managed HTTP API on port 37777
- Web viewer UI for real-time memory stream visualization
- 10 search endpoints for programmatic access
- REST API: `http://localhost:37777/api/observation/{id}`

**Storage:**
- SQLite database with FTS5 (Full-Text Search 5) for keyword indexing
- Chroma vector database for semantic search
- Hybrid approach: keyword matching + semantic similarity

### The 3-Layer Search Workflow (Token-Efficient)

This is the key design pattern -- progressive disclosure to minimize token waste:

**Layer 1: Index Search** (~50-100 tokens/result)
- `search` MCP tool returns compact results with IDs only
- Rapid filtering without loading full content

**Layer 2: Timeline Context**
- `timeline` MCP tool shows chronological context around specific observations
- What happened before/after moments of interest

**Layer 3: Full Details** (~500-1,000 tokens/result)
- `get_observations` MCP tool fetches complete observation data by ID
- Only used AFTER filtering in layers 1-2

Result: ~10x token savings by filtering before fetching details.

### 4 MCP Tools

1. **search** -- full-text queries with filters by type, date, project
2. **timeline** -- chronological context around observations
3. **get_observations** -- batch retrieval of full details by ID
4. (4th tool not fully documented in sources)

### Context Compression

- PostToolUse hook captures observations
- SessionEnd triggers AI compression via Claude agent-sdk
- Generates semantic summaries that reduce storage while preserving essential knowledge
- Recent optimization: ~53% reduction in compressed context token overhead

### Installation

```
/plugin marketplace add thedotmack/claude-mem
/plugin install claude-mem
```

Settings: `~/.claude-mem/settings.json` (auto-generated). Configurable: AI model, worker port, data directory, log level, context injection granularity.

### Privacy

`<private>` tags exclude sensitive content from storage.

### Requirements

Node.js >= 18, Claude Code (latest with plugin support), Bun, uv, SQLite 3.

### License

AGPL-3.0 (exception for ragtime/ directory: PolyForm Noncommercial 1.0.0).

---

## 3. Everyrow/FutureSearch Pipeline (18 subagents, 6 phases)

**Blog post:** https://futuresearch.ai/blog/claude-code-workflow-engine/ (originally everyrow.io, now redirects)
**Author:** Daniel Hnyk

### What it is

Production marketing pipeline that scans 18 community sources (Reddit, HubSpot, Shopify, etc.), enriches threads, classifies opportunities, generates draft responses, and creates a PR -- every weekday at 08:00 UTC. Uses Claude Code as a workflow engine with up to 18+ parallel subagents.

### The 6-Phase Pipeline

**Phase 1: Scan**
- Python search script produces shards
- 18 scanner subagents (one per source: reddit, hubspot, shopify, etc.)
- N search-scanner subagents (one per shard)
- All run in parallel via `run_in_background: true`

**Phase 2: Enrich**
- Python enrichment fetches full thread content
- WebFetch fallback for failed URLs

**Phase 3: Classify**
- N classifier subagents
- 20-question rubric, scoring 1-5 scale
- Parallel execution

**Phase 4: Propose**
- Product-specific proposer subagents
- Target score 4-5 matches only

**Phase 5: Report**
- Markdown report generation
- Metrics and draft forum responses

**Phase 6: Git**
- Branch creation, commits, push, open PR

### Key Design Pattern: Filesystem Message Bus

When scaling from 4 to 18 agents, the orchestrator's context window exploded with all returned output. The fix:

**Before:** Orchestrator collects agent output directly -> O(n * output_size) context
**After:** Agents write to filesystem, orchestrator reads filenames -> O(n * filename) context

Agents write results as files:
```
data/scans/reddit/2026-02-17-run1.json    # success
data/scans/reddit/2026-02-17-run1.error   # failure
```

Orchestrator polls:
```bash
while [ $ELAPSED -lt $TIMEOUT ]; do
  SUCCESS=$(ls -1 data/scans/*/${TODAY}-run*.json 2>/dev/null | wc -l)
  ERRORS=$(ls -1 data/scans/*/${TODAY}-run*.error 2>/dev/null | wc -l)
  # check if SUCCESS + ERRORS >= expected count
done
```

### Subagent Definitions

Each agent is a markdown file with YAML frontmatter:
```yaml
---
name: scanner
description: Scan a community source for marketing opportunities.
tools: Bash, Read, Write, Glob, Grep
model: sonnet
permissionMode: bypassPermissions
---
```

23 agent definitions total: scanners, classifiers, proposers, graphics generators, dataset finders, SEO analyzers.

### Pipeline Definition

Written as markdown `SKILL.md` with natural language instructions. Document order = dependency graph. No explicit DAG -- "Phase 2 comes after Phase 1 because it's written after Phase 1."

### 4-Layer Timeout Strategy

1. `max_turns` per agent -- hard API round-trip limit
2. 10-minute wall-clock phase cap
3. Bash `timeout 10800` -- 3-hour overall limit
4. Kubernetes `activeDeadlineSeconds` -- 4-hour hard stop

### Core Principle

> "Python does the mechanics, Claude does judgment."

Reusable standardized operations (search, file I/O, HTTP) live in Python libraries. Agents handle reasoning, adaptation, and error recovery. Unlike traditional retry decorators, Claude reads error messages and decides what to do -- conditional fallbacks instead of blind retries.

---

## Summary: Key Patterns for Our Project

| Pattern | Tool | Relevance |
|---------|------|-----------|
| Spec-as-source-of-truth (constitution -> spec -> plan -> tasks) | spec-kit | Could structure our feature development workflow |
| `[P]` parallelization markers + execution waves | spec-kit | Task decomposition for agent teams |
| 3-layer progressive disclosure (index -> timeline -> full) | claude-mem | Token-efficient context management pattern |
| Filesystem message bus (agents write files, orchestrator polls filenames) | Everyrow | Scaling parallel subagents without context explosion |
| YAML frontmatter agent definitions | Everyrow | Standardized subagent spawning |
| 4-layer timeout strategy | Everyrow | Production resilience for long-running pipelines |
| "Python does mechanics, Claude does judgment" | Everyrow | Clean separation of deterministic vs. reasoning work |
