# Phase 2: BatchRunner — план реализации

## Контекст

Phase 1 завершена: в `process_question()` добавлен `skip_files=True`, пропуск merge/charts/excel/pdf, возврат timings. 618 тестов зелёные. Phase 2 создаёт `BatchRunner` — класс для прогона списка вопросов с выводом аналитической таблицы (CSV/Excel) для ручного ревью.

Спецификация: `docs/research/2026-02-27-batch-mode-design.md`

## Затронутые файлы

### Новые файлы
| Файл | Назначение |
|------|-----------|
| `application/batch_runner.py` | BatchRunner class (run, flatten, export) |
| `presentation/batch_cli.py` | CLI entry point (argparse) |
| `run_batch.py` | Thin entry point (корень) |
| `tests/application/test_batch_runner.py` | Unit-тесты BatchRunner |

### Без изменений
Все существующие файлы — Phase 1 уже добавила нужные флаги.

---

## Задачи

### Task 1: Создать `application/batch_runner.py`
**Files:** `application/batch_runner.py`
**Depends on:** none

Класс `BatchRunner`:
```
class BatchRunner:
    def __init__(self, agent: AIAgent)
    def run(self, questions: list[str]) -> pd.DataFrame
    def _process_one(self, question: str, question_number: int) -> dict
    def _flatten_results(self, question: str, question_number: int, result: dict) -> list[dict]
    def _extract_final_answer(self, result: dict) -> str
    def to_csv(self, df: pd.DataFrame, path: str) -> str
    def to_excel(self, df: pd.DataFrame, path: str) -> str
```

Ключевые решения:
- `batch_id` = uuid4().hex[:12] (создаётся в `__init__`)
- `run()`: цикл по вопросам → `_process_one()` → `_flatten_results()` → concat → DataFrame
- Error isolation: `_process_one()` оборачивает `agent.process_question(q, skip_files=True)` в try/except
- Progress: `logger.info("[Batch %d/%d] %s", i, total, question[:80])`
- `_flatten_results()`: row-per-subquestion, дублирует `final_answer` по строкам
- `_extract_final_answer()`: 3 ветки по status (success → final_response, partial → message, error → error)
- Timings → JSON строки: `json.dumps(timings, ensure_ascii=False)`
- `created_at` = ISO timestamp

Колонки DataFrame (из спеки):
`batch_id, question_number, original_question, status, subquestion_number, subquestion, generated_sql, row_count, subquestion_answer, final_answer, top_timings_s, detail_timings_s, error, created_at`

**Done when:** класс создан, импортируется, типизирован

### Task 2: Unit-тесты BatchRunner (TDD — тесты первыми)
**Files:** `tests/application/test_batch_runner.py`
**Depends on:** Task 1 (пишутся параллельно — TDD)

Тесты с мокнутым `AIAgent.process_question`:
1. `test_batch_runner_run_returns_dataframe` — run([q1, q2]) → DataFrame с правильными колонками
2. `test_batch_runner_error_isolation` — один вопрос кидает exception → error строка, второй обработан
3. `test_batch_runner_result_columns` — DataFrame.columns == EXPECTED_COLUMNS
4. `test_flatten_results_success` — status=success, 2 subquestions → 2 rows
5. `test_flatten_results_partial` — status=partial → final_answer из message
6. `test_flatten_results_error` — status=error → final_answer из error
7. `test_extract_final_answer_success` — result с final_response
8. `test_extract_final_answer_partial` — result с message
9. `test_extract_final_answer_error` — result с error
10. `test_to_csv_creates_file` — to_csv() → файл существует, содержимое корректно
11. `test_to_excel_creates_file` — to_excel() → файл существует
12. `test_batch_id_is_unique` — два BatchRunner имеют разные batch_id

Паттерн мокирования:
```python
@patch.object(AIAgent, "process_question")
def test_...(self, mock_pq):
    mock_pq.return_value = {"status": "success", "final_response": "answer", ...}
```

Фикстура `make_agent` из `conftest.py` для создания AIAgent.

**Done when:** все 12 тестов зелёные

### Task 3: Создать `presentation/batch_cli.py`
**Files:** `presentation/batch_cli.py`
**Depends on:** Task 1

Entry point:
```python
def main():
    parser = argparse.ArgumentParser(description="AI Analyst Batch Mode")
    parser.add_argument("--input", required=True, help="Файл с вопросами (.json или .txt)")
    parser.add_argument("--output", default=None, help="Путь для результата (.csv или .xlsx)")
    parser.add_argument("--format", choices=["csv", "xlsx"], default="csv")
    args = parser.parse_args()
```

Логика:
1. Валидация настроек (паттерн из `presentation/cli.py`: проверка oracle_username, api_key, api_url)
2. Чтение вопросов из файла — **два формата**:
   - `.json`: `json.load()` → ожидает `list[str]` (как `dev/вопросы_client_product.json`)
   - `.txt`: строка на строку, strip пустых строк
   - Определение по расширению файла (`.json` → JSON, остальное → txt)
3. Создание AIAgent → BatchRunner
4. `runner.run(questions)` → DataFrame
5. Экспорт в CSV/Excel по `--format` (default: определяется по расширению `--output`, fallback csv)
6. Print summary: N вопросов, N success, N error, путь к файлу

Вынести `load_questions(path: str) -> list[str]` как отдельную функцию для тестируемости.

**Done when:** `python run_batch.py --input dev/вопросы_client_product.json --output results.csv` работает

### Task 4: Создать `run_batch.py` (thin entry point)
**Files:** `run_batch.py`
**Depends on:** Task 3

```python
if __name__ == "__main__":
    from presentation.batch_cli import main
    main()
```

Паттерн: аналогично `run_agent.py`.

**Done when:** файл создан, 3 строки

### Task 5: Прогнать тесты + devlog
**Files:** `devlog/changelog.json`
**Depends on:** Tasks 1-4

1. `pytest tests/ -v` → все тесты зелёные (618 + ~12 новых)
2. Добавить запись в devlog (id: "051" для Phase 1, "052" для Phase 2)

**Done when:** 0 failures, devlog обновлён

---

## Анализ воздействия

| Модуль | Изменение | Риск | Влияние |
|--------|-----------|------|---------|
| application/batch_runner.py | NEW | Нет — изолированный модуль | Зависит от agent.py |
| presentation/batch_cli.py | NEW | Нет | Зависит от batch_runner, settings |
| run_batch.py | NEW | Нет | Thin wrapper |
| Существующие файлы | БЕЗ ИЗМЕНЕНИЙ | Нет | — |

---

## Риски

| Сценарий | Вероятность | Воздействие | Митигация |
|----------|-------------|-------------|-----------|
| Некорректный формат result dict | Низкая | Средний | Тесты покрывают все 3 ветки status |
| Memory leak на 100+ вопросах | Низкая | Средний | Результаты в list[dict], concat один раз в конце |
| Batch зависает на одном вопросе | Средняя | Средний | try/except per question + logging progress |
| Опечатка в колонках DataFrame | Низкая | Низкий | Тест `test_result_columns` проверяет точный набор |

## Верификация

1. `pytest tests/application/test_batch_runner.py -v` → все тесты зелёные
2. `pytest tests/ -v` → 0 регрессий
3. (Опционально) smoke-test с реальными вопросами: `python run_batch.py --input dev/вопросы_client_product.json --output /tmp/batch_test.csv`

## Масштаб

- 4 новых файла, 0 модификаций существующих
- ~12 новых тестов
- ~120 LOC batch_runner.py, ~60 LOC batch_cli.py, ~3 LOC run_batch.py
- Рекомендация: последовательное выполнение (TDD: тесты → код → верификация)
