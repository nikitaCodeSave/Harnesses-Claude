# План: Миграция dev-инфраструктуры all_cli → client_product

## Context

Приложение уже мигрировано на таблицу `client_product` (ADR-014, коммит 6842450). Dev-инфраструктура (Oracle DDL, seed-генератор, тест-скрипты, skill) всё ещё использует старую таблицу `all_cli` (93 колонки). Нужно привести dev-окружение в соответствие с prod-схемой (35 колонок).

Базовые данные: `docs/research/2026-02-25-dev-infrastructure-migration.md`, `dev/peek_table.md`.

---

## Фаза 0 пропущена

Задача не меняет поведение runtime-кода. Миграция затрагивает только dev-инфраструктуру и описательные типы в metadata.py.

---

## Задачи

### Task 0: Обновить типы в metadata.py

**Файл:** `infrastructure/metadata.py`
**Объём:** 5 точечных правок
**Блокирует:** Tasks 1-7

| Поле | Было | Стало |
|------|------|-------|
| CUSTOMER_ID | `VARCHAR2(50)` | `NUMBER` |
| INN | `VARCHAR2(20)` | `NUMBER` |
| GROUP_NM | `VARCHAR2(500)` | `VARCHAR2(100)` |
| HUB | `VARCHAR2(20)` | `VARCHAR2(100)` |
| MANAGER_NAME | `VARCHAR2(200)` | `VARCHAR2(100)` |

**Риск:** low. Типы используются только в промптах как справочная информация. 6 зависимых модулей (relevance_checker, sql_generator, sql_validator, response_generator, chart_generator, agent) не парсят типы программно.

**Done when:** `pytest tests/ -v` — все 610 тестов проходят.

---

### Task 1: Переписать setup-oracle.sql

**Файл:** `dev/setup-oracle.sql` (293 строк → ~100)
**Зависит от:** Task 0

Что делать:
- CREATE TABLE `client_product` (35 колонок по `dev/peek_table.md`)
- Типы: все NUMBER без precision (как в prod), VARCHAR2 с реальными длинами
- 6 INSERT: 3 клиента × 2 месяца (ноябрь + декабрь 2024)
- Формат данных по prod: CUSTOMER_ID=12-значные числа, INN=10-значные, MONTH_DT=последний день месяца, SEG=английские значения, MANAGER_NAME=UPPERCASE кириллица
- Покрыть сегменты: Large, Middle, International
- Покрыть HUB: Москва + один региональный
- CLOSE_DT=NULL для всех, SALARY_PROJECT=NULL, ACT_1M/ACT_3M — разные значения

**Done when:** SQL синтаксически валиден (проверка глазами по структуре `peek_table.md`).

---

### Task 2: Обновить start-dev.sh

**Файл:** `dev/start-dev.sh`
**Зависит от:** Task 1
**Объём:** 3 строки

Замены:
- `table_name='ALL_CLI'` → `table_name='CLIENT_PRODUCT'`
- `all_cli` → `client_product` в комментариях

**Done when:** grep -i "all_cli" dev/start-dev.sh — пусто.

---

### Task 3: Переписать generate_seed.py

**Файл:** `dev/generate_seed.py` (1010 строк → ~600-700)
**Зависит от:** Tasks 0, 1

Ключевые изменения:
- INSERT INTO `client_product` (35 колонок вместо 93)
- CUSTOMER_ID → 12-значные числа (NUMBER), не строки 'CLI001'
- INN → 10-значные числа (NUMBER)
- MONTH_DT → последний день месяца (не 15-е число)
- SEGMENT → SEG, русские значения → английские (International, Middle, Large, SME, FI, Region)
- Добавить HUB (6 хабов из prod)
- MANAGER_NAME → UPPERCASE кириллица
- Убрать ~60 удалённых колонок и всю связанную логику: ID_I, INN_I, WEEK, MONTH, RN_DAY, UPDATE_TIME, DESK_ID, MANAGER_NM, CURRENCY_CD, CA_CCY_SUM, CNT_BAL, DEP_TERM, DEP_RATE, LOAN_SUM, FACTORING_SUM, GAR_SUM, GOSGAR_SUM, GOSCONT_SUM, FX_BUCKET, FX_*_VOLUME_USD/EUR, FX_*_SPREAD, OBOROT, CUR_*/RUB_*, CNT_CHECK, OBOROT_FX_*, PL_RKO, PL_TRANSIT, PL_CA_KOMIS, PL_VED_RUB, PL_VED_FX, PL_FX_FIX, VED_IN/OUT_* по валютам, все CNT_* операций
- Добавить: HUB, CLOSE_DT, SALARY_PROJECT, PREV_ACT_1M, PREV_ACT_3M, ACT_1M, ACT_3M
- Упрощение: VED_SUM и VED_VOL вместо детализации
- Переработка query_db_state() — CUSTOMER_ID теперь NUMBER, не строка
- Переработка SEGMENT_TARGETS, NAME_POOLS, DESK_OPTIONS, SCALE_RANGES под новую схему

**Done when:** `python dev/generate_seed.py --dry-run` выполняется без ошибок, `python dev/generate_seed.py --status` выводит корректную структуру.

---

### Task 4: Обновить test-connection.py

**Файл:** `dev/test-connection.py`
**Зависит от:** Task 1
**Объём:** 1-2 строки

Строка 73: `RUN_DATE, ORGANIZATION_NM, SEGMENT, PNL_SUM` → `MONTH_DT, ORGANIZATION_NM, SEG, PNL_SUM`

Остальное уже использует `ALL_CLI_METADATA["table_name"]` и `ALL_CLI_METADATA["fields"]` — корректно.

**Done when:** `python -c "from dev import test_connection"` — нет import-ошибок (live-тест — при наличии Oracle).

---

### Task 5: Обновить test_integration_connection.py

**Файл:** `tests/test_integration_connection.py`
**Зависит от:** Task 1
**Объём:** 1 строка

Строка 47: `RUN_DATE` → `MONTH_DT` в test_sample_data_query.

**Done when:** `pytest tests/test_integration_connection.py --collect-only` — все тесты собираются.

---

### Task 6: Переписать seed-data.md

**Файл:** `.claude/commands/seed-data.md` (524 строки → ~400)
**Зависит от:** Tasks 0-3

Полная перезапись:
- `all_cli` → `client_product` повсюду
- 93 колонки → 35 колонок в SQL-шаблонах
- Сегменты: русские → английские
- CUSTOMER_ID: строки → числа
- MONTH_DT вместо RUN_DATE (последний день месяца)
- HUB и новые колонки в справочниках
- Убрать composition rules для удалённых полей (CA_LCY = CA_LCY_RUB + CA_CCY, etc.)
- Добавить новые проверки (PNL_SUM = PL_CA + PL_DEP + PL_VK + PL_VK_OUT + VED_SUM + FX_MARGIN_RUB + ...)

**Done when:** grep -i "all_cli" .claude/commands/seed-data.md — пусто.

---

### Task 7: Обновить тесты generate_seed

**Файл:** `tests/dev/test_generate_seed_regressions.py`
**Зависит от:** Task 3

Полная перезапись тестов под новую структуру generate_seed.py:
- Новые MONTHS (последний день месяца)
- Убрать TestDepTerm* (DEP_TERM удалена из схемы)
- Убрать TestCurrencyCode (CURRENCY_CD удалена)
- Обновить TestVedCounters под новую структуру (VED_VOL, VED_SUM вместо детализации)
- Добавить тесты: CUSTOMER_ID — числовой, SEG — английские значения, MONTH_DT — последний день месяца

**Done when:** `pytest tests/dev/ -v` — все тесты проходят.

---

### Task 8: Верификация + devlog

**Зависит от:** Tasks 0-7

1. `pytest tests/ -v` — все unit-тесты
2. `grep -ri "all_cli" dev/ .claude/commands/seed-data.md tests/test_integration_connection.py` — нет остатков
3. Devlog: запись в `devlog/changelog.json`

**Done when:** Все тесты зелёные, нет ссылок на `all_cli` в затронутых файлах.

---

## Порядок выполнения

```
Task 0 (metadata.py)
  ↓
Task 1 (setup-oracle.sql)
  ↓
  ├── Task 2 (start-dev.sh)      ─── параллельно
  ├── Task 4 (test-connection.py) ─── параллельно
  └── Task 5 (integration test)   ─── параллельно
  ↓
Task 3 (generate_seed.py)
  ↓
  ├── Task 6 (seed-data.md)       ─── параллельно
  └── Task 7 (seed tests)         ─── параллельно
  ↓
Task 8 (верификация + devlog)
```

## Параллелизм

Tasks 2, 4, 5 — минимальные, можно выполнить в один шаг.
Tasks 6, 7 — независимы, но обе зависят от Task 3.

**Рекомендация:** Последовательное выполнение одним агентом. Tasks 1, 3, 6 — основная работа (полные перезаписи). Tasks 0, 2, 4, 5 — быстрые точечные правки.

## Риски

| Сценарий | Вероятность | Воздействие | Действие |
|----------|-------------|-------------|----------|
| Типы metadata.py ломают промпты | low | 6 модулей | Откат: git checkout infrastructure/metadata.py |
| setup-oracle.sql синтаксически невалиден | medium | dev-окружение | Проверка через Oracle container после реализации |
| generate_seed.py не запускается | medium | seed workflow | --dry-run как smoke test |
| Пропущена ссылка на all_cli | low | inconsistency | grep -ri "all_cli" по всему проекту |

## Оценка масштаба

- **Файлов:** 8 (3 полные перезаписи, 5 точечных правок)
- **Тестов:** 1 файл перезапись + проверка 610 существующих
- **Основная работа:** Tasks 1, 3, 6 (DDL, seed-генератор, skill)
