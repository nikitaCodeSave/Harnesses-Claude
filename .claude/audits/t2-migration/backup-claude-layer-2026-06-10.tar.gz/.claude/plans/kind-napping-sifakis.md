# Spec: типизированные исключения, тесты timeout и thread safety

## Context

Три точечных issue в infrastructure-слое:
1. `get_client()` (llm_client.py:161) бросает bare `Exception` — вызывающий код (`call_llm`) ловит generic `Exception` и оборачивает в `LLMCallError`, но прямые вызовы `get_client()` (dev/debug_llm_response.py) получают нетипизированное исключение
2. `query_timeout_ms` (db_connector.py:137-139) — новая фича без unit-тестов
3. `threading.Lock()` в `LLMClient` (llm_client.py:128-134, 145-147) — thread safety без теста на race condition

> Фаза 0 пропущена: задачи 1 — замена типа исключения (не меняет поведение call_llm), задачи 2-3 — добавление тестов.

## Анализ воздействия

| Модуль | Изменение | Риск | Зависимые |
|--------|-----------|------|-----------|
| infrastructure/llm_client.py | `get_client()`: `Exception` → `LLMCallError` | low | call_llm (ловит Exception → без изменений), dev/debug_llm_response.py (улучшение) |
| tests/infrastructure/test_llm_client.py | +тесты get_client, thread safety | none | — |
| tests/infrastructure/test_db_connector.py | +тесты query_timeout_ms | none | — |

Ломающие изменения: **нет**. `LLMCallError` — подкласс `Exception`, существующие `except Exception` продолжают работать.

## План реализации

### Task 1: get_client() → LLMCallError (llm_client.py:161)
- Files: `infrastructure/llm_client.py`
- Depends on: none
- Изменение: строка 161, `raise Exception(...)` → `raise LLMCallError(..., operation="init")`
- Done when: `LLMClient.get_client()` бросает `LLMCallError` при неинициализированном клиенте

### Task 2: тесты get_client + thread safety (test_llm_client.py)
- Files: `tests/infrastructure/test_llm_client.py`
- Depends on: Task 1
- Тесты:
  - `test_get_client_not_initialized_raises_llm_call_error` — без initialize, get_client бросает LLMCallError
  - `test_get_client_returns_client_after_initialize` — после initialize возвращает OpenAI
  - `test_singleton_thread_safety` — 10 потоков создают LLMClient(), все получают один instance
- Подход: mock truststore/httpx/OpenAI для initialize, `threading.Thread` для race condition
- Done when: `pytest tests/infrastructure/test_llm_client.py -v` — все тесты проходят

### Task 3: тесты query_timeout_ms (новый файл или дополнение)
- Files: `tests/infrastructure/test_db_connector.py` (новый)
- Depends on: none
- Тесты:
  - `test_execute_query_sets_call_timeout_when_positive` — mock connection, проверить что call_timeout установлен
  - `test_execute_query_skips_timeout_when_zero` — query_timeout_ms=0, call_timeout не устанавливается
  - `test_execute_query_skips_timeout_when_no_connection` — connection=None после connect fail
- Подход: mock `oracledb.connect`, mock `pd.read_sql`, mock `get_settings()` для query_timeout_ms
- Done when: `pytest tests/infrastructure/test_db_connector.py -v` — все тесты проходят

### Task 4: верификация + devlog
- Depends on: Tasks 1-3
- `pytest tests/ -v` — все unit-тесты проходят
- Запись в devlog/changelog.json

## Риски

| Сценарий | Вероятность | Действие |
|----------|-------------|----------|
| Существующий код ловит bare Exception от get_client | low | LLMCallError наследует Exception — совместимость сохранена |
| Thread safety тест flaky | medium | Использовать barrier для синхронного старта потоков, проверять identity (is), не equality |

## Масштаб
- 1 файл изменён (llm_client.py, 1 строка)
- 2 тестовых файла (test_llm_client.py дополнен, test_db_connector.py создан)
- ~60-80 строк тестового кода
- Выполнение: последовательное (Tasks 1→2, Task 3 параллельно)
