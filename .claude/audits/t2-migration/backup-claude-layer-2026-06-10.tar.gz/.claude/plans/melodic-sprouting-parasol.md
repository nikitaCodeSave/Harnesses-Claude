# Spec: Детерминированный fix alias mismatch в validator.py

## Контекст

LLM (Qwen3-30B) генерирует two-step SQL для balance-полей (CA_LCY_SUM, DEP_SUM и др.) с подзапросами. В Run 4 обнаружена ошибка: внешний SELECT ссылается на оригинальные имена колонок (`PNL_SUM`) вместо alias-ов подзапроса (`daily_pnl_sum`). Это вызывает ORA-00904, а LLM-fix (sql_fix) не может это починить за 4 попытки — он не понимает семантику alias-ов.

Решение: новая детерминированная функция `validate_subquery_alias_mismatch()` по аналогии с существующей `validate_like_constraints()` (validator.py:382). Парсит SQL, находит alias mapping в подзапросах, заменяет некорректные ссылки.

Источник: `docs/thinking/2026-03-27-sql-generation-quality-verified-queries.md`

---

## Файлы

| Файл | Действие |
|------|----------|
| `core/sql/validator.py` | Добавить функцию + 3 хелпера + интеграция в validate_and_fix_sql |
| `tests/core/sql/test_validator.py` | Добавить класс TestValidateSubqueryAliasMismatch (12 тестов) |
| `devlog/changelog.json` | Запись о новой детерминированной валидации |

---

## Задачи

### Task 1: Тесты (TDD RED)
**Files:** `tests/core/sql/test_validator.py`
**Depends on:** none

Добавить класс `TestValidateSubqueryAliasMismatch` с 12 тестами:

1. `test_no_subquery_returns_unchanged` — простой SQL без подзапросов, modified=False
2. `test_alias_matches_base_col_no_change` — inner AS PNL_SUM (alias = base), modified=False
3. `test_basic_mismatch_fixed` — каноничный баг из Run 4: SUM(PNL_SUM) в outer → SUM(daily_pnl_sum)
4. `test_table_qualified_reference_fixed` — t.PNL_SUM → t.daily_pnl_sum
5. `test_passthrough_column_not_touched` — MONTH_DT, INN в outer GROUP BY не трогаются
6. `test_multiple_mismatches_fixed` — 3 поля с alias, 2 из них broken в outer
7. `test_no_alias_in_inner_no_change` — SUM(CA_LCY_SUM) без AS, modified=False
8. `test_string_literal_not_affected` — 'PNL_SUM' в строковом литерале не заменяется
9. `test_left_join_two_subqueries` — две подзапроса в LEFT JOIN, оба корректны
10. `test_order_by_and_having_fixed` — ссылки в ORDER BY и HAVING тоже исправляются
11. `test_already_correct_aliases_no_change` — outer уже использует alias, modified=False
12. `test_integration_validate_and_fix_sql` — вызов validate_and_fix_sql с alias mismatch SQL + db_executor=None → fix применён

**Done when:** все 12 тестов написаны и FAIL (RED) с ImportError или AssertionError

---

### Task 2: Реализация функции (TDD GREEN)
**Files:** `core/sql/validator.py`
**Depends on:** Task 1

Добавить в validator.py:

**Regex (рядом с _NESTED_AGG_RE, ~строка 197):**
```python
_INNER_ALIAS_RE = re.compile(
    r"""\b(?:SUM|AVG|COUNT|MAX|MIN)\s*\(\s*(?:DISTINCT\s+)?(\w+)\s*\)\s+AS\s+(\w+)""",
    re.IGNORECASE,
)
```

**Хелперы:**
- `_find_matching_paren(sql, open_pos) -> int` — поиск закрывающей скобки
- `_extract_subquery_alias_map(inner_sql) -> dict[str, str]` — маппинг {BASE_COL_UPPER: alias}
- `_replace_column_refs(text, base_col_upper, alias, subquery_alias) -> str` — замена ссылок в outer-тексте

**Основная функция:**
```python
def validate_subquery_alias_mismatch(sql: str) -> tuple[str, bool]:
```

Алгоритм:
1. `_mask_string_literals(sql)` + `_compute_effective_depth(masked)`
2. Найти `FROM\s*\(` на depth=0
3. Для каждого — `_find_matching_paren()` → извлечь inner SQL
4. `_extract_subquery_alias_map(inner_sql)` → dict {BASE_COL: alias}
5. Определить subquery table alias (regex после `)`)
6. Разбить SQL на outer_before + subquery_block + outer_after
7. Заменить base_col → alias в outer_before и outer_after
8. Собрать обратно, вернуть (new_sql, was_modified)

**Интеграция в validate_and_fix_sql() (строка ~819):**
```python
# После validate_like_constraints, до _run_db_validation:
sql, alias_modified = validate_subquery_alias_mismatch(sql)
if alias_modified:
    logger.info("Исправлены ссылки на колонки подзапроса (alias mismatch)")
```

**Done when:** все 12 тестов из Task 1 проходят (GREEN)

---

### Task 3: Верификация + devlog
**Files:** devlog/changelog.json
**Depends on:** Task 2

1. `pytest tests/core/sql/test_validator.py -v` — все тесты проходят
2. `pytest tests/ -v` — нет регрессий в остальных тестах
3. `ruff check core/sql/validator.py` — линтер чист
4. Добавить запись в devlog/changelog.json

**Done when:** все тесты зелёные, линтер чист, devlog обновлён

---

## Риски

| Сценарий | Вероятность | Воздействие | Митигация |
|----------|-------------|-------------|-----------|
| False positive: замена колонки в scalar subquery внутри outer SELECT | Low | Medium | Замена только в outer_before/outer_after текстовых сегментах, не внутри подзапросов |
| Замена внутри строкового литерала | Low | Low | regex `\b` не матчит внутри кавычек в большинстве случаев; для полной защиты можно маскировать outer-сегменты |
| Несколько подзапросов с пересекающимися alias-ами | Low | Medium | Обработка каждого подзапроса независимо, итерация в обратном порядке позиций |
| CTE (WITH ... AS) | Low | Low | CTE не использует FROM (...) t паттерн — фильтруется автоматически |

**Откат:** `git checkout -- core/sql/validator.py tests/core/sql/test_validator.py`

---

## Переиспользуемые компоненты

Из validator.py (уже существуют):
- `_compute_effective_depth()` (строка 85) — глубина вложенности
- `_mask_string_literals()` (строка 180) — маскировка строк
- `_extract_outer_select_clause()` (строка 307) — outer SELECT
- `_extract_outer_group_by_clause()` (строка 250) — outer GROUP BY

---

## Верификация

1. Unit: `pytest tests/core/sql/test_validator.py::TestValidateSubqueryAliasMismatch -v`
2. Full suite: `pytest tests/ -v`
3. Lint: `ruff check core/sql/validator.py`
4. (Опционально) Live: `python run_agent.py` → вопрос "суммарный объём остатков за 2024 год"
