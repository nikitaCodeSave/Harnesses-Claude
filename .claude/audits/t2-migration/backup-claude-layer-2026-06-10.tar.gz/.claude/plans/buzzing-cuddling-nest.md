# Edge-case audit: validate_like_constraints

## Контекст

`validate_like_constraints` — детерминированная валидация LIKE-полей в SQL. Анализ выявил баг: посимвольный `.match(i)` в `_extract_like_fields` создаёт перекрывающиеся матчи, из-за чего `NOT LIKE` захватывает `NOT`, `OT`, `T` как имена полей. Плюс ~7 непокрытых edge cases.

## Баг: NOT LIKE → артефакты NOT/OT/T в SELECT/GROUP BY

**Файл:** `core/sql/validator.py:37-54`

**Корень проблемы:** Посимвольный scan с `_LIKE_PATTERN.match(sql_clean, i)` пробует матч на КАЖДОЙ позиции строки. Для `NOT LIKE`:
- Позиция `N`: `(\w+)` = `NOT`, `\s+LIKE\s` → матч, field = `NOT`
- Позиция `O`: `(\w+)` = `OT`, `\s+LIKE\s` → матч, field = `OT`
- Позиция `T`: `(\w+)` = `T`, `\s+LIKE\s` → матч, field = `T`

Фильтрация SQL-keywords не спасает от `OT` и `T`.

### Фикс: переход на re.finditer

**1. Обновить `_LIKE_PATTERN`** — добавить `\b` (word boundary) и `(?P<negated>NOT\s+)?`:

```python
_LIKE_PATTERN = re.compile(
    r"""\b(?:(?:UPPER|LOWER)\s*\(\s*(\w+)\s*\)|(\w+))\s+(?P<negated>NOT\s+)?LIKE\s""",
    re.IGNORECASE,
)
```

Теперь regex матчит всю цепочку `FIELD NOT LIKE` или `UPPER(FIELD) NOT LIKE` от начала поля. `\b` гарантирует что матч начинается на границе слова (не с середины `NOT`). `(?P<negated>NOT\s+)?` захватывает NOT если он есть.

Проверка:
- `GROUP_NM NOT LIKE` → матч с позиции G, group(2)=GROUP_NM, negated="NOT " → skip
- `GROUP_NM LIKE` → матч с позиции G, group(2)=GROUP_NM, negated=None → detect
- `UPPER(X) NOT LIKE` → матч с позиции U, group(1)=X, negated="NOT " → skip

**2. Переписать `_extract_like_fields`** — `re.finditer` вместо посимвольного `.match(i)`:

```python
def _extract_like_fields(sql_clean: str) -> list[str]:
    """Извлекает уникальные имена полей из LIKE-условий на глубине скобок = 0."""
    # Предвычислить depth для каждой позиции
    depths: list[int] = []
    depth = 0
    for ch in sql_clean:
        if ch == "(":
            depth += 1
        elif ch == ")":
            depth -= 1
        depths.append(depth)

    seen: set[str] = set()
    result: list[str] = []
    for m in _LIKE_PATTERN.finditer(sql_clean):
        if m.group("negated"):
            continue  # NOT LIKE — пропустить
        if depths[m.start()] != 0:
            continue  # Внутри скобок — пропустить
        field = (m.group(1) or m.group(2)).upper()
        if field not in seen:
            seen.add(field)
            result.append(field)
    return result
```

`finditer` — неперекрывающийся проход, после матча `GROUP_NM NOT LIKE ` курсор сдвигается за конец матча → `NOT`, `OT`, `T` не рассматриваются как отдельные кандидаты.

**Комментарий к depth-массиву:** `depths[i]` = глубина ПОСЛЕ обработки символа `sql_clean[i]`. Для `(` depth уже инкрементирован → `depths[pos_of_open_paren] = parent_depth + 1`. Это значит что `depths[m.start()] == 0` проверяет что матч начинается вне любых скобок (включая текущую открывающую).

**Сложность:** O(n) для depth-массива + O(k) для finditer (k = количество LIKE).

### Ограничение (документируем, не чиним)

LIKE в скобках `WHERE (UPPER(X) LIKE ...)` — depth=1 на позиции `U`, пропускается. Это by design: depth-tracking не различает "группировочные скобки WHERE" и "скобки подзапроса". LLM-генерируемый SQL проекта не оборачивает одиночные LIKE-условия в скобки (паттерн из system.txt). Добавить тест документирующий поведение.

## План реализации (TDD)

### Task 1: Baseline — зафиксировать текущее состояние
```bash
.venv/bin/pytest tests/core/sql/test_validator.py -v  # все 46 тестов GREEN
```

### Task 2: Написать edge-case тесты (RED фаза)
**Файл:** `tests/core/sql/test_validator.py`, класс `TestValidateLikeConstraints`

| # | Тест | SQL-паттерн | Ожидание | RED на текущем коде? |
|---|------|-------------|----------|---------------------|
| 1 | `test_not_like_upper_ignored` | `UPPER(GROUP_NM) NOT LIKE '%test%'` | modified=False, SELECT/GROUP BY без артефактов NOT/OT/T | YES — баг |
| 2 | `test_not_like_plain_field_ignored` | `GROUP_NM NOT LIKE '%test%'` | modified=False, нет артефактов | YES — баг |
| 3 | `test_like_and_not_like_mixed` | `UPPER(X) LIKE ... AND UPPER(Y) NOT LIKE ...` | Только X добавлен; Y, NOT, OT, T отсутствуют в SELECT | YES — баг |
| 4 | `test_lower_function_handled` | `LOWER(GROUP_NM) LIKE '%test%'` с агрегатом | GROUP_NM в SELECT и GROUP BY | NO — уже работает |
| 5 | `test_duplicate_like_same_field` | `UPPER(GROUP_NM) LIKE '%a%' AND UPPER(GROUP_NM) LIKE '%b%'` | GROUP_NM добавлен один раз | NO — dedup работает |
| 6 | `test_like_in_parenthesized_where_skipped` | `WHERE (UPPER(GROUP_NM) LIKE '%test%')` | modified=False — документирует ограничение | NO — текущее поведение |
| 7 | `test_like_inside_sum_case_ignored` | `SELECT SUM(CASE WHEN X LIKE '%t%' THEN 1 ELSE 0 END) FROM t` | modified=False (LIKE внутри SUM() на depth>0) | NO |
| 8 | `test_cte_outer_like_detected` | `WITH cte AS (...) SELECT SUM(PNL_SUM) FROM cte WHERE UPPER(GROUP_NM) LIKE ...` | modified=True, GROUP_NM добавлен | NO — depth=0 после CTE |
| 9 | `test_sql_without_like_keyword_unchanged` | `SELECT SUM(PNL_SUM) FROM client_product GROUP BY MONTH_DT` | modified=False | NO — trivial |

Тесты #1-3 проверяют артефакты через `_extract_like_fields` напрямую (точнее чем строковый поиск в SELECT):
```python
sql_clean = _strip_string_literals(sql, " ")
fields = _extract_like_fields(sql_clean)
assert fields == []  # или == ["GROUP_NM"] для теста #3
# Ни NOT, ни OT, ни T не должны появиться в списке полей
```

### Task 3: Реализовать фикс (GREEN фаза)
**Файл:** `core/sql/validator.py`
1. Обновить `_LIKE_PATTERN` — добавить `\b` и `(?P<negated>NOT\s+)?`
2. Переписать `_extract_like_fields` на `finditer` + precomputed depths
3. Прогнать тесты → все GREEN

### Task 4: Регрессионная проверка
```bash
.venv/bin/pytest tests/core/sql/test_validator.py -v  # validator тесты GREEN
.venv/bin/pytest tests/ -v  # все unit-тесты GREEN
```

### Task 5: Обновить devlog
**Файл:** `devlog/changelog.json`

## Оценка
- Файлы: 2 (validator.py, test_validator.py) + devlog
- Новые тесты: 9
- Изменения кода: ~20 строк (_LIKE_PATTERN + _extract_like_fields)
- Риск: низкий — `finditer` + depth-массив полностью заменяют посимвольный scan, тесты покрывают все ветки
