# Анализ: дубль сообщений и WinError 233 на Windows

## Context

На Windows (production) три симптома:
1. **Первое сообщение дублируется** — бот отправляет "✅ Ваш вопрос принят" дважды
2. **WinError 233** (`OSError: С обоих концов канала отсутствуют процессы`) — crash в `emit()`
3. **Файлы не отправляются** — `io.BytesIO object has no attribute 'name'`

Traceback из production — от **старой** версии кода (line numbers не совпадают с текущими).

## Корневые причины и статус фиксов

### 1. Дубль сообщений — ИСПРАВЛЕНО (dual client)

**Причина:** SDK `do_api_query()` при `retry_on_errors=True` (дефолт) ретраит запрос до 10 раз при `ConnectionError`. POST `/messages` не идемпотентен → retry создаёт дубликат.

**Фикс:** Два клиента в `__init__`:
- `_event_client` (`retry_on_errors=True`) — для `call_on_each_message` (event loop, стабильность)
- `client` (`retry_on_errors=False`) — для `send_message`, `update_message`, `upload_file`

**Подтверждение из SDK (строка 594-675):** При `retry_on_errors=False`, `error_retry()` возвращает `False` → SDK не ретраит, а re-raises `ConnectionError` → наш `except OSError` ловит → без дубликатов.

### 2. WinError 233 в emit — ИСПРАВЛЕНО (make_progress_emit wrapper)

**Причина в старом коде:** `_emit` была прямым методом без try/except. OSError из `send_message`/`update_message` мог пробиться через `emit()` → `_emit()` → crash `process_question`.

**Текущий код уже защищён 3 уровнями:**
1. `_sync()` (строка 86-106) — `except Exception: logger.error(..., exc_info=True)`
2. `emit()` вызывает только `_sync()` — все сетевые вызовы внутри try/except
3. `make_progress_emit._event_emit()` (infrastructure/progress.py:69-72) — wraps callback в `try/except Exception`

Даже если `emit()` бросит исключение, `_event_emit` подавит его. Пайплайн не упадёт.

### 3. BytesIO не имеет .name — ИСПРАВЛЕНО (open() вместо BytesIO)

**Причина:** SDK `do_api_query` строка 583: `req_files = [(f.name, f) for f in files]`. `io.BytesIO` не имеет `.name`.

**Фикс:** `_upload_file_with_retry` передаёт `open(file_path, "rb")` напрямую. `FileNotFoundError`/`PermissionError`/`IsADirectoryError` пропускаются без retry.

## Уже внесённые изменения

### `presentation/zulip_bot.py`
- `import io` удалён
- `__init__`: `_event_client` (с retry) + `client` (без retry, `has_connected=True`)
- `_recreate_client()`: пересоздаёт только send-клиент с `retry_on_errors=False`
- `run()`: `_event_client.call_on_each_message`
- `_upload_file_with_retry`: `open()` вместо `io.BytesIO`, фильтрация файловых OSError

### `tests/presentation/test_zulip_logger.py`
- Обновлён `test_recreate_client_uses_original_credentials` (проверяет `retry_on_errors=False`)
- Добавлен `TestDualClient` (5 тестов):
  - `test_client_created_with_retry_disabled`
  - `test_event_client_created_with_retry_enabled`
  - `test_run_uses_event_client`
  - `test_recreate_client_sets_has_connected`
  - `test_upload_file_not_found_not_retried`

## Дополнительные изменения — НЕ ТРЕБУЮТСЯ

Анализ SDK показал:
- Event loop (`call_on_each_event`, строки 718-808) имеет свой retry для `get_events` и `do_register` — работает стабильно с `retry_on_errors=True`
- `has_connected = True` безопасен (SDK использует его только для skip "trying to connect" message, строка 663-670)
- `requests.exceptions.ConnectionError` наследует `IOError` (= `OSError`) → наши `except OSError` ловят все сетевые ошибки SDK

## Verification

1. `pytest tests/presentation/test_zulip_logger.py -v` — **71 passed** ✅
2. `pytest tests/ -v` — **1038 passed** ✅
3. Деплой на Windows → проверить:
   - Файлы отправляются (no `AttributeError: 'BytesIO' has no attribute 'name'`)
   - Первое сообщение НЕ дублируется
   - WinError 233 не крашит пайплайн (подавляется в `_event_emit`)
