# Fix: галлюцинация при провале всех подвопросов + ложный success

## Context

Два подтверждённых бага в `application/reports.py`:

1. **Галлюцинация**: когда все подвопросы провалились (`final_df is None`, `successful_results == 0`), вызывается `generate_final_response()` — LLM получает вопрос + тексты ошибок ("Не удалось сгенерировать SQL") и выдумывает числа. Воспроизводится во всех 3 точках входа.

2. **Ложный success**: `reports.py:367` безусловно возвращает `status: "success"` — даже при 0 успешных подвопросах. Zulip бот отправляет "Обработка завершена успешно!", batch runner пишет `status: success`.

## Затронутые файлы

| Файл | Изменение |
|------|-----------|
| `application/reports.py` | Основной fix: early return при 0 успешных + status logic |
| `tests/application/test_reports.py` | Новые тесты: all-fail scenario, partial success |

## Анализ воздействия

| Модуль | Риск | Влияние |
|--------|------|---------|
| `application/reports.py` | low | Изменяется только ветка `successful_results == 0` |
| `presentation/zulip_bot.py` | none | Уже обрабатывает non-success в else-ветке (строка 446-450) |
| `presentation/batch_cli.py` | none | batch_runner._extract_final_answer: non-success/partial → читает `error` |
| `application/agent.py` | none | Передаёт status в _track_request as-is |

## План реализации

### Task 1: Тесты (TDD — RED)
**Files:** `tests/application/test_reports.py`
**Depends on:** none
**Что:**
- `test_generate_reports_all_subquestions_failed_returns_no_data_status` — subquestion_results с df=None, answer="ошибка" → status != "success", no LLM call
- `test_generate_reports_all_subquestions_failed_no_llm_call` — verify `generate_final_response` NOT called
- `test_generate_reports_all_subquestions_failed_deterministic_message` — final_response содержит текст ошибок подвопросов
- `test_generate_reports_partial_success_still_calls_llm` — 1 ok + 1 fail → existing behavior preserved
- `test_generate_reports_empty_df_counts_as_success` — df=empty DataFrame (0 строк, SQL отработал) → status="success", LLM вызывается. Пустой результат — валидный ответ ("0 сделок"), не ошибка.
**Done when:** 4+ тестов FAIL (red phase)

### Task 2: Fix reports.py (TDD — GREEN)
**Files:** `application/reports.py`
**Depends on:** Task 1
**Что:**

**Bug 1 fix** (строка ~298, перед `if final_df is not None`):
```python
if successful_results == 0:
    # Все подвопросы провалились — детерминированный ответ, без LLM
    error_lines = []
    for i, r in enumerate(subquestion_results, 1):
        subq = r.get("question", f"Подвопрос {i}")
        ans = r.get("answer", "ошибка")
        error_lines.append(f"  {i}. {subq}: {ans}")
    final_response = (
        "Не удалось получить данные ни по одному подвопросу:\n"
        + "\n".join(error_lines)
    )
```

**Bug 2 fix** (строка ~367):
```python
status = "success" if successful_results > 0 else "no_data"
return {
    "status": status,
    "message": document_text,
    "final_response": final_response,
    "error": final_response if status == "no_data" else None,
    ...
}
```

Переменная `successful_results` уже вычислена на строке 276 — в scope.

**Done when:** все тесты из Task 1 проходят + регрессии 0

### Task 3: Верификация и devlog
**Files:** `devlog/changelog.json`
**Depends on:** Task 2
**Что:**
- `pytest tests/ -v` — все unit-тесты проходят
- `ruff check application/reports.py tests/application/test_reports.py`
- Запись в devlog

## Ключевое разграничение: failed vs empty

`successful_results` (строка 276) считает подвопросы где `df is not None`:
- **df=None** → SQL не сгенерирован / не прошёл валидацию / execution error → **failed**
- **df=empty DataFrame** → SQL выполнился, 0 строк → **success** (ответ "0 сделок" валиден)

Проверка `successful_results == 0` срабатывает **только** при true failures. Пустые результаты запроса (менеджер без сделок за месяц) корректно проходят как success.

## Риски

| Сценарий | Вероятность | Действие |
|----------|-------------|----------|
| Потребители status проверяют `== "success"` строго | low | Проверено: zulip_bot, batch_runner, agent — все корректно обрабатывают non-success |
| Промпт generate_final_response.txt остаётся уязвимым | low | Ветка `else` (строка 308) теперь достижима только при successful_results > 0 — в subquestion_results есть реальные данные |

## Масштаб

- 1 файл кода, 1 файл тестов, 1 devlog
- ~15 строк нового кода, ~60 строк тестов
- Последовательное выполнение (TDD: red → green → verify)
