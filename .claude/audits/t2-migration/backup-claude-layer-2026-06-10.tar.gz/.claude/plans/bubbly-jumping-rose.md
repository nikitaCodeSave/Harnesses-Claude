# Валидация и исправление SQL-промпта и метаданных

## Контекст

SQL-промпт `core/sql/prompts/v1/system.txt` и метаданные `infrastructure/metadata.py` — ключевые файлы, определяющие качество генерации SQL. При валидации обнаружены несоответствия: sql_examples нарушают правила самого промпта, описания полей ссылаются на несуществующие поля, формат дат неконсистентен. Все 33 SQL-запроса выполняются успешно на Oracle — проблемы не в синтаксисе, а в **консистентности правил и примеров**, что напрямую влияет на качество LLM-генерации.

> ORGANIZATION_NM существует и в Oracle, и в metadata.py — изначальная гипотеза об отсутствии не подтвердилась.
> PREV_ACT_1M, PREV_ACT_3M, SALARY_PROJECT — исключены из metadata намеренно, добавлять НЕ нужно.

## Найденные проблемы (6 штук)

### CRITICAL (влияют на качество SQL)

| # | Проблема | Файл | Строки |
|---|----------|------|--------|
| 1 | sql_example нарушает LIKE-правило: `ORGANIZATION_NM` в LIKE, но нет в SELECT/GROUP BY. Используется `lower()` вместо `UPPER()`. Промпт явно помечает этот паттерн как "WRONG" | metadata.py | 442-444 |
| 2 | Описания FX_EUR_VOLUME_RUB и FX_CNY_VOLUME_RUB ссылаются на несуществующие поля (FX_EUR_VOLUME_USD, FX_EUR_VOLUME_EUR, FX_CNY_VOLUME_USD, FX_CNY_VOLUME_EUR) | metadata.py | 204, 237 |
| 3 | Промпт перечисляет несуществующие поля (OPEN_DT, ACCOUNT_OPEN_DT, CLOSE_DATE, CLOSURE_DT и др.) — могут запутать LLM | system.txt | 338-341, 354-356 |

### HIGH (несоответствие правил и примеров)

| # | Проблема | Файл | Строки |
|---|----------|------|--------|
| 4 | sql_example использует `AVG(CA_LCY_SUM)`, но метаданные говорят `aggregation_between_clients='SUM'`. Промпт запрещает override через NL | metadata.py | 409-412 |
| 5 | Даты: промпт использует `DATE '...'` (ANSI literal), sql_examples — `TO_DATE()`. Стандарт: `DATE '...'` (по решению пользователя) | metadata.py sql_examples | разные |

### Не является проблемой

- ~~Имя таблицы `CLIENT_PRODUCT` (uppercase) — это корректное написание~~

## План реализации

### Task 1: Исправить sql_examples в metadata.py (Issues 1, 4, 5)

**Files:** `infrastructure/metadata.py`
**Depends on:** none

Изменения:
- **Issue 1 (line 442-444):** Исправить пример "общий доход компании Лукойл":
  - `lower(ORGANIZATION_NM) LIKE '%лукойл%'` → `UPPER(ORGANIZATION_NM) LIKE '%' || UPPER('Лукойл') || '%'`
  - Добавить `ORGANIZATION_NM` в SELECT и GROUP BY
  - `TO_DATE(...)` → `DATE '...'`
- **Issue 4 (line 409-412):** Исправить пример "средние остатки по сегментам":
  - `AVG(CA_LCY_SUM)` → `SUM(CA_LCY_SUM)`
  - Вопрос: "средние остатки" → "остатки" (убрать конфликт с правилом)
  - Алиас: `avg_balance` → `total_balance`
- **Issue 5:** Во ВСЕХ 23 sql_examples заменить `TO_DATE('YYYY-MM-DD', 'YYYY-MM-DD')` → `DATE 'YYYY-MM-DD'`

Эталонный формат (задан пользователем):
```sql
SELECT INN, ORGANIZATION_NM, SUM(FX_CNT) AS fx_operations_count
FROM client_product
WHERE MONTH_DT BETWEEN DATE '2024-01-01' AND DATE '2024-12-31'
GROUP BY INN, ORGANIZATION_NM
ORDER BY fx_operations_count DESC
```

**Done when:** Все примеры используют `DATE '...'`, LIKE-пример следует правилам промпта, AVG→SUM исправлен.

### Task 2: Удалить фантомные поля из описаний (Issue 2)

**Files:** `infrastructure/metadata.py`
**Depends on:** none

Изменения:
- **FX_EUR_VOLUME_RUB (line 204):** Удалить фразу "Это то же самое, что и FX_EUR_VOLUME_USD, FX_EUR_VOLUME_EUR, это одна и та же сумма приведенная в разных валютах. Не суммировать с этими полями!" из description и description_en
- **FX_CNY_VOLUME_RUB (line 237):** Аналогично удалить ссылки на FX_CNY_VOLUME_USD и FX_CNY_VOLUME_EUR

**Done when:** Описания не содержат ссылок на несуществующие поля.

### Task 3: Исправить промпт — убрать несуществующие поля (Issue 3)

**Files:** `core/sql/prompts/v1/system.txt`
**Depends on:** none

Изменения:
- **Issue 3 (lines 338-341):** Сократить список до `CREATE_DT` (единственное реально существующее поле)
- **Issue 3 (lines 354-356):** Аналогично: только `CLOSE_DT`

Промпт уже использует `DATE '...'` формат — это совпадает со стандартом. `CLIENT_PRODUCT` — корректное написание.

**Done when:** Промпт не содержит несуществующих полей.

### Task 4: Добавить тесты консистентности (validation guard)

**Files:** `tests/infrastructure/test_metadata.py`
**Depends on:** Tasks 1-3

Новые тесты:
1. `test_sql_examples_like_rule_compliance` — LIKE-столбец должен быть в SELECT
2. `test_sql_examples_use_upper_not_lower` — case-insensitive через UPPER(), не lower()
3. `test_field_descriptions_no_phantom_references` — описания не ссылаются на несуществующие поля

**Done when:** `pytest tests/infrastructure/test_metadata.py -v` — все новые тесты зелёные.

### Task 5: Верификация и devlog

**Files:** `devlog/changelog.json`
**Depends on:** Tasks 1-4

1. `pytest tests/ -v` — все тесты проходят
2. `python dev/test-connection.py` — Oracle доступна, metadata валидна
3. Live test: `python run_agent.py` с вопросами:
   - "общий доход компании Нестле за 2024 год" (LIKE rule)
   - "остатки по сегментам" (aggregation)
   - "сколько новых клиентов в 2024" (CREATE_DT)
4. Запись в devlog/changelog.json

**Done when:** Все проверки пройдены, devlog обновлён.

## Оценка рисков

| Сценарий | Вероятность | Воздействие | Митигация |
|----------|-------------|-------------|-----------|
| LLM генерирует другой SQL после изменений промпта | Medium | Medium | Live test обязателен; откат: `git checkout -- system.txt metadata.py` |
| TO_DATE→DATE замена ломает sql_examples | Low | Low | Проверено: `DATE '2024-11-30'` работает на Oracle |
| Тесты metadata ломаются | Low | Low | Структурные тесты не чувствительны к этим изменениям |

## Масштаб

- **Файлов к изменению:** 3 (metadata.py, system.txt, test_metadata.py) + devlog
- **Новых тестов:** 3
- **sql_examples к обновлению:** все 23 (формат дат `TO_DATE()` → `DATE '...'`) + 2 (LIKE + AVG fix)
- **Agent Teams:** не нужны (2 тесно связанных файла, последовательная проверка безопаснее)
- **Tasks 1-3 можно делать параллельно** (разные блоки в одних файлах, без конфликтов)
