# Plan: Hardening LIKE-constraint validation

## Context

`validate_like_constraints()` в `core/sql/validator.py` — детерминированный safety net, который добавляет LIKE-поля в SELECT/GROUP BY после генерации SQL от LLM. Реализация работает для основных кейсов, но имеет edge-case баги и не использует знание о метаданных таблицы.

---

## Проблема 1 (CRITICAL): Скобки в WHERE ложно пропускают LIKE

`_extract_like_fields()` использует `depths[m.start()] != 0` для пропуска LIKE в подзапросах. Но это пропускает и обычные WHERE-скобки:

```sql
-- Подзапрос (depth=1) — ПРАВИЛЬНО пропущен
WHERE id IN (SELECT id FROM t WHERE UPPER(GROUP_NM) LIKE '%test%')

-- Группировка WHERE (depth=1) — НЕПРАВИЛЬНО пропущен!
WHERE (UPPER(GROUP_NM) LIKE '%test%' AND MONTH_DT > DATE '2025-01-01')
```

Тест `test_like_in_parenthesized_where_skipped` (строка 568) документирует баг.

**Решение**: заменить простой depth на "effective depth", который учитывает только скобки подзапросов и вызовов функций, игнорируя группирующие скобки WHERE.

Классификация скобочных пар:
- **Функция** — перед `(` стоит идентификатор (`SUM(`, `UPPER(`) → +1 depth
- **Подзапрос** — внутри `(...)` есть `SELECT` → +1 depth
- **Группировка** — ни то, ни другое (`WHERE (X AND Y)`) → depth НЕ меняется

Новая функция `_compute_effective_depth(sql: str) -> list[int]` в validator.py.

## Проблема 2: Regex не ловит table alias

`_LIKE_PATTERN` использует `\(\s*(\w+)\s*\)` — `\w+` не содержит точку, поэтому `UPPER(cp.GROUP_NM)` не ловится.

**Решение**: добавить optional alias prefix `(?:\w+\.)?` в regex:
```python
# Было:  \(\s*(\w+)\s*\)
# Стало: \(\s*(?:\w+\.)?\s*(\w+)\s*\)
```

## Проблема 3: Нет связи с метаданными

`_extract_like_fields` возвращает любое слово перед LIKE — может быть false positive на нестандартном SQL. Система не знает что GROUP_NM, ORGANIZATION_NM — текстовые поля для LIKE.

**Решение**: добавить `_get_text_fields() -> frozenset[str]` — рантайм-вычисление из существующего `type: VARCHAR2(...)` в metadata. Фильтровать LIKE-поля в `validate_like_constraints()` по этому набору.

- **metadata.py НЕ меняется** — данные выводятся из `type` поля
- 6 зависимых модулей не затрагиваются
- `lru_cache` для перформанса

## Проблема 4: CTE + _insert_into_select

`_insert_into_select` находит первый `SELECT` — для CTE (`WITH cte AS (SELECT ...) SELECT ...`) вставит поле в CTE, не во внешний SELECT.

**Решение**: `_find_outer_select_pos()` — находит внешний SELECT (depth=0 после WITH).

---

## Файлы

| Файл | Изменение |
|------|-----------|
| `tests/core/sql/test_validator.py` | ~12 новых/обновлённых тестов (TDD — ПЕРВЫМИ) |
| `core/sql/validator.py` | `_compute_effective_depth()`, обновлённый `_LIKE_PATTERN`, `_get_text_fields()`, опционально `_find_outer_select_pos()` |
| `devlog/changelog.json` | Новая запись |

## Порядок (TDD)

### Шаг 1: Тесты для effective depth (Phase 1)
- Обновить `test_like_in_parenthesized_where_skipped` → `test_like_in_parenthesized_where_detected` (assert modified=True)
- Новый `test_like_in_multi_condition_parenthesized_where` — `WHERE (UPPER(X) LIKE ... AND date > ...)`
- Новый `test_like_in_nested_grouping_parens` — `WHERE ((UPPER(X) LIKE ...))`
- Проверить что существующие тесты подзапросов и SUM(CASE) НЕ сломались

### Шаг 2: Реализовать _compute_effective_depth + обновить _extract_like_fields
- `_compute_effective_depth()`: стэк для пар скобок → классификация → effective depth
- Заменить `depths` на `effective_depth` в `_extract_like_fields`
- `pytest tests/core/sql/test_validator.py -v` → все GREEN

### Шаг 3: Тесты для table alias (Phase 2)
- `test_like_with_table_alias_in_upper` — `UPPER(cp.GROUP_NM) LIKE` → GROUP_NM
- `test_like_with_table_alias_plain` — `cp.GROUP_NM LIKE` → GROUP_NM

### Шаг 4: Обновить _LIKE_PATTERN
- Добавить `(?:\w+\.)?` в оба branch regex

### Шаг 5: Тесты для metadata filtering (Phase 3)
- `test_like_non_metadata_field_ignored` — `BOGUS_FIELD LIKE` → не трогаем SQL
- `test_like_metadata_varchar2_field_processed` — GROUP_NM → обрабатываем
- `test_get_text_fields_returns_expected` — unit test для `_get_text_fields()`

### Шаг 6: Реализовать _get_text_fields + filtering в validate_like_constraints

### Шаг 7: Тесты + реализация CTE fix
- `test_cte_field_inserted_in_outer_select` — поле добавляется во внешний SELECT, не в CTE
- `test_multi_cte_field_in_outer_select` — `WITH a AS (...), b AS (...) SELECT ...`
- Обновить `test_cte_outer_like_detected` — проверить что поле именно во внешнем SELECT
- Реализовать `_find_outer_select_pos()` + обновить `_insert_into_select()`

### Шаг 8: Полный прогон тестов + devlog

## Верификация

```bash
pytest tests/core/sql/test_validator.py -v     # все тесты validator
pytest tests/ -v                                # полная регрессия (854 теста)
```
