# Plan: Fix two-step AVG prompt bug + duplicate column detection

## Context

Два взаимосвязанных бага, обнаруженных при e2e тестировании:

**Баг 1 (семантический):** STRICT RULE в `sql_generation.txt` (строки 228-286) принуждает LLM использовать two-step pattern (SUM→AVG через подзапрос) для ВСЕХ запросов с balance-полями (`between_month='AVG'`). Но для помесячных разбивок (каждый месяц — отдельная строка) two-step вырождается в SUM, потому что данные имеют месячную гранулярность (один MONTH_DT на клиент на месяц). Verified query в metadata.py (строка 474) правильно использует простой `SUM GROUP BY MONTH_DT`.

**Баг 2 (crash):** LLM при fix SQL иногда генерирует дубли alias'ов в SELECT (например, два `CA_AVG_BALANCE`), что вызывает crash в `response_generator.py` — pandas `df[col]` возвращает DataFrame вместо Series.

## Фаза 0: Наблюдения

| Наблюдение | Ожидание | Реальность | Проблема? |
|------------|----------|------------|-----------|
| "средние остатки по месяцам" → SQL с two-step subquery | SUM(CA_LCY_SUM) GROUP BY MONTH_DT (как verified query) | AVG(SUM(CA_LCY_SUM)) через подзапрос = SUM | Да — критичность HIGH |
| Контрольный AVG vs сгенерированный | Одинаковые числа | Расхождение 100x (SUM vs AVG) | Да — данные неверны |
| "топ-5 по PNL + динамика" → дубли колонок | Уникальные alias'ы | `['CA_AVG_BALANCE', 'CA_AVG_BALANCE']` → crash | Да — crash |

---

## Tasks

### Task 1: Тесты для `_deduplicate_select_aliases` (TDD RED)
**Files:** `tests/core/sql/test_validator.py`
**Depends on:** nothing

Добавить `TestDeduplicateSelectAliases` с 6 тестами:
1. `test_no_duplicates_unchanged` — уникальные alias'ы → без изменений, `modified=False`
2. `test_simple_duplicate_renamed` — `SELECT SUM(A) AS bal, AVG(B) AS bal FROM t` → `...AS bal_2`
3. `test_triple_duplicate` — три одинаковых → `_2`, `_3`
4. `test_subquery_duplicates_ignored` — дубли внутри подзапроса не трогать, только outer SELECT
5. `test_case_insensitive` — `AS BAL` и `AS bal` → дубль
6. `test_string_literal_not_matched` — `'AS bal'` внутри строки не считается alias

**Done when:** `pytest ...::TestDeduplicateSelectAliases -v` → 6 FAIL

### Task 2: Тесты для DataFrame duplicate defense (TDD RED)
**Files:** `tests/core/output/test_response_generator.py`
**Depends on:** nothing

Добавить `TestDuplicateColumnHandling` с 3 тестами:
1. `test_dataframe_to_digest_with_duplicate_columns` — не crashит, возвращает валидный digest
2. `test_dataframe_to_text_with_duplicate_columns` — не crashит
3. `test_digest_columns_are_unique` — все колонки уникальны после обработки

**Done when:** `pytest ...::TestDuplicateColumnHandling -v` → 3 FAIL

### Task 3: Реализация `_deduplicate_select_aliases` (TDD GREEN)
**Files:** `core/sql/validator.py`
**Depends on:** Task 1

Функция после `validate_subquery_alias_mismatch` (~строка 520). Алгоритм:
1. `_find_outer_select_pos()` → CTE handling
2. `_mask_string_literals()` → безопасность строковых литералов
3. `_compute_effective_depth()` → только depth=0
4. Найти span outer SELECT...FROM
5. Regex `\bAS\s+(\w+)` на depth=0 → собрать alias'ы
6. Для дублей — replace с суффиксом `_2`, `_3` (в обратном порядке для сохранения позиций)
7. Return `(sql, modified)`

**Reuses:** `_find_outer_select_pos`, `_mask_string_literals`, `_compute_effective_depth`

**Done when:** `pytest ...::TestDeduplicateSelectAliases -v` → 6 PASS

### Task 4: Реализация DataFrame duplicate defense (TDD GREEN)
**Files:** `core/output/response_generator.py`
**Depends on:** Task 2

Функция `_deduplicate_df_columns(df)`:
1. Fast path: `if not df.columns.duplicated().any(): return df`
2. Переименовать дубли с суффиксом `_2`, `_3`
3. `df.set_axis(new_columns, axis=1)`

Вызвать в начале `dataframe_to_digest()` (строка 378) и `dataframe_to_text()` (строка 301).

**Done when:** `pytest ...::TestDuplicateColumnHandling -v` → 3 PASS

### Task 5: Wiring dedup в validation loop + полный regression
**Files:** `core/sql/validator.py`
**Depends on:** Task 3

**5a.** После `validate_subquery_alias_mismatch` (строка 1117):
```python
sql, dedup_modified = _deduplicate_select_aliases(sql)
if dedup_modified:
    logger.info("Дедупликация alias'ов в SELECT")
```

**5b.** Сразу после `fixed_sql = fix_sql_with_llm(...)` (строка 1143), ДО `check_sql_structure_preserved` (строка 1155):
```python
            fixed_sql, dedup_modified = _deduplicate_select_aliases(fixed_sql)
            if dedup_modified:
                logger.info("Дедупликация alias'ов в SELECT после LLM fix")
```
**Важно:** dedup ДОЛЖЕН быть до check_sql_structure_preserved, иначе переименование `_2` будет считаться нарушением структуры.

**Done when:** `pytest tests/ -v` → all PASS, 0 regressions

### Task 6: Обновление sql_generation.txt — Fix STRICT RULE
**Files:** `core/sql/prompts/v1/sql_generation.txt`
**Depends on:** nothing (параллельно с Tasks 1-5)

**Ключевое понимание:** данные в client_product — месячные снепшоты (один MONTH_DT на клиента на месяц). Но пользователи задают `BETWEEN` с точностью до дней. Two-step НУЖЕН для total за период (AVG по месяцам). Two-step НЕ НУЖЕН для помесячных разбивок (GROUP BY month → SUM per month).

Переписать строки 228-293:

1. **STRICT RULE** (строки 230-237): СОХРАНИТЬ two-step для свёртки месяцев, ДОБАВИТЬ чёткое разграничение:
   ```
   ❗ STRICT RULE applies when MONTHS ARE BEING COLLAPSED — i.e., the output
   does NOT have GROUP BY month (TO_CHAR(MONTH_DT,...) or MONTH_DT).
   This includes:
   - "средний остаток за 2024 год" (one row total)
   - "средний остаток по сегментам" (rows per segment, but months collapsed)
   In these cases: two-step SUM per MONTH_DT → AVG over months.

   ❗ EXCEPTION — WHEN MONTHS ARE NOT COLLAPSED:
   When output has GROUP BY month/quarter (each time bucket = separate row),
   months are NOT being collapsed → between_month does NOT apply.
   Use aggregation_between_clients = SUM(field) GROUP BY time_bucket.
   Examples: "остатки по месяцам", "PNL по кварталам" → SUM(field) GROUP BY month.
   ```

2. **Example 3.1** (строки 261-270): оставить без изменений (correct two-step для total)

3. **Example 3.2** (строки 271-286): заменить two-step на простую агрегацию:
   ```sql
   SELECT TO_CHAR(MONTH_DT,'YYYY-MM') AS month,
          SUM(field) AS field_sum_month  -- per_month='SUM', each month separate
   FROM {table_name}
   WHERE MONTH_DT BETWEEN DATE 'YYYY-01-01' AND DATE 'YYYY-12-31'
   GROUP BY TO_CHAR(MONTH_DT,'YYYY-MM')
   ORDER BY month;
   ```
   Добавить комментарий: `-- NO subquery needed: each month is a separate output row`

4. **Example 3.3** (строки 287-293): аналогично — без подзапроса для помесячных разбивок

5. **Natural-language mapping** (строки 243-257): уточнить что "средний остаток по месяцам" = SUM per month (NOT two-step), а "средний остаток за год" = two-step (AVG of monthly SUMs)

**Done when:** 4 live-теста:
1. "средние остатки по месяцам за 2024" → `SUM(CA_LCY_SUM) GROUP BY TO_CHAR(MONTH_DT,...)` (без подзапроса)
2. "средний остаток за 2024 год" → two-step subquery (months collapsed → одна строка)
3. "средний остаток по сегментам за 2024" → two-step subquery (months collapsed, GROUP BY SEG only)
4. "средний остаток по сегментам и месяцам за 2024" → SUM GROUP BY SEG, month (months NOT collapsed)

### Task 7: Обновление sql_fix.txt для консистентности
**Files:** `core/sql/prompts/v1/sql_fix.txt`
**Depends on:** Task 6

После ORA-00937 секции (строка ~110), добавить:
```
ВАЖНО: Если запрос показывает данные ПОМЕСЯЧНО (GROUP BY MONTH_DT или TO_CHAR(MONTH_DT,...)),
НЕ оборачивай в подзапрос с AVG. Используй SUM(field) GROUP BY MONTH_DT.
Подзапрос с AVG нужен ТОЛЬКО для агрегации за ВЕСЬ период в одну строку.

Дубликаты alias'ов в SELECT:
- НЕ создавай несколько колонок с одинаковым alias.
- Каждый AS <alias> должен быть уникальным.
```

**Done when:** промпт обновлён, `pytest tests/ -v` зелёный

### Task 8: Changelog + финальная верификация
**Files:** `devlog/changelog.json`
**Depends on:** Tasks 1-7

1. Запись #110 в changelog
2. `pytest tests/ -v` → 0 failures
3. `ruff check` → clean
4. Live test: `python dev/e2e_trace.py "средние остатки на расчётных счетах по месяцам за 2024 год"` → SUM, не two-step

**Done when:** все тесты зелёные, live test подтверждает корректную семантику

---

## Порядок выполнения

**Начать с Task 6 (промпт)** — самое рискованное, сложнее откатить. Live-тесты покажут проблемы до написания кода dedup.

```
Task 6 (prompt fix) ──→ Task 7 (fix prompt) ──→ live tests (4 сценария)
    ↓ (параллельно после live-тестов OK)
Task 1 (tests SQL dedup) ──→ Task 3 (impl) ──→ Task 5 (wire) ──┐
Task 2 (tests DF dedup) ──→ Task 4 (impl) ──────────────────────┤
                                                                 └→ Task 8 (verify)
```

Tasks 1 и 2 можно параллелить после подтверждения промпта.

## Risks

| Сценарий | Вероятность | Воздействие | Действие |
|----------|-------------|-------------|----------|
| Prompt change ломает другие типы запросов | medium | неверный SQL для non-balance вопросов | Live test regression: 8 вопросов из measure_full_pipeline |
| Regex alias parsing пропускает CASE expression alias | low | не ловит дубль | Тест с CASE WHEN ... END AS alias |
| DF dedup меняет имена колонок, ломая downstream | low | некорректный промпт response_generator | Суффикс `_2` визуально ясен, данные не теряются |
| Two-step всё ещё нужен для quarterly/yearly totals | low | регрессия на total-запросах | Example 3.1 сохранён, live test |

## Scope

- **7 файлов**: 2 промпта, validator.py, response_generator.py, 2 тест-файла, changelog
- **~9 тестов** новых + ~50-70 строк кода + переписка промпта
- **0 новых зависимостей**
