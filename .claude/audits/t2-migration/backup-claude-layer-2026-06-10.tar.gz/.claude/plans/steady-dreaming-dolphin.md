# План: Обогащение мониторинга данными DESK + расширение аналитики

## Контекст

ADR-021 (row-level access control) уже реализован: `resolve_access()` запрашивает таблицу DESK для определения прав пользователя. Но запрос берёт только 2 поля (`DESK_NAME`, `HEAD_FLG`), а мониторинг (`data/monitoring/`) не содержит информации о дэске пользователя. Это значит, что аналитика (`/analytics` в Zulip) не может показать разбивку по дэскам, менеджерам и логинам.

**Цель:** Добавить 4 поля DESK-таблицы в мониторинг-JSON и расширить Excel-аналитику дэск-аналитикой.

## Изменения

### Task 1: Миграция AccessInfo на Pydantic + расширение полей

**Файл:** `infrastructure/access_config.py`

Заменяем `@dataclass(frozen=True)` на Pydantic `BaseModel` с `Field(description=...)`. Проект уже использует pydantic (settings.py) — консистентный подход.

Текущий:
```python
@dataclass(frozen=True)
class AccessInfo:
    desk_names: list[str]
    is_head: bool
```

Новый:
```python
from pydantic import BaseModel, Field

class AccessInfo(BaseModel):
    """Результат резолвинга доступа пользователя (ADR-021)."""
    model_config = {"frozen": True}

    desk_names: list[str] = Field(description="Список дэсков для SQL-фильтра (пустой для HEAD)")
    is_head: bool = Field(description="HEAD-пользователь = полный доступ без фильтрации")
    desk_name: str = Field(default="", description="Оригинальный DESK_NAME из таблицы DESK")
    manager_name: str = Field(default="", description="ФИО менеджера (MANAGER_NAME)")
    login: str = Field(default="", description="Oracle LOGIN из таблицы DESK")
    employee_id: str = Field(default="", description="Табельный номер (EMPLOYEE_ID)")
```

Убираем `from dataclasses import dataclass`. Добавляем `from pydantic import BaseModel, Field`.

SQL-запрос:
```sql
-- Было:
SELECT DESK_NAME, HEAD_FLG FROM DESK WHERE LOGIN = :login AND VALID_TO = DATE '4000-01-01'

-- Стало:
SELECT DESK_NAME, HEAD_FLG, MANAGER_NAME, LOGIN, EMPLOYEE_ID FROM DESK WHERE LOGIN = :login AND VALID_TO = DATE '4000-01-01'
```

Новые поля заполняются для **всех** пользователей (включая HEAD). Дефолты `""` — обратная совместимость для кода, использующего только `desk_names`/`is_head`.

### Task 2: Добавить desk-поля в request_tracker

**Файл:** `infrastructure/request_tracker.py`

- `build_request_rows()` и `track_request()`: новый параметр `access_info: Any = None`
- В `_build_common_fields()` после "source" добавить 4 поля:
  ```python
  "desk_name": access_info.desk_name if access_info else "",
  "manager_name": access_info.manager_name if access_info else "",
  "login": access_info.login if access_info else "",
  "employee_id": access_info.employee_id if access_info else "",
  ```

### Task 3: Передать AccessInfo из agent в tracker (1 строка)

**Файл:** `application/agent.py` → `_track_request()`

```python
track_request(
    ...,
    access_info=self._access,  # ← новая строка
)
```

### Task 4: Расширить analytics Excel

**Файл:** `infrastructure/analytics.py`

| Лист | Изменение |
|------|-----------|
| 1 (Данные для ревью) | +3 колонки: Дэск, Менеджер, Логин (после Источник) |
| 2 (Обзор) | +1 метрика: Уникальных дэсков |
| 6 (Пользователи) | +2 колонки: Дэск, Менеджер (join first occurrence) |
| **7 (По дэскам)** | **Новый лист**: Дэск, Запросов, Пользователей, Успешных, Ошибок |

Обратная совместимость: `if "desk_name" in df.columns` — старые данные без desk-полей не ломают отчёт.

### Task 5: Тесты

- `tests/infrastructure/test_access_config.py` — обновить `fetchone` return на 5-tuple, проверить новые поля
- `tests/infrastructure/test_request_tracker.py` — тесты с/без access_info
- `tests/infrastructure/test_analytics.py` — тесты новых колонок и листа "По дэскам"

### Task 6: Devlog

Запись в `devlog/changelog.json`.

## Порядок выполнения

1. Task 1 (access_config) → тесты
2. Task 2 (request_tracker) → тесты
3. Task 3 (agent.py) — 1 строка
4. Task 4 (analytics) → тесты
5. Полный `pytest tests/ -v`
6. Task 6 (devlog)

Tasks 1-2 независимы, можно параллельно.

## Обратная совместимость

- Старые JSON без desk-полей: pandas заполняет NaN, `available` фильтр в review_sheet пропускает отсутствующие колонки
- Console/batch: `self._access = None` → пустые строки в desk-полях
- AccessInfo: новые поля с дефолтами — существующий код не ломается

## Проверка

1. `pytest tests/ -v` — все unit-тесты зелёные
2. `pytest -m "integration and not slow"` — integration-тесты на Oracle
3. Live: запустить Zulip-бот, отправить вопрос, проверить:
   - JSON в `data/monitoring/` содержит desk_name, manager_name, login, employee_id
   - `/analytics` Excel содержит лист "По дэскам" и новые колонки
