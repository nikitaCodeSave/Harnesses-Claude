# Brainstorm-зона для перехода MVP → Production v2

## Context

MVP показал метрики, приемлемые для организации, на одной таблице `client_product` с монолитным промптом и набором полей в `infrastructure/metadata.py`. Следующий этап — продовая архитектура: множество таблиц с JOIN-ами, полноценный агентский цикл, валидация пользовательских вопросов и генерации SQL, вынос 12 категорий бизнес-правил из промпта.

Brainstorm уже идёт, но **рассеян**:
- `docs/thinking/` — 15 плоских документов с датой-префиксом; часть напрямую относится к production-v2 (`2026-04-21-catalog-format-mdl-semantic-layer.md`, `2026-04-21-sql2text-requirements.md`, `2026-04-06-deep-project-review-spec.md`, блок `2026-03-27-*` про SQL-grounding), часть — нет. INDEX отсутствует.
- `docs/research/` — 44 файла, без INDEX, без связи с thinking-документами.
- Внешний контекст (чаты в claude.ai) — ещё не в репо.
- В MEMORY уже зафиксировано: «SQL quality initiative: 12 thinking docs, prompt overload crisis, 4 quick wins pending» — т.е. прецедент крупной инициативы без структуры уже был.

Проблема: при ≥10 документах по одной теме без INDEX начинается дрейф — дубликаты, потерянные открытые вопросы, непонятный статус «что уже решено / что в работе». Для production-v2 документов будет сильно больше 10.

Цель этого плана — создать **минимальную организационную надстройку** над существующим `/think → /research → /spec` workflow, которая:
1. Даёт одну точку входа для всей инициативы (карта + roadmap + открытые вопросы).
2. Не ломает существующие скиллы и папки (`/think` по-прежнему пишет в `docs/thinking/`).
3. Даёт место для импорта внешнего контекста (claude.ai чаты).
4. Грепабельна: все документы инициативы находятся за 1 команду.

## Архитектурный выбор

**Гибрид: новая папка `docs/initiatives/production-v2/` как агрегирующий слой + сохранение плоских `docs/thinking/` / `docs/research/` для индивидуальных документов.**

Почему не просто `docs/thinking/INDEX.md`:
- INDEX смешивается с другими думками, его приходится поддерживать вручную внутри чужой папки.
- Нет места для артефактов, которые не являются think/research (выжимки чатов, черновые метрики, roadmap).

Почему не `docs/plans/production-v2/`:
- `docs/plans/` сейчас под короткоживущие планы итераций (`BACKLOG.md`, `2026-02-21-post-review-consolidation-plan.md`). Инициатива живёт месяцами, это другой жанр.

Почему не подпапка в `docs/thinking/`:
- Скилл `/think` пишет плоско по дате; ломать это соглашение ради одной инициативы дорого.

## Предлагаемая структура

```
docs/initiatives/production-v2/
  README.md              # карта инициативы: goal, scope, success, current phase, doc map
  roadmap.md             # фазы с критериями готовности, связи на thinking/research
  open-questions.md      # открытые вопросы с владельцем и статусом
  decisions-log.md       # что уже решено на уровне инициативы (lightweight, до ADR)
  external-context.md    # выжимки из claude.ai чатов + ссылки
  metrics-baseline.md    # baseline MVP-метрик (которые надо удержать/превзойти)
```

**Связь с существующими артефактами (не трогаем):**
- Индивидуальные размышления → по-прежнему `docs/thinking/YYYY-MM-DD-<slug>.md` (через `/think`).
- Углублённое исследование кода/литературы → `docs/research/YYYY-MM-DD-<slug>.md` (через `/research`).
- Формальные архитектурные решения → `docs/decisions/ADR-023+.md` (ADR пишется, когда решение созрело — из инициативы).
- Планы реализации конкретных задач → `.claude/plans/<slug>.md` (через `/spec`).
- История реализованного → `devlog/changelog.json`.

**Соглашение для грепабельности** (опционально, но рекомендую):
В YAML front-matter каждого `docs/thinking/` и `docs/research/` документа, относящегося к инициативе, добавить поле:
```yaml
initiative: production-v2
```
Тогда `grep -l "initiative: production-v2" docs/thinking/ docs/research/` даёт полный список.

## Черновик карты инициативы (для README.md)

Фазы, которые уже видны из имеющихся think-документов:

| Фаза | Тема | Готовые thinking-документы |
|---|---|---|
| P0 — Discovery | Зафиксировать текущее поведение, собрать требования, импортировать внешний контекст | `2026-04-21-sql2text-requirements.md` (частично), `2026-04-06-deep-project-review-spec.md` |
| P1 — Domain catalog | Формат каталога (YAML/pydantic), entities, relationships, мультитабличность | `2026-04-21-catalog-format-mdl-semantic-layer.md` |
| P2 — Rules layer | Вынос 12 категорий бизнес-правил из промпта, retrieval по типу вопроса | `2026-04-02-prompt-conflict-resolution-sql-generation.md`, `2026-04-02-small-llm-prompt-structure-rules.md` |
| P3 — Pipeline v2 | 9 этапов: выбор таблицы, выбор полей, grounding, генерация, валидация | `2026-03-27-temporal-context-*`, `2026-03-27-sql-aware-aggregation-*`, `2026-04-02-sql-prompt-reasoning-loops.md` |
| P4 — Validation & agents | AST-валидация SQL, multi-turn agent loop, error enrichment | `2026-03-27-sql-generation-quality-verified-queries.md`, `2026-03-30-explain-plan-validation-gap.md`, `2026-03-30-error-enrichment-ora-00937.md` |
| P5 — Quality gates | Acceptance tests (12 сценариев из sql2text §11), golden dataset, live-метрики | нет, нужен новый think |
| P6 — Migration | Feature flag, параллельный прогон MVP vs v2, cutover | нет, нужен новый think |

README.md содержит эту таблицу + явные **success criteria** (что значит «инициатива закрыта»), **текущую фазу**, **счётчик открытых вопросов** (берётся из open-questions.md).

## План реализации (один подход к созданию — за одну сессию)

1. Создать папку `docs/initiatives/production-v2/`.
2. Создать шесть файлов-скелетов (README, roadmap, open-questions, decisions-log, external-context, metrics-baseline). Каждый — короткий, с секциями-заглушками, чтобы было ясно куда что класть.
3. README.md заполнить сразу: цель, scope, таблица фаз (см. выше), ссылки на 2 свежих thinking-документа + 10 более ранних, относящихся к P2–P4.
4. В два свежих thinking-документа (`2026-04-21-catalog-format-*`, `2026-04-21-sql2text-requirements.md`) добавить в front-matter поле `initiative: production-v2` — чтобы грепабельность заработала с первого дня.
5. Добавить одну строку в `CLAUDE.md` в разделе «Правила»: `- Инициативы (крупные: production-v2) → docs/initiatives/<name>/README.md` — чтобы будущие сессии знали о точке входа.

Опционально (не в этой сессии):
- Импорт чатов с claude.ai: попросить пользователя выгрузить их в markdown, положить в `external-context.md` как выжимки + ссылки.
- Ретроспективная простановка `initiative: production-v2` в более ранних think-документах (P2–P4).
- Обновить скилл `/think` так, чтобы он опционально принимал `--initiative <name>` и прописывал тег в front-matter автоматически.

## Критические файлы для этого плана

- `docs/initiatives/production-v2/README.md` — создать
- `docs/initiatives/production-v2/roadmap.md` — создать
- `docs/initiatives/production-v2/open-questions.md` — создать
- `docs/initiatives/production-v2/decisions-log.md` — создать
- `docs/initiatives/production-v2/external-context.md` — создать
- `docs/initiatives/production-v2/metrics-baseline.md` — создать
- `docs/thinking/2026-04-21-catalog-format-mdl-semantic-layer.md` — добавить тег в front-matter
- `docs/thinking/2026-04-21-sql2text-requirements.md` — добавить тег в front-matter
- `CLAUDE.md` — добавить одну строку про docs/initiatives/

## Verification

1. `ls docs/initiatives/production-v2/` — шесть файлов на месте.
2. Прочитать README.md — таблица фаз ссылается на существующие thinking-документы по корректным относительным путям (`../../thinking/2026-04-21-*.md`).
3. `grep -l "initiative: production-v2" docs/thinking/` — даёт минимум 2 файла.
4. Прочитать `CLAUDE.md` — новая строка про инициативы видна в разделе «Правила».
5. Запустить ментальный тест: «новая сессия должна за 1 минуту понять куда класть следующий think по мультитабличности». Ответ: через `/think` в `docs/thinking/` с тегом, затем обновить roadmap.md и open-questions.md в инициативе.
