# Fix 3 lint warnings in test files

## Context
Верификация (`/verify`) выявила 3 lint-замечания в новых тестовых файлах. Все unit-тесты проходят (588/588), это чисто косметические фиксы.

## Changes

### 1. `tests/infrastructure/test_log_context.py` (lines 14, 21)
- F841: `token = set_request_id(...)` → `set_request_id(...)` (убрать неиспользуемое присваивание, 2 места)

### 2. `tests/infrastructure/test_log_setup.py` (line 9)
- F401: удалить `from unittest.mock import patch` (неиспользуемый импорт)

## Verification
- `ruff check tests/infrastructure/test_log_context.py tests/infrastructure/test_log_setup.py` — 0 errors
- `pytest tests/infrastructure/test_log_context.py tests/infrastructure/test_log_setup.py -v` — all pass
