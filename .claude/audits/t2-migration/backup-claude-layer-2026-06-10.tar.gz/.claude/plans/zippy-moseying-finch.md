# План: Перемещение progress.py из application/ в infrastructure/

## Контекст

`presentation/zulip_bot.py:24` импортирует типы из `application/progress.py` — нарушение layered architecture (presentation не должен зависеть от application). Модуль содержит инфраструктурные типы (Enum, NamedTuple, frozenset, type aliases) и тонкую фабрику, а не бизнес-логику. Сам progress.py уже импортирует из `infrastructure.utils.make_emit` — концептуально принадлежит infrastructure-слою. Presentation уже легально импортирует из infrastructure (settings, db_connector).

## Масштаб

- **7 файлов** — обновление импортов (3 production + 1 presentation + 3 теста)
- **1 файл** — перемещение модуля
- **1 файл** — перемещение тестов
- **2 файла** — документация (architecture.md, devlog)
- Удаление dead code: `EmitFn` type alias

## Задачи

### Task 1: Переместить модуль + удалить EmitFn
```
Files: application/progress.py -> infrastructure/progress.py
Depends on: none
```
- `git mv application/progress.py infrastructure/progress.py`
- Удалить строку 30: `EmitFn = Callable[[str, ProgressEventType], None]`
- Заменить return type в `make_progress_emit` (строка 33): `-> EmitFn:` на `-> Callable[[str, ProgressEventType], None]:`
- **Done when:** файл в infrastructure/, EmitFn удалён, `grep -r EmitFn .` = 0 (кроме docs/research/)

### Task 2: Обновить импорты в production-коде (4 файла)
```
Files: application/agent.py:15, application/subquestion.py:11,
       application/reports.py:15, presentation/zulip_bot.py:24
Depends on: Task 1
```
Замена `from application.progress` → `from infrastructure.progress` в каждом файле.

| Файл | Строка | Импорты |
|------|--------|---------|
| application/agent.py | 15 | ProgressCallback, ProgressEventType, make_progress_emit |
| application/subquestion.py | 11 | ProgressCallback, ProgressEventType, make_progress_emit |
| application/reports.py | 15 | ProgressCallback, ProgressEventType, make_progress_emit |
| presentation/zulip_bot.py | 24 | IMMEDIATE_TYPES, ProgressEvent |

- **Done when:** `grep -r "from application.progress" . --include="*.py"` = 0 (кроме docs/research/)

### Task 3: Переместить тесты + обновить тестовые импорты
```
Files: tests/application/test_progress.py -> tests/infrastructure/test_progress.py,
       tests/application/test_callback.py:41, tests/presentation/test_zulip_logger.py:5
Depends on: Task 1
```
- `git mv tests/application/test_progress.py tests/infrastructure/test_progress.py`
- В перемещённом файле: обновить import и docstring (`application.progress` → `infrastructure.progress`)
- В test_callback.py:41: `from application.progress` → `from infrastructure.progress`
- В test_zulip_logger.py:5: `from application.progress` → `from infrastructure.progress`
- **Done when:** `pytest tests/ -v` — все тесты проходят

### Task 4: Документация и devlog
```
Files: docs/architecture.md, devlog/changelog.json
Depends on: Tasks 1-3
```
- docs/architecture.md: добавить `infrastructure/progress.py` в список модулей infrastructure-слоя
- devlog: запись type=refactor, scope=все затронутые файлы

## Верификация

```bash
# 1. Все тесты проходят
pytest tests/ -v

# 2. Нет старых импортов (кроме docs/research/)
grep -r "from application.progress" . --include="*.py"

# 3. Новые импорты на месте
grep -r "from infrastructure.progress" . --include="*.py"

# 4. Файл удалён из application/
ls application/progress.py  # должен вернуть ошибку

# 5. EmitFn удалён
grep -r "EmitFn" . --include="*.py"  # 0 совпадений (кроме docs/)
```

## Риски

| Сценарий | Вероятность | Действие |
|----------|-------------|----------|
| `__pycache__` со старыми .pyc | low | `find . -name __pycache__ -exec rm -rf {} +` |
| Пропущенный импорт | low | grep + pytest покажут |

## Рекомендация

Задачи 2 и 3 независимы друг от друга (обе зависят только от Task 1) — можно выполнять параллельно. Общий объём: ~20 минут, Agent Teams не нужны.
