# Plan: Sync docs after formatters.py / pdf_generator.py changes

## What changed in code

Uncommitted changes (on top of feature branch):

1. `core/report/formatters.py` — added `from infrastructure.utils import is_id_column`; `should_use_unit_abbreviations()` now excludes ID columns (INN, CUSTOMER_ID, *_ID) from metric detection
2. `core/report/pdf_generator.py` — added `from infrastructure.utils import is_id_column`; `_prepare_table_data()` now skips unit abbreviation for ID columns (per-cell check)
3. `tests/core/report/test_formatters.py` — 3 new tests for ID-column exclusion in `should_use_unit_abbreviations()`
4. `tests/core/report/test_pdf_integration.py` — 1 new test class `TestPrepareTableDataINN` verifying INN not abbreviated

## Classification

- `core/report/formatters.py` -> Reporting (role: value formatting for PDF) -> architecture.md (dependency graph: new import of utils)
- `core/report/pdf_generator.py` -> Reporting (role: PDF orchestrator) -> architecture.md (dependency graph: new import of utils)
- `tests/core/report/test_formatters.py` -> Tests -> CLAUDE.md (test counts)
- `tests/core/report/test_pdf_integration.py` -> Tests -> CLAUDE.md (test counts)

## Documentation changes needed

### 1. architecture.md — dependency graph update

Current graph shows:
```
+-- core/report/pdf_generator.py -------- infrastructure/output_config, reportlab, core/report/formatters, core/report/styles, core/report/table_builder
|   +-- core/report/formatters.py ------- (formatting values and DataFrame)
```

Both `formatters.py` and `pdf_generator.py` now import `infrastructure/utils.py` (specifically `is_id_column()`).

**Update needed:**
- Line 427: `core/report/formatters.py` — add dependency on `infrastructure/utils`
- Line 426: `core/report/pdf_generator.py` — add dependency on `infrastructure/utils`

Also update mermaid diagram: add edges `PDFF --> UTL` and `PDF --> UTL`.

### 2. architecture.md — module description for formatters.py

Current (line 272):
> Formatting of values and text: dates, numbers, markdown cleanup, DataFrame preparation for table insertion.

Should mention ID-column exclusion from unit abbreviation. Actually this is an internal detail — the description is about the module's responsibility, not every function detail. The current description is adequate.

However, the `is_id_column()` description in utils.py (line 315) says:
> used in chart_builder, response_generator

Now it's also used in formatters.py and pdf_generator.py. **Update needed.**

### 3. CLAUDE.md — test counts

Current: "46 test-files, 1039 tests"
Actual: 50 test-files, 1087 tests (+ 27 deselected integration = 1114 collected)

**Update needed:** 46 -> 50 test-files, 1039 -> 1087 tests

Also: "ADR-001..ADR-020" — there are 22 ADR files (including ADR-TEMPLATE), with ADR-014 having two files (ADR-014-client-product-migration.md and ADR-014-monitoring.md). The range ADR-001..ADR-020 is correct.

### 4. No ADR needed

This is a bug fix (INN values displayed as "7.8 mlrd" in PDF tables), not an architectural change. No new module, no pipeline change.

### 5. Other docs

- configuration.md — no new settings, not affected
- setup.md — not affected
- zulip-setup.md — not affected
- output-files.md — not affected

## Specific edits

### architecture.md

1. Mermaid diagram: add two edges
   - `PDFF --> UTL` (formatters uses is_id_column from utils)
   - `PDF --> UTL` (pdf_generator uses is_id_column from utils)

2. Utils module description (line 315): add formatters.py and pdf_generator.py to is_id_column users
   Old: `(used in chart_builder, response_generator)`
   New: `(used in chart_builder, response_generator, formatters, pdf_generator)`

3. Dependency graph (line 426-427):
   Old:
   ```
   +-- core/report/pdf_generator.py -------- infrastructure/output_config, reportlab, core/report/formatters, core/report/styles, core/report/table_builder
   |   +-- core/report/formatters.py ------- (formatting values and DataFrame)
   ```
   New:
   ```
   +-- core/report/pdf_generator.py -------- infrastructure/output_config, infrastructure/utils, reportlab, core/report/formatters, core/report/styles, core/report/table_builder
   |   +-- core/report/formatters.py ------- infrastructure/utils
   ```

### CLAUDE.md

1. Line 140: Update test counts
   Old: `46 test-files, 1039 tests`
   New: `50 test-files, 1087 tests`
