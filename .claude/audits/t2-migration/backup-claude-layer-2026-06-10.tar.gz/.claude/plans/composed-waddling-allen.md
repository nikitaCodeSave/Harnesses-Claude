# Спринт: техническое логирование для мониторинга

## Цели

До запуска на реальных пользователей закрыть минимум:
1. **Быстро находить и диагностировать ошибки** — полная цепочка логов с контекстом ошибки
2. **Понимать состояние сервиса по ключевым метрикам** — LLM latency, tokens, pipeline timings
3. **Отслеживать цепочку обработки запроса от входа до ответа** — request_id + структурированные шаги

## Context

Текущее состояние:
- **errors.jsonl** — только ERROR в JSON. INFO/WARNING уходят в stdout текстом и теряются
- **PerfTimer** — замеряет 10+ шагов пайплайна, логирует `[PERF]` на INFO — данные **не персистятся**
- **llm_client** — логирует tokens, latency, op, model, attempt на INFO — данные **теряются**
- **agent.py** — `format_timing_summary()` с полной таблицей — **теряется**
- **request_id** — первый logger.info до set_request_id в zulip_bot.py

**Принцип**: все нужные данные уже логируются на INFO — нужно (1) сохранить их в файл, (2) сделать метрики машиночитаемыми, (3) привязать к request_id от входа.

**Ограничение**: без изменений бизнес-логики (request_tracker, analytics, data/monitoring, agent pipeline). Только слой логирования.

---

## Group 1: Структурированное логирование всех уровней

**Цель 1**: ошибки диагностируемы — полная цепочка логов в JSON файле.

### 1.1. Новые поля в LogSettings

**Файл**: `infrastructure/settings.py` (класс `LogSettings`, строки 149-156)

```python
class LogSettings(BaseModel):
    # ... existing fields ...
    all_file: str = ""                                           # пусто = выключено (opt-in)
    all_file_max_bytes: int = Field(default=52_428_800, ge=1024) # 50 MB
    all_file_backup_count: int = Field(default=5, ge=0, le=100)
```

### 1.2. Обогащение JSONLFormatter

**Файл**: `infrastructure/log_setup.py` (класс `JSONLFormatter`, строки 28-42)

Добавить в JSON-вывод:
- Поля LogRecord для локализации: `module`, `func`, `line`
- Структурированные метрики из `extra`: если LogRecord содержит атрибут `perf` (dict) — включить в JSON

```python
def format(self, record: logging.LogRecord) -> str:
    entry: dict = {
        "ts": datetime.fromtimestamp(record.created, tz=timezone.utc).isoformat(),
        "level": record.levelname,
        "logger": record.name,
        "message": record.getMessage(),
        "request_id": getattr(record, "request_id", "-"),
        "module": record.module,
        "func": record.funcName,
        "line": record.lineno,
    }
    # Структурированные метрики (из extra={"perf": {...}})
    perf = getattr(record, "perf", None)
    if perf is not None:
        entry["perf"] = perf
    # Exception info
    if record.exc_info and record.exc_info[0] is not None:
        entry["exc_type"] = record.exc_info[0].__name__
        entry["traceback"] = "".join(traceback.format_exception(*record.exc_info))
    return json.dumps(entry, ensure_ascii=False)
```

### 1.3. All-level JSONL handler

**Файл**: `infrastructure/log_setup.py` (функция `configure_logging`, после строки 96)

Третий handler по аналогии с error handler:
- `RotatingFileHandler`, level=DEBUG (пропускает всё что прошло root logger)
- `JSONLFormatter` + `RequestIdFilter`
- Конфиг: `all_file` / `all_file_max_bytes` / `all_file_backup_count`
- opt-in: если `all_file` пустой — handler не создаётся

```python
# All-level JSONL handler (opt-in)
all_file = getattr(settings, "all_file", "")
if all_file:
    all_max_bytes = getattr(settings, "all_file_max_bytes", 52_428_800)
    all_backup_count = getattr(settings, "all_file_backup_count", 5)
    dir_name = os.path.dirname(all_file)
    if dir_name:
        os.makedirs(dir_name, exist_ok=True)
    all_handler = RotatingFileHandler(
        all_file,
        maxBytes=all_max_bytes,
        backupCount=all_backup_count,
        encoding="utf-8",
    )
    all_handler.setLevel(logging.DEBUG)
    all_handler.setFormatter(JSONLFormatter())
    all_handler.addFilter(req_filter)
    root.addHandler(all_handler)
```

### 1.4. `.env.example`

В секцию `--- Логирование ---`:
```
# AI_ANALYST_LOG__ALL_FILE=logs/all.jsonl              # все уровни в JSON; пусто = выключено
# AI_ANALYST_LOG__ALL_FILE_MAX_BYTES=52428800           # min: 1024 (50 MB default)
# AI_ANALYST_LOG__ALL_FILE_BACKUP_COUNT=5               # 0-100
```

### Верификация Group 1
- `pytest tests/ -v` — все существующие тесты проходят
- Новые тесты в `tests/infrastructure/test_log_setup.py`:
  - `test_configure_logging_all_file_creates_handler` — handler создаётся при непустом `all_file`
  - `test_configure_logging_all_file_empty_no_handler` — handler НЕ создаётся при пустом `all_file`
  - `test_jsonl_formatter_contains_module_func_line` — новые поля в JSON
  - `test_jsonl_formatter_includes_perf_extra` — `extra={"perf": {...}}` попадает в JSON
  - `test_jsonl_formatter_no_perf_when_absent` — без extra нет ключа `perf`

---

## Group 2: Структурированные метрики в лог-записях

**Цель 2**: метрики сервиса машиночитаемы — `jq '.perf'` вместо regex по тексту.

Механизм: Python logging `extra={"perf": {...}}` добавляет атрибут к LogRecord. JSONLFormatter (Group 1) извлекает его в JSON. Текстовое сообщение для stdout не меняется.

### 2.1. PerfTimer: structured perf field

**Файл**: `infrastructure/perf_timer.py` (строка 41)

Одна строка — добавить `extra`:
```python
# Было:
logger.info("[PERF] %s: %.3fs", self.label, self.elapsed)

# Стало:
logger.info(
    "[PERF] %s: %.3fs", self.label, self.elapsed,
    extra={"perf": {"type": "step", "label": self.label, "elapsed_s": round(self.elapsed, 3)}},
)
```

Результат в all.jsonl:
```json
{"ts":"...","level":"INFO","message":"[PERF] 1_relevance_check: 1.234s","request_id":"abc","perf":{"type":"step","label":"1_relevance_check","elapsed_s":1.234}}
```

### 2.2. llm_client: structured LLM metrics + DRY helper

**Файл**: `infrastructure/llm_client.py`

Сейчас 10 call sites с почти идентичным `logger.info("[PERF] LLM: ...")`. Добавить приватный helper:

```python
def _log_llm_perf(
    elapsed: float,
    operation: str,
    model: str,
    prompt_len: int,
    attempt: int,
    status: str,
    usage: Any = None,
) -> None:
    """Логирует LLM-метрику с текстом для stdout и structured perf для JSONL."""
    perf: dict[str, Any] = {
        "type": "llm",
        "op": operation or "-",
        "model": model,
        "elapsed_s": round(elapsed, 3),
        "prompt_len": prompt_len,
        "attempt": attempt,
        "status": status,
    }
    if usage:
        perf["prompt_tokens"] = usage.prompt_tokens
        perf["completion_tokens"] = usage.completion_tokens
        perf["total_tokens"] = usage.total_tokens
        logger.info(
            "[PERF] LLM: %.3fs (op=%s, model=%s, prompt=%d, attempt=%d, status=%s, "
            "prompt_tokens=%d, completion_tokens=%d, total_tokens=%d)",
            elapsed, operation or "-", model, prompt_len, attempt, status,
            usage.prompt_tokens, usage.completion_tokens, usage.total_tokens,
            extra={"perf": perf},
        )
    else:
        logger.info(
            "[PERF] LLM: %.3fs (op=%s, model=%s, prompt=%d, attempt=%d, status=%s)",
            elapsed, operation or "-", model, prompt_len, attempt, status,
            extra={"perf": perf},
        )
```

Затем заменить все 10 call sites на вызов `_log_llm_perf(...)`. Текстовый вывод в stdout **идентичен** текущему — нет видимых изменений.

Результат в all.jsonl:
```json
{"ts":"...","level":"INFO","message":"[PERF] LLM: 2.345s (op=sql_generation, ...)","request_id":"abc","perf":{"type":"llm","op":"sql_generation","elapsed_s":2.345,"prompt_tokens":1234,"total_tokens":1801,"status":"ok"}}
```

### Верификация Group 2
- `pytest tests/ -v` — все тесты проходят
- Новые тесты:
  - `tests/infrastructure/test_perf_timer.py::test_perf_timer_logs_with_extra` — LogRecord содержит `perf` атрибут
  - `tests/infrastructure/test_llm_client.py::test_log_llm_perf_with_usage` — helper формирует корректный perf dict
  - `tests/infrastructure/test_llm_client.py::test_log_llm_perf_without_usage` — без usage нет token-полей
- Ручная проверка: `python run_agent.py`, один вопрос, `jq 'select(.perf)' logs/all.jsonl` показывает шаги пайплайна и LLM-метрики

---

## Group 3: request_id от точки входа

**Цель 3**: полная цепочка обработки запроса привязана к request_id.

### 3.1. Ранний request_id в Zulip bot

**Файл**: `presentation/zulip_bot.py`

Сейчас порядок (строки 357-378):
```python
logger.info("Получен вопрос от %s: %s", ...)  # <- request_id ещё "-"
...
request_id = f"..."                             # строка 375
logger.info("ID запроса: %s", request_id)       # строка 376
set_request_id(request_id)                       # строка 378
```

Нужно: генерировать request_id и вызывать set_request_id **до первого logger.info**:
```python
request_id = f"{datetime.now().strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex[:8]}_{sender_email.split('@')[0]}"
set_request_id(request_id)
logger.info("Получен вопрос от %s: %s (request_id=%s)", sender_email, question, request_id)
```

### 3.2. CLI — без изменений

CLI не генерирует request_id (dev-режим, один вопрос за раз). Логи с request_id="-". Это нормально.

### Верификация Group 3
- `pytest tests/ -v` — все тесты проходят
- Ручная проверка: `jq 'select(.request_id != "-") | .request_id' logs/all.jsonl | head` — все записи одного запроса с одним ID

---

## Проверка покрытия целей

### Цель 1: Диагностика ошибок

```bash
# Все ошибки за последний час
jq 'select(.level == "ERROR")' logs/all.jsonl

# Полная цепочка для конкретной ошибки (по request_id)
jq 'select(.request_id == "20260324_123456_abc")' logs/all.jsonl

# Hotspot: какие модули падают чаще всего
jq -r 'select(.level == "ERROR") | .module' logs/all.jsonl | sort | uniq -c | sort -rn

# Ошибка с точной локализацией
# {"level":"ERROR","module":"llm_client","func":"call_llm","line":316,"exc_type":"LLMCallError","traceback":"..."}
```

Покрыто: all.jsonl (Group 1) + module/func/line + request_id (Group 3) + exc_type/traceback.

### Цель 2: Метрики сервиса

```bash
# Средняя latency LLM по операциям
jq -r 'select(.perf.type == "llm" and .perf.status == "ok") | [.perf.op, .perf.elapsed_s] | @tsv' logs/all.jsonl

# Суммарные токены за день
jq '[select(.perf.total_tokens) | .perf.total_tokens] | add' logs/all.jsonl

# Тайминги пайплайна
jq -r 'select(.perf.type == "step") | [.perf.label, .perf.elapsed_s] | @tsv' logs/all.jsonl

# Retry и error rate LLM
jq -r 'select(.perf.type == "llm") | .perf.status' logs/all.jsonl | sort | uniq -c
```

Покрыто: structured `perf` field (Group 2) — метрики в JSON полях, не в тексте.

### Цель 3: Цепочка обработки запроса

```bash
# Полный timeline одного запроса (шаги + LLM вызовы + ошибки)
jq 'select(.request_id == "20260324_123456_abc") | {ts, level, module, func, message, perf}' logs/all.jsonl

# Только шаги пайплайна для одного запроса
jq 'select(.request_id == "20260324_123456_abc" and .perf) | {ts: .ts, step: .perf.label, elapsed: .perf.elapsed_s, type: .perf.type}' logs/all.jsonl
```

Покрыто: request_id от входа (Group 3) + хронологический порядок + structured perf steps (Group 2).

---

## Итоговый порядок файлов

| Файл | Group 1 | Group 2 | Group 3 |
|------|---------|---------|---------|
| `infrastructure/settings.py` | LogSettings (3 поля) | — | — |
| `infrastructure/log_setup.py` | JSONLFormatter + all handler | — | — |
| `infrastructure/perf_timer.py` | — | extra perf (1 строка) | — |
| `infrastructure/llm_client.py` | — | _log_llm_perf helper + 10 call sites | — |
| `presentation/zulip_bot.py` | — | — | ранний set_request_id |
| `.env.example` | ALL_FILE секция | — | — |

**Тесты** (новые):
| Файл | Тесты |
|------|-------|
| `tests/infrastructure/test_log_setup.py` | all_file handler create/skip, formatter module/func/line, formatter perf extra |
| `tests/infrastructure/test_perf_timer.py` | perf extra в LogRecord |
| `tests/infrastructure/test_llm_client.py` | _log_llm_perf с/без usage |

**НЕ меняются** (вне скоупа):
- `infrastructure/request_tracker.py` — бизнес-данные
- `infrastructure/analytics.py` — Excel-отчёты
- `application/agent.py` — пайплайн
- `application/subquestion.py` — подвопросы
- `infrastructure/log_context.py` — без новых ContextVar

## Постобработка
- `docs/configuration.md` — новые log settings (3 параметра)
- `devlog/changelog.json` — одна запись
- Ручной smoke-test: `python run_agent.py` + `jq 'select(.perf)' logs/all.jsonl`
