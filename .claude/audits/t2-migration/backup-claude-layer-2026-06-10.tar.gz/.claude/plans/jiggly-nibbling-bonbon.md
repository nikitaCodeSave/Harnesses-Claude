# Финальная проверка миграции: остатки old_cli / RUN_DATE / aggregation_per_day / aggregation_between_days / ID_I

## Контекст

Пункт 14 из research-документа миграции: grep по всему проекту (исключая tests/, dev/, new_prompts_and_metadata/) на остатки старых имён. Проверка показала, что .txt файлы чистые, но в .py файлах есть остатки, которые нужно классифицировать: одни — баги миграции, другие — допустимые (dev-инфра, тесты, variable names).

> Фаза 0 пропущена: задача — аудит/замена остатков, не изменение поведения. Baseline — результаты grep.

---

## Результаты grep (исключая tests/, dev/, new_prompts_and_metadata/)

### 1. `all_cli` в production-коде (.py, кроме tests/dev/new_prompts)

| Файл:строка | Контекст | Действие |
|---|---|---|
| `infrastructure/metadata.py:489` | `def get_table_metadata(table_name: str = "all_cli")` | **Заменить** дефолт на `"client_product"` |
| `infrastructure/metadata.py:491` | `if table_name in ("all_cli", "client_product"):` | **Убрать** `"all_cli"` — оставить `== "client_product"` |
| `infrastructure/metadata.py:496` | `def get_sql_examples(table_name: str = "all_cli")` | **Заменить** дефолт на `"client_product"` |
| `core/analysis/relevance_checker.py:150` | `def get_keywords_from_metadata(table_name: str = "all_cli")` | **Заменить** дефолт на `"client_product"` |
| `core/analysis/relevance_checker.py:234` | docstring: `"к таблице all_cli"` | **Заменить** на `"к таблице client_product"` |
| `core/sql/field_search.py:160` | `def get_key_fields(table_name: str = "all_cli")` | **Заменить** дефолт на `"client_product"` |
| `core/output/response_generator.py:283` | `def get_field_descriptions(fields, table_name: str = "all_cli")` | **Заменить** дефолт на `"client_product"` |

### 2. `RUN_DATE` в production-коде

| Файл:строка | Контекст | Действие |
|---|---|---|
| `core/output/response_generator.py:43` | `"RUN_DATE"` в `date_keywords` | **Оставить** — это эвристика для определения дата-колонок, RUN_DATE может встретиться в данных других таблиц; MONTH_DT уже добавлен (строка 45) |

### 3. `aggregation_per_day` / `aggregation_between_days` в production-коде

| Файл:строка | Контекст | Действие |
|---|---|---|
| `core/sql/field_search.py:214` | `aggregation_per_day = field_info.get("aggregation_between_clients", ...)` | **Переименовать** переменную: `aggregation_per_day` → `aggregation_between_clients` |
| `core/sql/field_search.py:215` | `aggregation_between_days = field_info.get("aggregation_between_month", ...)` | **Переименовать** переменную: `aggregation_between_days` → `aggregation_between_month` |
| `core/sql/field_search.py:228-233` | использование переименованных переменных | **Обновить** все ссылки на новые имена |

### 4. `ID_I` в production-коде

Не найдено (только в dev/generate_seed.py — excluded).

### 5. Файлы в excluded-зонах (tests/, dev/, new_prompts_and_metadata/) — **НЕ трогаем**

- `tests/test_integration_connection.py:28,33,47-48` — тесты integration, имена методов `test_all_cli_*` и `RUN_DATE` в SQL. TABLE_NAME уже динамический (строка 14), но **имена тестов** и **hardcoded SQL-колонки** (RUN_DATE, PNL_SUM) устарели. Это отдельная задача для integration-тестов.
- `dev/test-connection.py:73` — `RUN_DATE` в примере запроса. Dev-инфра, отложено.
- `dev/generate_seed.py` — всё про all_cli. Dev-инфра, отложено.
- `new_prompts_and_metadata/metadata.py` — reference-файл, не production.

---

## План реализации

### Task 1: Обновить дефолты и docstrings — замена `"all_cli"` → `"client_product"`
**Files:** `infrastructure/metadata.py`, `core/analysis/relevance_checker.py`, `core/sql/field_search.py`, `core/output/response_generator.py`
**Depends on:** none
**Изменения:**
  - `metadata.py:489` — дефолт `"all_cli"` → `"client_product"`
  - `metadata.py:491` — `if table_name in ("all_cli", "client_product"):` → `if table_name == "client_product":`
  - `metadata.py:496` — дефолт `"all_cli"` → `"client_product"`
  - `relevance_checker.py:150` — дефолт `"all_cli"` → `"client_product"`
  - `relevance_checker.py:234` — docstring `"all_cli"` → `"client_product"`
  - `field_search.py:160` — дефолт `"all_cli"` → `"client_product"`
  - `response_generator.py:283` — дефолт `"all_cli"` → `"client_product"`
**Test:** `pytest tests/ -v` — убедиться что тесты не сломались
**Done when:** Нет ни одного `"all_cli"` дефолта в production-коде

### Task 2: Переименовать переменные `aggregation_per_day` / `aggregation_between_days` в field_search.py
**Files:** `core/sql/field_search.py`
**Depends on:** none

**Анализ логики (верификация корректности):**
Функция `get_relevant_fields_description()` (строки 180-242) формирует текстовое описание полей для LLM-промпта.
- Строка 214: `aggregation_per_day = field_info.get("aggregation_between_clients", "N/A")` — **ключ `.get()` уже правильный**, читает `aggregation_between_clients` из новой metadata. Переменная названа по-старому.
- Строка 215: `aggregation_between_days = field_info.get("aggregation_between_month", "N/A")` — **аналогично, ключ правильный**.
- Строки 231, 233: output-строки `aggregation_between_clients: {value}` и `aggregation_between_month: {value}` — **корректно** передают новые имена в промпт LLM.
- Пример из metadata: `CA_LCY_SUM` → `aggregation_between_clients: "SUM"`, `aggregation_between_month: "AVG"` — функция корректно выведет `[АГРЕГАЦИЯ: aggregation_between_clients: SUM, aggregation_between_month: AVG]`.

**Вывод:** логика функции корректна для новой таблицы. Замена — чисто косметическая (имена переменных не соответствуют ключам, что ухудшает читаемость).

**Изменения:**
  - Строки 214-233: переименовать переменные `aggregation_per_day` → `aggregation_between_clients`, `aggregation_between_days` → `aggregation_between_month`
  - Это внутренние переменные (не экспортируемые), функциональное поведение не меняется
**Test:** `pytest tests/core/sql/test_field_search.py -v`
**Done when:** Нет `aggregation_per_day` / `aggregation_between_days` в field_search.py

### Task 3: Прогнать тесты + devlog
**Files:** `devlog/changelog.json`
**Depends on:** Task 1, Task 2
**Test:** `pytest tests/ -v` — полный прогон unit-тестов
**Done when:** Все тесты зелёные, devlog обновлён

---

## Оценка рисков

| Сценарий сбоя | Вероятность | Воздействие | Действие |
|---|---|---|---|
| Тесты, вызывающие `get_table_metadata("all_cli")` — сломаются | medium | тесты | Обновить тесты: заменить `"all_cli"` → `"client_product"` в вызовах |
| Переименование переменных — опечатка | low | field_search | pytest test_field_search.py поймает |

## Что НЕ входит в scope (осознанно)

- `tests/` — отдельная задача (имена integration-тестов, hardcoded SQL-колонки)
- `dev/` — dev-инфра, отложено по research-документу
- `new_prompts_and_metadata/` — reference-файлы
- `RUN_DATE` в `response_generator.py:43` date_keywords — оставляем для обратной совместимости

## Масштаб

- 4 файла production-кода
- ~12 точечных замен (7 дефолтов/docstrings + 5 переименований переменных)
- Выполнение: последовательно, Tasks 1 и 2 параллельны, Task 3 после обоих
