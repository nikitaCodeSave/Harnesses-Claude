# План: детерминированный fix ORA-00904 для подзапросов (A + C)

## Контекст

**Проблема:** На проде SQL-генератор (Qwen3-30B) создал запрос с `FROM (...) p1 JOIN (...) p2`,
где подзапрос p2 определяет алиас `february_balance`, но outer SELECT ссылается на `p2.feb_balance`.
Oracle выдаёт ORA-00904. LLM-валидатор 3 раза вернул идентичный SQL — не смог исправить.

**Три уровня защиты не сработали:**

1. `validate_subquery_alias_mismatch` — regex `FROM\s*\(` не ловит `JOIN (`;
   даже если бы ловил, функция обрабатывает только BASE_COL→ALIAS, а не WRONG_ALIAS→CORRECT_ALIAS
2. LLM fixer — ORA-00904 не обогащается доступными колонками; Qwen3-30B не видит расхождение
3. Промпт `sql_fix.txt` — ORA-00904 описан только для HAVING/ORDER BY

**Цель:** Два детерминированных fix-а, 0 LLM-вызовов, работают до DB-валидации.

---

## Fix C: расширить regex на JOIN-подзапросы

### Файл: `core/sql/validator.py`

**Изменение 1 — regex** (строка 207-210):

```python
# Было:
_FROM_SUBQUERY_RE = re.compile(r"""\bFROM\s*\(""", re.IGNORECASE)

# Стало:
_SUBQUERY_SOURCE_RE = re.compile(
    r"""\b(?:FROM|(?:(?:LEFT|RIGHT|FULL|INNER|CROSS|NATURAL)\s+(?:OUTER\s+)?)?JOIN)\s*\(""",
    re.IGNORECASE,
)
```

Покрывает все Oracle JOIN-типы: `JOIN`, `LEFT JOIN`, `LEFT OUTER JOIN`,
`RIGHT JOIN`, `INNER JOIN`, `FULL OUTER JOIN`, `CROSS JOIN`, `NATURAL JOIN`.

Regex всегда заканчивается на `\(`, поэтому `m.end() - 1` по-прежнему даёт позицию `(`.

**Изменение 2 — обновить ссылки** (строка 333 в `validate_subquery_alias_mismatch`):

Заменить `_FROM_SUBQUERY_RE` → `_SUBQUERY_SOURCE_RE` в `validate_subquery_alias_mismatch`.

**Риски:** Минимальные. Функция уже обрабатывает subquery alias (`p1`, `p2`)
и depth-aware логику. JOIN-подзапросы структурно идентичны FROM-подзапросам.

---

## Fix A: валидация ссылок на колонки подзапросов

### Файл: `core/sql/validator.py`

Новая функция `validate_subquery_column_refs(sql) -> tuple[str, bool]`.

### Алгоритм

**Шаг 1.** Найти все подзапросы (FROM + JOIN) на depth=0 через `_SUBQUERY_SOURCE_RE`.
Для каждого извлечь:
- inner SQL (между скобками)
- table alias подзапроса (`p1`, `p2`, `t`, ...)

**Шаг 2.** Для каждого подзапроса извлечь **все** output-колонки (новая функция `_extract_subquery_output_columns`):

```sql
SELECT MANAGER_NAME, DESK, SUM(CA_LCY_SUM) AS february_balance
```
→ `{MANAGER_NAME, DESK, FEBRUARY_BALANCE}`

Логика:
- Depth-aware comma-split SELECT-clause (переиспользовать паттерн из `_enrich_group_by_error`, строки 538-547)
- Для каждого expression:
  - `... AS alias` → alias
  - Bare identifier / `table.identifier` → identifier
  - Expression без AS (например `SUM(x)`) → пропустить (неадресуемо по имени)

**Шаг 3.** Найти все table-qualified ссылки в outer query: `<subq_alias>.<col>`.
Regex: для каждого найденного subquery alias строить `\b<alias>\s*\.\s*(\w+)\b`.

Обрабатывать только ссылки на depth=0 (не внутри других подзапросов).
Пропускать ссылки внутри строковых литералов (mask).

**Шаг 4.** Для каждой ссылки `alias.col`: проверить, есть ли `col` (upper) в output columns.
Если нет — найти closest match:

1. Exact match (case-insensitive) → ok, пропустить
2. Единственная колонка, которая содержит `col` как подстроку (или наоборот) → match
3. Несколько кандидатов или 0 → **не фиксить** (консервативно, оставить для LLM)

**Шаг 5.** Применить замены в обратном порядке (паттерн из `_replace_column_refs`).

### Точка вставки в pipeline

`validate_and_fix_sql`, строка 1200-1206 — **после** `validate_subquery_alias_mismatch`,
**перед** `_deduplicate_select_aliases`:

```python
sql, alias_modified = validate_subquery_alias_mismatch(sql)           # существующий
sql, colref_modified = validate_subquery_column_refs(sql)              # НОВЫЙ
sql, dedup_modified = _deduplicate_select_aliases(sql)                 # существующий
```

Порядок важен: сначала BASE_COL→ALIAS fix (C), потом WRONG_ALIAS→CORRECT_ALIAS fix (A),
потом dedup.

### Переиспользуемые функции

| Функция | Строка | Что берём |
|---|---|---|
| `_SUBQUERY_SOURCE_RE` (новый regex) | 207 | Поиск FROM/JOIN подзапросов |
| `_find_matching_paren` | 213 | Найти закрывающую скобку подзапроса |
| `_mask_string_literals` | 180 | Игнорировать строковые литералы |
| `_compute_effective_depth` | 85 | Depth-aware разбор |
| Comma-split паттерн | 538-547 | Разбиение SELECT на expressions |

### Ограничения (осознанные)

- Обрабатывает только **table-qualified** ссылки (`p2.col`) — bare ссылки (`col`) амбигуозны
- Не обрабатывает CTE (`WITH x AS (...) SELECT x.col`) — другой паттерн
- `SELECT *` в подзапросе → не извлекаем колонки (не знаем схему) → пропускаем
- Fuzzy match только по substring containment — не по Levenshtein (нет зависимости)
- При >1 кандидате — не фиксим (лучше false negative, чем false positive)

---

## Тесты

### Файл: `tests/core/sql/test_validator.py`

### Fix C: тесты для JOIN-подзапросов в `validate_subquery_alias_mismatch`

1. **Обновить** `test_join_subquery_not_matched` (строка 1651) → `test_join_subquery_base_col_fixed`:
   переписать SQL чтобы outer ссылался на BASE_COL, assert `modified is True`

2. **Добавить:** `test_left_join_subquery_base_col_fixed` — LEFT JOIN вариант

3. **Добавить:** `test_from_plus_join_both_fixed` — FROM(...) p1 JOIN(...) p2,
   обе ветки с BASE_COL→ALIAS mismatch

4. **Обновить** `test_left_join_two_subqueries` (строка 1395) — уже тестирует
   FROM+JOIN без mismatch, поведение не должно измениться (по-прежнему `modified is False`,
   т.к. алиасы совпадают)

### Fix A: тесты для `validate_subquery_column_refs`

5. **Production case:** SQL из лога (`p2.feb_balance` → `p2.february_balance`)
6. **No mismatch:** Все ссылки валидны → `modified is False`
7. **Multiple candidates:** `p2.bal` при доступных `balance_rub` и `balance_ccy` → не фиксить
8. **Zero candidates:** Совсем нет похожих колонок → не фиксить
9. **Multiple subqueries:** FROM(...) p1 JOIN(...) p2 — fix только в нужном подзапросе
10. **Bare reference (no table alias):** `feb_balance` без `p2.` → пропустить
11. **Nested subquery refs:** ссылки на depth>0 → не трогать

### `_extract_subquery_output_columns`:

12. **Bare columns:** `SELECT A, B FROM t` → `{A, B}`
13. **AS aliases:** `SELECT SUM(x) AS total, y AS name` → `{TOTAL, NAME}`
14. **Mixed:** `SELECT A, SUM(B) AS sum_b, C AS d` → `{A, SUM_B, D}`
   Нет — expression без AS (`SUM(B)`) → `{A, SUM_B, D}`. Wait, `SUM(B)` без AS → пропустить.
   `{A, D}` + `sum_b` из AS.
   Итого: `{A, SUM_B, D}` ← нет, A — bare, SUM(B) AS sum_b → sum_b, C AS d → d.
   Ответ: `{A, SUM_B, D}`
15. **Expression without AS:** `SELECT SUM(x)` → `set()` (не извлекаем)
16. **SELECT * in subquery:** → пустое множество (консервативно)

---

## Fix B (fallback): обогащение ORA-00904 + доработка промпта

Для случаев, которые детерминированный fix не покрыл (0 кандидатов, >1 кандидат,
bare refs, CTE), кейс уходит в LLM. Нужно дать модели достаточно контекста.

### B1: Обогащение ошибки (`_enrich_ora00904_error`)

**Файл:** `core/sql/validator.py`

Новая функция `_enrich_ora00904_error(sql, error_message) -> str`.

Алгоритм:
1. Проверить `"ORA-00904"` в `error_message` — иначе вернуть без изменений
2. Извлечь invalid identifier из ошибки:
   - Regex: `"(\w+)".*invalid identifier` (Oracle формат `"P2"."FEB_BALANCE"`)
   - Также извлечь table alias если есть (qualifier перед точкой)
3. Найти подзапрос по table alias через `_SUBQUERY_SOURCE_RE`
4. Извлечь доступные колонки через `_extract_subquery_output_columns`
5. Сформировать enriched message:

```
Ошибка синтаксиса SQL: ORA-00904: "P2"."FEB_BALANCE": invalid identifier
Колонка FEB_BALANCE не существует в подзапросе P2.
Доступные колонки P2: MANAGER_NAME, DESK, FEBRUARY_BALANCE.
Исправление: замени P2.FEB_BALANCE на корректное имя колонки из списка выше.
```

Точка вставки — `validate_and_fix_sql`, строка 1214-1216 (рядом с `_enrich_group_by_error`):

```python
if error_message:
    error_message = _enrich_group_by_error(sql, error_message)
    error_message = _enrich_ora00904_error(sql, error_message)  # НОВЫЙ
```

### B2: Доработка промпта `sql_fix.txt`

**Файл:** `core/sql/prompts/v1/sql_fix.txt`, секция 5

Добавить новый блок после `ORA-00904 в ORDER BY:`:

```
ORA-00904 (invalid identifier) в ссылках на подзапросы:
- Если ошибка указывает на колонку через алиас подзапроса (например P2.FEB_BALANCE):
  - Проверь определение подзапроса P2 — какие алиасы он определяет через AS.
  - Замени неверное имя на правильный алиас из внутреннего SELECT подзапроса.
  - Проверь ВСЕ ссылки на этот алиас во всём внешнем запросе (SELECT, WHERE, ON, ORDER BY).
  Пример:
  - Подзапрос: SELECT SUM(CA_LCY_SUM) AS february_balance FROM ... GROUP BY ...
  - Было (outer): p2.feb_balance
  - Стало (outer): p2.february_balance
```

### Тесты для B1

17. **Enrichment:** SQL с `p2.feb_balance`, error `ORA-00904: "P2"."FEB_BALANCE"` →
    enriched содержит `Доступные колонки P2:` и `FEBRUARY_BALANCE`
18. **Non-ORA-00904:** error `ORA-00937` → возвращает без изменений
19. **No subquery match:** invalid identifier не привязан к подзапросу → без изменений

---

## Порядок реализации

### Этап 1: Fix C (regex + тесты)
1. Расширить regex `_FROM_SUBQUERY_RE` → `_SUBQUERY_SOURCE_RE`
2. Обновить ссылки на regex в `validate_subquery_alias_mismatch`
3. Написать тесты для Fix C (п. 1-4)
4. `pytest tests/core/sql/test_validator.py -v` → green

### Этап 2: Fix A (детерминированный column ref fix + тесты)
5. Написать `_extract_subquery_output_columns`
6. Написать `validate_subquery_column_refs`
7. Вставить вызов в `validate_and_fix_sql`
8. Написать тесты для Fix A (п. 5-16)
9. `pytest tests/core/sql/test_validator.py -v` → green

### Этап 3: Fix B (LLM fallback: enrichment + промпт)
10. Написать `_enrich_ora00904_error`
11. Вставить вызов в `validate_and_fix_sql` (рядом с `_enrich_group_by_error`)
12. Добавить блок в `sql_fix.txt` секция 5
13. Написать тесты для B1 (п. 17-19)
14. `pytest tests/core/sql/test_validator.py -v` → green

### Этап 4: Финальная проверка
15. `pytest tests/ -v` → нет регрессий
16. `ruff check core/sql/validator.py` → clean
17. Логирование для всех новых fix-ов

## Верификация

1. `pytest tests/core/sql/test_validator.py -v` → все тесты pass (включая новые ~19 тестов)
2. `pytest tests/ -v` → нет регрессий в других модулях
3. `ruff check core/sql/validator.py core/sql/prompts/v1/sql_fix.txt` → clean
4. Ручная проверка: подставить SQL из прод-лога в тест → fix работает
5. Проверить что `test_left_join_two_subqueries` (строка 1395) по-прежнему `modified is False`
