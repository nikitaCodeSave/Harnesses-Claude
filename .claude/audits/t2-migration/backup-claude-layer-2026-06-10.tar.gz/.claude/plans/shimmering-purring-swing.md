# Усиление защиты от вложенных агрегатов (ORA-00937)

## Контекст

На рабочей базе LLM сгенерировал `AVG(SUM(CA_LCY_RUB_SUM))` вместо subquery-паттерна. Oracle вернул ORA-00937. Промпт генератора содержит правильные примеры с subquery, но нет явного анти-паттерна и нет проверки в self-check. Промпт фиксера не содержит обработки ORA-00937.

## Изменения

### 1. system.txt — анти-паттерн + self-check

**Файл:** `core/sql/prompts/v1/system.txt`

**A)** После строки 280 (конец секции 3.3 "With extra dimensions") добавить блок:

```
🔴 NESTED AGGREGATES — ABSOLUTELY FORBIDDEN
NEVER write nested aggregate functions in a single SELECT level:
❌ AVG(SUM(field)), SUM(COUNT(field)), MAX(AVG(field)), etc.
Nested aggregates cause ORA-00937 and are ALWAYS wrong.
✅ ALWAYS use a subquery (see patterns 3.1, 3.2, 3.3 above).
```

**B)** В секции "General self-check (MANDATORY)" (строки 470-477) добавить пункт:

```
• Check for nested aggregate functions: AVG(SUM(...)), SUM(COUNT(...)), etc.
  – If found, REWRITE using a subquery (patterns 3.1 / 3.2 / 3.3).
```

### 2. validator.py — ORA-00937 в промпте фиксера

**Файл:** `core/sql/validator.py`

В функции `fix_sql_with_llm`, секция "5. ОСОБЫЕ СЛУЧАИ ОШИБОК" (после строки 649), добавить блок:

```
ORA-00937 (not a single-group group function):
- Вложенные агрегаты AVG(SUM(x)), SUM(COUNT(x)) с GROUP BY создают конфликт:
  внутренний агрегат работает по группам, внешний схлопывает всё в одну строку,
  но GROUP BY-выражение в SELECT требует множества строк.
- РЕШЕНИЕ: вынести внутренний агрегат в подзапрос.
- Было (НЕПРАВИЛЬНО):
  SELECT TO_CHAR(MONTH_DT, 'YYYY-MM') AS month, AVG(SUM(CA_LCY_SUM)) AS avg_balance
  FROM client_product WHERE ... GROUP BY TO_CHAR(MONTH_DT, 'YYYY-MM')
- Стало (ПРАВИЛЬНО):
  SELECT TO_CHAR(MONTH_DT, 'YYYY-MM') AS month, AVG(monthly_value) AS avg_balance
  FROM (SELECT MONTH_DT, SUM(CA_LCY_SUM) AS monthly_value FROM client_product WHERE ... GROUP BY MONTH_DT) t
  GROUP BY TO_CHAR(MONTH_DT, 'YYYY-MM') ORDER BY month
```

### 3. Тест

**Файл:** `tests/core/sql/test_validator.py`

Добавить тест `test_ora00937_nested_aggregates_fixed_by_llm` в `TestValidateAndFixSql` — аналогично существующему `test_invalid_sql_with_db_calls_llm_for_fix`, но с ORA-00937 ошибкой и проверкой что LLM вызывается с правильным контекстом ошибки.

## Верификация

1. `pytest tests/core/sql/test_validator.py -v` — все тесты проходят
2. `pytest tests/ -v` — нет регрессий
