Генерация реалистичных банковских данных для dev-окружения Oracle.

Цель: 100 компаний × 12 месяцев = ~1200 строк в таблице `client_product`.
Каждый запуск создаёт батч из ~10 компаний (120 строк). Запускай повторно до достижения цели.

## Режим строгого выполнения (обязательно)

- Используй только один генератор: `python dev/generate_seed.py`.
- Запрещено создавать ad-hoc скрипты в `dev/` (`gen_seed_batch*.py`, `tmp_*.py`, и т.п.).
- Разрешённый постоянный артефакт в `dev/` после выполнения команды: только `dev/seed-progress.md`.
- `dev/seed_batch*.sql` допускается только как временный файл на время загрузки; после успешной загрузки файл нужно удалить.
- Любой `ORA-`, `SP2-` или `ERROR` в выводе `sqlplus` означает `FAILED` (нельзя писать `PASSED`).

---

## Шаг 1: Проверка состояния

Прочитай `infrastructure/metadata.py` для понимания полей и `dev/setup-oracle.sql` для формата INSERT.

Проверь и очисти артефакты прошлых запусков перед началом:

```bash
# Ad-hoc .py не должны оставаться в dev/
rm -f dev/gen_seed_batch*.py

# Старые батч-файлы удаляем, чтобы не перепутать загрузку текущего батча
rm -f dev/seed_batch*.sql
```

Выполни SQL-запросы для определения текущего состояния:

```bash
# Прогресс: считаем ТОЛЬКО новые компании (без базовых 3)
docker exec ai-analyst-oracle bash -c "echo '
SELECT COUNT(DISTINCT CUSTOMER_ID) AS new_companies, COUNT(*) AS new_rows
FROM client_product WHERE CUSTOMER_ID NOT IN (958255038908, 958297637798, 958475926468);
' | sqlplus -s dev_user/dev_password@//localhost:1521/XEPDB1"
```

```bash
# Распределение по сегментам (только новые)
docker exec ai-analyst-oracle bash -c "echo '
SELECT SEG, COUNT(DISTINCT CUSTOMER_ID) AS cnt
FROM client_product WHERE CUSTOMER_ID NOT IN (958255038908, 958297637798, 958475926468)
GROUP BY SEG ORDER BY cnt DESC;
' | sqlplus -s dev_user/dev_password@//localhost:1521/XEPDB1"
```

```bash
# Покрытие дэсков (только новые)
docker exec ai-analyst-oracle bash -c "echo '
SELECT DESK, COUNT(DISTINCT CUSTOMER_ID) AS cnt
FROM client_product WHERE CUSTOMER_ID NOT IN (958255038908, 958297637798, 958475926468)
GROUP BY DESK ORDER BY cnt DESC;
' | sqlplus -s dev_user/dev_password@//localhost:1521/XEPDB1"
```

```bash
# Следующий CUSTOMER_ID
docker exec ai-analyst-oracle bash -c "echo '
SELECT MAX(CUSTOMER_ID) FROM client_product;
' | sqlplus -s dev_user/dev_password@//localhost:1521/XEPDB1"
```

Также проверь `dev/seed-progress.md` если он существует — там сводка прошлых сессий.

**Если новых компаний >= 100 → СТОП. Датасет полон. Сообщи пользователю.**

---

## Шаг 2: Планирование батча

### Целевое распределение (100 новых компаний)

| Сегмент (SEG) | Цель | DESK |
|---------------|------|------|
| Large | 10 | Large 1 |
| Middle | 20 | Middle 1 |
| International | 25 | International 1, International 2 |
| SME | 25 | Region 1 |
| FI | 5 | FI |
| Region | 15 | Region 1 |

### HUB'ы

| HUB | Типичные сегменты |
|-----|-------------------|
| Москва | Large, International, FI, Middle |
| HUB NORTH-WEST | Middle, International, SME |
| HUB SIBERIA | Middle, SME, Region |
| HUB SOUTH | Middle, SME, Region |
| HUB URAL | Middle, SME, Region |
| HUB VOLGA | Middle, SME, Region |

### DESK'и

Region 1, International 1, International 2, Middle 1, FI, Large 1

На основе текущего распределения из Шага 1, определи какие сегменты и дэски **недопредставлены** и выбери ~10 компаний для этого батча, чтобы равномерно закрывать цели.

---

## Шаг 3: Генерация данных

Для каждой компании генерируй 12 INSERT'ов — по одному на каждый месяц: **июль 2024 — июнь 2025** (MONTH_DT = последний день месяца).

### Обязательный способ генерации

Генерируй батч только через каноничный скрипт:

```bash
# Проверка плана батча (без генерации файла)
python dev/generate_seed.py --dry-run

# Генерация батча
python dev/generate_seed.py
```

Запрещено писать новый Python-скрипт для батча вручную.

### Справочники

#### Сегменты (SEG) — английские значения:
International, Middle, Large, SME, FI, Region

#### Менеджеры (MANAGER_NAME — UPPERCASE кириллица):

| Полное ФИО |
|------------|
| ИВАНОВ ПЕТР СЕРГЕЕВИЧ |
| СМИРНОВА ЕЛЕНА ВИКТОРОВНА |
| КОЗЛОВА АННА ДМИТРИЕВНА |
| ПЕТРОВА ОЛЬГА АЛЕКСАНДРОВНА |
| СЕРГЕЕВ ДМИТРИЙ НИКОЛАЕВИЧ |
| МИХАЙЛОВА НАТАЛЬЯ ИГОРЕВНА |
| АЛЕКСЕЕВ АНДРЕЙ ВЛАДИМИРОВИЧ |
| ВАСИЛЬЕВА МАРИЯ ПЕТРОВНА |
| НИКОЛАЕВ ИГОРЬ СЕРГЕЕВИЧ |
| ФЁДОРОВА ТАТЬЯНА АНДРЕЕВНА |
| МОРОЗОВ СЕРГЕЙ ВИТАЛЬЕВИЧ |
| КУЗНЕЦОВА ЮЛИЯ ОЛЕГОВНА |
| ПОПОВ АЛЕКСЕЙ МИХАЙЛОВИЧ |
| СОКОЛОВА ИРИНА ВЛАДИМИРОВНА |
| ЛЕБЕДЕВ ВИКТОР АЛЕКСАНДРОВИЧ |
| НОВИКОВА ЕКАТЕРИНА СЕРГЕЕВНА |
| ВОЛКОВ МАКСИМ ДМИТРИЕВИЧ |
| ЗАЙЦЕВА АНАСТАСИЯ НИКОЛАЕВНА |
| ОРЛОВ ПАВЕЛ ИГОРЕВИЧ |
| БЕЛОВА СВЕТЛАНА ПЕТРОВНА |

#### Группы компаний (для GROUP_NM):
ГК ШНАЙДЕР ГРУПП, ПРОМЫШЛЕННАЯ ГРУППА УРАЛ, ИНВЕСТКАПИТАЛ, ТЕХНОГРУПП, ЛОГИСТИКПАРТНЕР, АГРОХОЛДИНГ ЮГ, ЭНЕРГОАЛЬЯНС, ФАРМАГРУПП, СТРОЙИНДУСТРИЯ, МЕТАЛЛТРЕЙД, ГРУППА АЛЬФА, ТОРГОВЫЙ ДОМ ВОСТОК, ИТ КЛАСТЕР, ТРАНСАЛЬЯНС, ФУДИНДУСТРИЯ

Несколько компаний (2-4) могут иметь одну GROUP_NM. SME и Region — GROUP_NM обычно NULL.

### Формат данных

- **CUSTOMER_ID**: 12-значное число (NUMBER), например 958300001234
- **INN**: 10-значное число (NUMBER), например 7705915440
- **MONTH_DT**: последний день месяца — TO_DATE('2024-11-30', 'YYYY-MM-DD')
- **SEG**: английские значения — International, Middle, Large, SME, FI, Region
- **MANAGER_NAME**: UPPERCASE кириллица — ДАВЫДОВА ДАРЬЯ ВЛАДИМИРОВНА
- **CLOSE_DT**: NULL для большинства клиентов, дата для 5-10% закрытых

### Масштабы по сегментам

| Параметр | Large | Middle | International | SME | FI | Region |
|----------|-------|--------|---------------|-----|----|--------|
| CA_LCY_SUM | 150-800M | 10-50M | 5-80M | 0.5-10M | 50-500M | 1-20M |
| DEP_SUM | 100-600M | 20-100M | 10-200M | 0.5-15M | 100-800M | 2-30M |
| FX_VOLUME_RUB | 100-600M | 20-100M | 30-200M | 0.5-15M | 50-300M | 1-20M |
| VED_VOL | 40-200M | 10-60M | 20-150M | 0.5-8M | 20-100M | 1-15M |
| PNL_SUM | 1-5M | 50-500K | 100K-1M | 10-100K | 500K-3M | 20-200K |

### Флаги по сегментам (вероятности)

| Флаг | Large | Middle | International | SME | FI | Region |
|------|-------|--------|---------------|-----|----|--------|
| has_fx | 90% | 70% | 85% | 30% | 95% | 40% |
| has_deposits | 80% | 60% | 70% | 35% | 90% | 45% |
| has_ved | 85% | 60% | 80% | 25% | 50% | 35% |

### Тренды (выбирай разнообразно для каждой компании)

- **growth** (+3-5%/мес): стартап, растущий бизнес
- **decline** (-2-4%/мес): компания в трудностях
- **stable** (±8-10% шум): устоявшийся бизнес
- **seasonal** (пик в октябре-декабре, спад в январе-марте)

### Правила композиции доходов

**PNL_SUM = PL_CA + PL_DEP + PL_VK + PL_VK_OUT + VED_SUM + FX_MARGIN_RUB + прочий доход**

Компоненты:
- PL_CA = CA_LCY_SUM × (0.03-0.08) / 365
- PL_DEP = DEP_SUM × (0.01-0.02) / 365 (0 если нет депозитов)
- PL_VK = VED_VOL × (0.0005-0.0015) (0 если нет ВЭД)
- PL_VK_OUT = PL_VK × (0.2-0.5)
- VED_SUM = VED_VOL × (0.001-0.005) (доход от ВЭД)
- FX_MARGIN_RUB = FX_EUR_MARGIN_RUB + FX_CNY_MARGIN_RUB + маржа по другим валютам

### Формат INSERT

Используй ТОЧНО тот же порядок колонок, что в `dev/setup-oracle.sql`:

```sql
INSERT INTO client_product (
    MONTH_DT, CREATE_DT, CLOSE_DT,
    CUSTOMER_ID, INN, ORGANIZATION_NM, GROUP_NM, SEG,
    DESK, HUB, MANAGER_NAME,
    CA_LCY_SUM, CA_LCY_RUB_SUM, DEP_SUM,
    FX_VOLUME_RUB, FX_CNT, FX_MARGIN_RUB,
    FX_EUR_MARGIN_RUB, FX_EUR_VOLUME_RUB, FX_EUR_CNT,
    FX_CNY_MARGIN_RUB, FX_CNY_VOLUME_RUB, FX_CNY_CNT,
    PNL_SUM, PL_CA, PL_DEP, PL_VK, PL_VK_OUT, VED_SUM,
    VED_VOL, SALARY_PROJECT,
    ACT_1M, ACT_3M, PREV_ACT_1M, PREV_ACT_3M
) VALUES (
    TO_DATE('2024-11-30','YYYY-MM-DD'), TO_DATE('2020-01-15','YYYY-MM-DD'), NULL,
    958300001234, 7705915440, 'ООО "ПРИМЕР"', 'ГРУППА АЛЬФА', 'Middle',
    'Сафронов А.', 'Москва', 'ИВАНОВ ПЕТР СЕРГЕЕВИЧ',
    ... числовые значения через запятую ...
);
```

**Все суммы — NUMBER без ограничения precision (как в prod). Количества — целые.**

---

## Шаг 4: Загрузка в Oracle

Загрузи в Oracle только последний сгенерированный батч и очисти временный SQL-файл:

```bash
# Найти текущий батч
BATCH_SQL=$(ls -1t dev/seed_batch*.sql | head -n1)
[ -n "$BATCH_SQL" ] || { echo "ERROR: seed_batch*.sql не найден"; exit 1; }

# Загрузить батч
docker exec -i ai-analyst-oracle bash -c "
NLS_LANG=AMERICAN_AMERICA.AL32UTF8 sqlplus -s dev_user/dev_password@//localhost:1521/XEPDB1
" < "$BATCH_SQL"

# Удалить временный SQL-файл только после успешной загрузки
[ $? -eq 0 ] && rm -f "$BATCH_SQL"
```

---

## Шаг 5: Верификация

После загрузки выполни проверки:

```bash
# Прогресс после загрузки (без базовых клиентов)
docker exec ai-analyst-oracle bash -c "echo '
SELECT COUNT(DISTINCT CUSTOMER_ID) AS new_companies, COUNT(*) AS new_rows
FROM client_product WHERE CUSTOMER_ID NOT IN (958255038908, 958297637798, 958475926468);
' | sqlplus -s dev_user/dev_password@//localhost:1521/XEPDB1"
```

```bash
# Проверка правил композиции на добавленных компаниях
# Замени 958300xxx на первый и последний CUSTOMER_ID текущего батча
docker exec ai-analyst-oracle bash -c "echo '
SELECT CUSTOMER_ID, MONTH_DT,
  ABS(PNL_SUM - (PL_CA + PL_DEP + PL_VK + PL_VK_OUT + VED_SUM + FX_MARGIN_RUB)) AS pnl_diff
FROM client_product
WHERE CUSTOMER_ID BETWEEN 958300xxx AND 958300yyy
  AND ABS(PNL_SUM - (PL_CA + PL_DEP + PL_VK + PL_VK_OUT + VED_SUM + FX_MARGIN_RUB)) > 0.01;
' | sqlplus -s dev_user/dev_password@//localhost:1521/XEPDB1"
```

Запрос возвращает ТОЛЬКО строки с нарушениями. Если результат пуст (no rows selected) — все правила композиции соблюдены.

Также проверь количество загруженных строк:
```bash
docker exec ai-analyst-oracle bash -c "echo '
SELECT COUNT(*) AS batch_rows FROM client_product
WHERE CUSTOMER_ID BETWEEN 958300xxx AND 958300yyy;
' | sqlplus -s dev_user/dev_password@//localhost:1521/XEPDB1"
```
Ожидаемый результат: 10 компаний × 12 месяцев = 120 строк.

---

## Шаг 6: Обновление прогресса

Запроси свежие данные из БД и обнови (или создай) файл `dev/seed-progress.md`:

```bash
# Собрать данные для прогресса
docker exec ai-analyst-oracle bash -c "echo '
SELECT SEG, COUNT(DISTINCT CUSTOMER_ID) AS cnt
FROM client_product WHERE CUSTOMER_ID NOT IN (958255038908, 958297637798, 958475926468)
GROUP BY SEG ORDER BY cnt DESC;
SELECT DESK, COUNT(DISTINCT CUSTOMER_ID) AS cnt
FROM client_product WHERE CUSTOMER_ID NOT IN (958255038908, 958297637798, 958475926468)
GROUP BY DESK ORDER BY cnt DESC;
SELECT COUNT(DISTINCT CUSTOMER_ID) AS new_companies, COUNT(*) AS new_rows
FROM client_product WHERE CUSTOMER_ID NOT IN (958255038908, 958297637798, 958475926468);
' | sqlplus -s dev_user/dev_password@//localhost:1521/XEPDB1"
```

Создай (при первом запуске) или обнови `dev/seed-progress.md` с таблицами прогресса:

```markdown
# Seed Data Progress

Последнее обновление: YYYY-MM-DD (сессия N)
Цель: 100 новых компаний, ~1200 строк

## Прогресс

| Метрика | Текущее | Цель | % |
|---------|---------|------|---|
| Новые компании | X | 100 | X% |
| Новые строки | Y | 1200 | Y% |
| Базовые (3 клиента) | 6 | 6 | — |
| **Итого строк** | **Y+6** | **1206** | — |

## Распределение по сегментам (новые)

| Сегмент | Текущее | Цель | Осталось |
|---------|---------|------|----------|
| Large | ... | 10 | ... |
| Middle | ... | 20 | ... |
| International | ... | 25 | ... |
| SME | ... | 25 | ... |
| FI | ... | 5 | ... |
| Region | ... | 15 | ... |

## Последний батч (сессия N)

Добавлено X компаний: CUSTOMER_ID xxx - yyy
- Сегменты: ...
- Верификация: PASSED/FAILED
```

---

## Шаг 7: Завершение

Выведи итоги:
- Сколько компаний добавлено в этом батче
- Какие сегменты/дэски покрыты
- Прогресс к цели (X/100 компаний, Y/1200 строк)
- Результат верификации
- Подтверди отсутствие артефактов: в `dev/` не должно остаться `gen_seed_batch*.py` и `seed_batch*.sql`
- Если цель не достигнута: "Запустите `/seed-data` снова для продолжения."
- Если цель достигнута: "Датасет полон! Проверьте через `python dev/test-connection.py` и `python run_agent.py`."
