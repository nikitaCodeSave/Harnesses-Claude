Создай production-архив проекта для переноса на рабочий сервер.

Архив: `AI_analyst_for_work.zip` в родительской директории проекта.

## Правила

**Включить:**
- Все `*.py` из корня проекта (entry points)
- 4 пакета: `core/`, `application/`, `infrastructure/`, `presentation/`
- `tests/` (smoke-проверки на проде после деплоя; конфиг pytest — в `pyproject.toml`)
- `docs/` (документация) — **кроме** `docs/plans/`, `docs/research/`, `docs/archive/`, `docs/skill-acceptance-tests.md`
- `devlog/` (журнал изменений)
- `.env.example`, `allowed_users.yaml.example` (шаблоны конфигурации, без секретов)
- `pyproject.toml`, `README.md`, `CLAUDE.md`, `.gitignore`
- `CLAUDE.md` корневой (главные инструкции проекта) + любые вложенные CLAUDE.md (например `devlog/CLAUDE.md`) попадают автоматически вместе с соответствующими папками

**Исключить:**
- `.venv/` — устанавливается из pyproject.toml
- `.git/` — git-история не нужна на проде
- `.claude/`, `.cursor/` — конфиги IDE/агентов
- `dev/`, `docker-compose.dev.yml` — dev-тулинг
- `.env`, `.env.dev` — секреты и dev-конфиг
- `__pycache__/`, `.pytest_cache/`, `.ruff_cache/` — кеши
- `data/` — данные мониторинга (на сервере свои)
- `logs/` — логи (на сервере свои)
- `output/` — сгенерированные файлы
- `.DS_Store` — macOS мусор
- `docs/plans/`, `docs/research/`, `docs/archive/` — dev-only
- `docs/skill-acceptance-tests.md` — dev-only

## Команда

```bash
cd <project_root>
rm -f ../AI_analyst_for_work.zip
zip -r ../AI_analyst_for_work.zip \
  *.py \
  core/ \
  application/ \
  infrastructure/ \
  presentation/ \
  tests/ \
  .env.example \
  allowed_users.yaml.example \
  pyproject.toml \
  README.md \
  CLAUDE.md \
  .gitignore \
  docs/ \
  devlog/ \
  -x "docs/plans/*" "docs/research/*" "docs/archive/*" "docs/skill-acceptance-tests.md" "*/__pycache__/*" "*.pyc" "*/.DS_Store"
```

## После создания

1. Проверь содержимое: `unzip -l ../AI_analyst_for_work.zip | tail -5`
2. Проверь размер: `du -sh ../AI_analyst_for_work.zip`
3. Убедись что ключевые файлы на месте: `unzip -l ../AI_analyst_for_work.zip | grep -c '\.py$'`
4. Проверь документацию: `unzip -l ../AI_analyst_for_work.zip | grep -E "CLAUDE\.md|README\.md|docs/architecture|docs/setup|docs/configuration"`
5. Сообщи: количество файлов, размер, что нового по сравнению с прошлым разом
