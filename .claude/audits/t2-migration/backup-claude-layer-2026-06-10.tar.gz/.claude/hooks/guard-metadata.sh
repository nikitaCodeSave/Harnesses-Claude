#!/usr/bin/env bash
# PreToolUse hook: предупреждение при редактировании metadata.py
# Читает JSON payload со stdin, проверяет file_path

set -euo pipefail

INPUT=$(cat)
FILE_PATH=$(echo "$INPUT" | python3 -c "
import sys, json
try:
    data = json.load(sys.stdin)
    print(data.get('tool_input', {}).get('file_path', ''))
except Exception:
    print('')
" 2>/dev/null || echo "")

if [[ "$FILE_PATH" == *"metadata.py"* ]]; then
    echo "ПРЕДУПРЕЖДЕНИЕ: metadata.py используется в 6 модулях: relevance_checker, sql_generator, sql_validator, response_generator, chart_generator, agent. Проверь все зависимые модули после изменения." >&2
fi

exit 0
