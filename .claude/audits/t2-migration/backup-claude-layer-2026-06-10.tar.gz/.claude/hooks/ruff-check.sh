#!/usr/bin/env bash
# PostToolUse hook: запуск ruff check на изменённом .py файле
# Читает JSON payload со stdin

set -euo pipefail

INPUT=$(cat)
FILE_PATH=$(echo "$INPUT" | python3 -c "
import sys, json
try:
    data = json.load(sys.stdin)
    print(data.get('tool_input', {}).get('file_path', ''))
except Exception:
    print('')
" 2>/dev/null || echo "")

# Проверяем только .py файлы
if [[ "$FILE_PATH" != *.py ]]; then
    exit 0
fi

# Проверяем что файл существует
if [[ ! -f "$FILE_PATH" ]]; then
    exit 0
fi

# Ищем ruff
RUFF=""
if command -v ruff &>/dev/null; then
    RUFF="ruff"
elif [[ -x "$HOME/.local/bin/ruff" ]]; then
    RUFF="$HOME/.local/bin/ruff"
fi

if [[ -z "$RUFF" ]]; then
    echo "ruff не найден — пропускаю lint-проверку" >&2
    exit 0
fi

# Запускаем ruff check
$RUFF check "$FILE_PATH" 2>&1 || true

exit 0
