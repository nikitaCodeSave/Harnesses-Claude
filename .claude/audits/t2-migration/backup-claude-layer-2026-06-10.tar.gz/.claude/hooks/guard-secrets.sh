#!/usr/bin/env bash
# PreToolUse hook: блокировка git commit/push с секретами в staged файлах

set -euo pipefail

INPUT=$(cat)
COMMAND=$(echo "$INPUT" | python3 -c "
import sys, json
try:
    data = json.load(sys.stdin)
    print(data.get('tool_input', {}).get('command', ''))
except Exception:
    print('')
" 2>/dev/null || echo "")

# Проверяем только git commit и git push
if [[ "$COMMAND" != *"git commit"* && "$COMMAND" != *"git push"* ]]; then
    exit 0
fi

# Ищем строки с реальными хардкодами секретов (со строковым значением в кавычках)
SECRETS_FOUND=$(git diff --cached --diff-filter=ACM -U0 -- ':!tests/' ':!docs/plans/' 2>/dev/null \
  | grep -iE '^\+.*(API_KEY|PASSWORD|SECRET|TOKEN|DSN)\s*=\s*["\x27]' \
  | grep -v '^\+.*#' \
  | grep -v '^\+.*example' \
  | grep -v '^\+.*placeholder' \
  | grep -v '^\+.*your[-_]' \
  | grep -v '^\+.*xxx' \
  | grep -v '^\+.*="test"' \
  | grep -v '^\+.*=""' \
  | grep -v '^\+.*=\s*[a-z_]*$' \
  | grep -v '^\+.*=\s*os\.environ' \
  | grep -v '^\+.*=\s*os\.getenv' \
  | grep -v '^\+.*=\s*get_settings()' \
  | grep -v '^\+.*=\s*settings\.' \
  | head -5 || true)

if [[ -n "$SECRETS_FOUND" ]]; then
    echo "BLOCKED: possible secrets found in staged files:" >&2
    echo "$SECRETS_FOUND" >&2
    echo "Remove secrets from staged files before committing." >&2
    exit 2
fi

exit 0
