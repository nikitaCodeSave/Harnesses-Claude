# AI Analyst for Work

Система аналитики данных для банка. Принимает вопросы на естественном языке, генерирует SQL, выполняет на Oracle DB, строит графики и отчёты (PDF, Excel). Интегрирована с Zulip.

## Стек

- Python 3.10+ (truststore требует >=3.10)
- Oracle DB (oracledb >=2.5.0)
- OpenAI-совместимый API (модель GenAI/Qwen3-30B-A3B)
- pandas, matplotlib, reportlab, scikit-learn (TF-IDF)
- Zulip (бот-интеграция)

## Структура проекта

Модульная структура (ADR-012). Весь код в пакетах `infrastructure/`, `core/`, `application/`, `presentation/`.

```
presentation/            # Слой представления — точки входа
  cli.py                 # Консольный REPL через .env / settings.py
  zulip_bot.py           # Zulip бот (ZulipBot, ZulipProgressUpdater, main)
  batch_cli.py           # CLI для batch-режима (--input, --output, --format)

application/             # Слой приложения
  agent.py               # Тонкий оркестратор: AIAgent, process_question(), run_console()
  subquestion.py         # Обработка одного подвопроса (5-шаговый pipeline + runtime-retry SQL execute)
  reports.py             # Шаги 5-8: объединение DF, график, финальный ответ, Excel, PDF; детерминированный ответ при no_data
  batch_runner.py        # Batch-режим: прогон списка вопросов, аналитическая таблица

core/types.py            # Доменные типы пайплайна (SubquestionResult TypedDict)

infrastructure/          # Инфраструктурный слой
  settings.py            # Централизованная конфигурация (pydantic-settings v2, .env)
  llm_client.py          # Singleton-клиент OpenAI API + SSL (truststore), LLMCallError
  db_connector.py        # Подключение к Oracle (oracledb + pandas.read_sql)
  metadata.py            # Словарь полей таблицы client_product (~500 строк)
  log_setup.py           # Настройка логирования (stdout text/JSON + JSONL error/all файлы, RequestIdFilter)
  log_context.py         # request_id через contextvars (set/get_request_id)
  utils.py               # Общие утилиты: get_word_stem(), extract_python_code(), is_id_column()
  safe_builtins.py       # Ограниченный набор builtins для exec() (ADR-002)
  output_config.py       # Управление папкой output/
  perf_timer.py          # Замер производительности (PerfTimer, format_timing_summary)
  progress.py            # Типизированные прогресс-события (ProgressEvent, ProgressEventType, make_progress_emit)
  request_tracker.py     # Мониторинг: сбор, хранение, загрузка данных запросов (ADR-014)
  analytics.py           # Аналитика использования: Excel-отчёты (6 листов) (ADR-014)
  user_access.py          # YAML whitelist доступа: email/fnmatch → bool (AccessDeniedError)

core/sql/                # SQL-пайплайн (ADR-010)
  generator.py           # Оркестрация генерации SQL через LLM
  field_search.py        # TF-IDF поиск релевантных полей метаданных
  keywords.py            # Извлечение ключевых слов + морфологический поиск
  extraction.py          # Извлечение SQL из ответа LLM
  validator.py           # Валидация SQL: детерминированные фиксы (LIKE, nested aggs, subquery alias/column refs, dedup, collapsed date-range) + EXPLAIN PLAN + LLM fix с enriched errors (ORA-00937/00979/00904)

core/analysis/           # Анализ вопроса
  relevance_checker.py   # Проверка релевантности вопроса по metadata
  question_analyzer.py   # Разбиение вопроса на атомарные подвопросы
  prompts/v1/            # Шаблоны промптов (analyze_question.txt, generate_final_response.txt)

core/output/             # Генерация вывода
  chart_builder.py       # Детерминированные графики по структуре DataFrame (ADR-017)
  response_generator.py  # Генерация NL-ответа из DataFrame через LLM
  chart_generator.py     # LLM-генерация matplotlib-графиков (fallback для chart_builder)
  df_merger.py           # Детерминированное объединение DataFrames (0 LLM, <10мс)
  code_generator.py      # Генерация pandas-кода для объединения DataFrame (LLM fallback для df_merger)
  code_validator.py      # Валидация и exec pandas-кода (SAFE_BUILTINS)

core/report/             # PDF-отчёты (ADR-011)
  pdf_generator.py       # PDF-отчёт через reportlab (тонкий оркестратор)
  formatters.py          # Форматирование значений/текста для PDF
  styles.py              # Цвета, константы, шрифты, ParagraphStyle/TableStyle
  table_builder.py       # Построение таблиц PDF с авто-шириной и разбивкой

# Entry points (корень) — thin wrappers
run_agent.py             # -> presentation.cli
run_batch.py             # -> presentation.batch_cli
zulip_bot.py             # -> presentation.zulip_bot
```

## Архитектура (8-шаговый пайплайн)

1. `relevance_checker` — проверка релевантности вопроса по metadata
2. `question_analyzer` — разбиение на N атомарных подвопросов
3. Цикл по подвопросам: sql_generator → sql_validator (+ детерминированные фиксы) → db_connector (+ runtime-retry при ORA-ошибках) → chart_builder (deterministic) / chart_generator (LLM fallback) → response_generator
4. `df_merger` (deterministic) / `python_code_generator` (LLM fallback) — объединение DataFrame
5. `chart_builder` / `chart_generator` — итоговый график
6. `response_generator` — финальный NL-ответ (при 0 успешных подвопросов — детерминированный ответ, без LLM)
7. `save_dataframes_to_excel` — экспорт в Excel
8. `pdf_generator` — PDF-отчёт
9. `request_tracker` — сохранение данных запроса для мониторинга (non-fatal)

Подробнее: docs/architecture.md

## Виртуальная среда и команды

Виртуальная среда: `.venv` в корне. Используй `.venv/bin/python`, `.venv/bin/pytest` или `source .venv/bin/activate`.
Линтер ruff установлен ГЛОБАЛЬНО (в PATH). Запускать `ruff check`, НЕ `.venv/bin/ruff`.

```bash
# консольный режим (рекомендуется)
python run_agent.py

# batch-режим (прогон списка вопросов)
python run_batch.py --input questions.json --output results.csv

# zulip бот
python zulip_bot.py
```

## Правила

- Workflow, запреты, ADR-критерии → `.claude/rules/development-workflow.md`
- Стиль кода → `.claude/rules/code-style.md`
- Тестирование → `.claude/rules/testing.md`
- Devlog → `.claude/rules/devlog.md`
- Фаза мышления → `.claude/rules/thinking-mode.md` (docs/thinking/)
- ADR: docs/decisions/ (ADR-001..ADR-022)
- Архитектура: docs/architecture.md
- Исследования: docs/research/ (трассировка кодовой базы), docs/thinking/ (широкое исследование идей)
- Инициативы (крупные, долгоживущие): docs/initiatives/<name>/README.md — карта, roadmap, open-questions, decisions-log, insights. Сейчас активно: `production-v2` (MVP → продовая архитектура), `sql-prompt-quality` (Iter 3.1 promoted-to-baseline 2026-05-04, продолжается стабилизация v1 SQL-промпта)

## Dev-окружение

Запуск: `./dev/run-dev.sh` | Проверка: `python dev/test-connection.py` | Seed-данные: `python dev/generate_seed.py`
